/**
 * SiteForge API Worker — main entry point.
 *
 * Fixes vs original:
 *  - sha256 imported at top (was imported mid-file, invalid ES module syntax)
 *  - Static template routes (/featured, /new, /trending) ordered BEFORE /:id
 *    so they are not swallowed by the param pattern
 *  - Queue consumer uses MAX_RETRIES + exponential backoff with DLQ logging
 *  - handleQueueMessage is defined here where all imports are available,
 *    not in rate-limit.js where they were unreachable
 *  - adminSetup routes added
 */

import { handleCORS } from './middleware/cors.js';
import { checkRateLimit } from './middleware/rate-limit.js';
import { success, error } from './utils/response.js';
import { sha256 } from './utils/encryption.js';
import * as auth from './auth.js';
import * as sites from './sites.js';
import * as templates from './templates.js';
import * as deploy from './deploy.js';
import * as paynow from './paynow.js';
import * as oauth from './oauth.js';
import * as push from './push.js';
import * as githubBuild from './github-build.js';
import * as adminSetup from './admin-setup.js';
import * as templateRoutes from './template-factory/routes.js';

const MAX_RETRIES = 3;
const BASE_DELAY_SECONDS = 60;

// ─── Route table ────────────────────────────────────────────────────────────
// IMPORTANT: static segments must precede param segments in each method group.

const ROUTES = [
  // Auth
  ['POST',   '/api/auth/send-otp',                    auth.handleSendOTP],
  ['POST',   '/api/auth/verify-otp',                  auth.handleVerifyOTP],
  ['POST',   '/api/auth/refresh',                     auth.handleRefreshToken],
  ['GET',    '/api/auth/me',                          auth.handleGetMe,                 'auth'],

  // Sites
  ['POST',   '/api/sites',                            sites.handleCreateSite,           'auth'],
  ['GET',    '/api/sites',                            sites.handleListSites,            'auth'],
  ['GET',    '/api/sites/:id',                        sites.handleGetSite,              'auth'],
  ['PATCH',  '/api/sites/:id',                        sites.handleUpdateSite,           'auth'],
  ['DELETE', '/api/sites/:id',                        sites.handleDeleteSite,           'auth'],
  ['GET',    '/api/sites/:id/content',                sites.handleGetContent,           'auth'],
  ['PUT',    '/api/sites/:id/content',                sites.handleUpdateContent,        'auth'],
  ['PUT',    '/api/sites/:id/app-config',             sites.handleUpdateAppConfig,      'auth'],
  ['POST',   '/api/sites/:id/publish',                deploy.handlePublish,             'auth'],
  ['POST',   '/api/sites/:id/rebuild',                deploy.handleRebuild,             'auth'],

  // Templates — static routes BEFORE /:id to avoid param shadowing
  ['GET',    '/api/templates/featured',               templateRoutes.handleFeaturedTemplates],
  ['GET',    '/api/templates/new',                    templateRoutes.handleNewTemplates],
  ['GET',    '/api/templates/trending',               templateRoutes.handleTrendingTemplates],
  ['GET',    '/api/templates/factory/industries',     templateRoutes.handleListIndustries],
  ['GET',    '/api/templates/factory/design-systems', templateRoutes.handleListDesignSystems],
  ['POST',   '/api/templates/factory/generate',       templateRoutes.handleGenerateTemplates],
  ['GET',    '/api/templates',                        templates.handleListTemplates],
  ['GET',    '/api/templates/:id',                    templates.handleGetTemplate],

  // Paynow
  ['POST',   '/api/paynow/initiate',                  paynow.handleInitiatePayment,     'auth'],
  ['POST',   '/api/paynow/callback',                  paynow.handlePaymentCallback],
  ['GET',    '/api/paynow/status/:ref',               paynow.handlePaymentStatus,       'auth'],
  ['POST',   '/api/paynow/recurring',                 paynow.handleRecurringCharge],

  // Cloudflare OAuth
  ['GET',    '/api/oauth/cloudflare',                 oauth.handleOAuthRedirect,        'auth'],
  ['GET',    '/api/oauth/cloudflare/callback',        oauth.handleOAuthCallback],

  // Push notifications
  ['POST',   '/api/push/register',                    push.handleRegisterDevice],
  ['POST',   '/api/push/send',                        push.handleSendPush,              'auth'],
  ['GET',    '/api/push/campaigns',                   push.handleListCampaigns,         'auth'],

  // GitHub builds
  ['POST',   '/api/builds/app',                       githubBuild.handleTriggerBuild,   'auth'],
  ['POST',   '/api/builds/complete',                  githubBuild.handleBuildComplete],

  // Admin
  ['POST',   '/api/admin/provision',                  adminSetup.handleProvision],
  ['GET',    '/api/admin/status',                     adminSetup.handleStatus],

  // Health
  ['GET',    '/api/health',                           () => success({ status: 'ok', timestamp: new Date().toISOString() })],
];

// ─── Router ──────────────────────────────────────────────────────────────────

function matchRoute(method, pathname) {
  for (const [routeMethod, pattern, handler, authRequired] of ROUTES) {
    if (method !== routeMethod) continue;
    const paramNames = [];
    const regexStr = pattern.replace(/:([^/]+)/g, (_, name) => {
      paramNames.push(name);
      return '([^/]+)';
    });
    const match = pathname.match(new RegExp(`^${regexStr}$`));
    if (match) {
      const params = {};
      paramNames.forEach((name, i) => { params[name] = match[i + 1]; });
      return { handler, params, authRequired };
    }
  }
  return null;
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

async function authenticate(request, env) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7);
  const tokenHash = await sha256(token);
  const db = env.DB;
  if (!db) return null;
  const record = await db.prepare(
    'SELECT user_id, expires_at FROM auth_tokens WHERE token_hash = ? AND token_type = ? AND revoked_at IS NULL'
  ).bind(tokenHash, 'access').first();
  if (!record) return null;
  if (new Date(record.expires_at) < new Date()) return null;
  return record.user_id;
}

// ─── Queue handler ───────────────────────────────────────────────────────────

async function handleQueueMessage(message, env) {
  const retryCount = message.attempts || 0;
  try {
    const { type, payload } = message.body;
    switch (type) {
      case 'deploy-site':         await deploy.handleDeployJob(payload, env);   break;
      case 'build-apk':           await githubBuild.handleBuildJob(payload, env); break;
      case 'send-push-campaign':  await push.handlePushJob(payload, env);       break;
      case 'process-renewal':     await paynow.handleRenewalJob(payload, env);  break;
      default:
        console.warn('[Queue] Unknown job type:', type);
    }
    message.ack();
  } catch (err) {
    console.error(`[Queue] Job failed (attempt ${retryCount + 1}/${MAX_RETRIES + 1}):`, err.message);
    if (retryCount >= MAX_RETRIES) {
      await logToDeadLetterQueue(message.body, err, env);
      message.ack();
    } else {
      const delay = BASE_DELAY_SECONDS * Math.pow(2, retryCount);
      message.retry({ delaySeconds: delay });
    }
  }
}

async function logToDeadLetterQueue(messageBody, err, env) {
  try {
    await env.DB.prepare(
      `INSERT INTO build_logs (site_id, build_type, status, log_output, completed_at)
       VALUES (?, 'dead-letter', 'failed', ?, datetime('now'))`
    ).bind(
      messageBody?.payload?.siteId || 0,
      `[DLQ] ${err.message}\nPayload: ${JSON.stringify(messageBody)}`
    ).run();
  } catch (e) {
    console.error('[DLQ] Failed to log:', e.message);
  }
}

// ─── Main export ─────────────────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    if (request.method === 'OPTIONS') return handleCORS(request);

    const url = new URL(request.url);
    const pathname = url.pathname;

    const rateLimit = await checkRateLimit(request, env);
    if (!rateLimit.allowed) return error(rateLimit.error, 429);

    const route = matchRoute(request.method, pathname);
    if (!route) return error('Not found', 404);

    if (route.authRequired) {
      const userId = await authenticate(request, env);
      if (!userId) return error('Authentication required', 401);
      request.userId = userId;
    }

    request.env = env;
    request.params = route.params;

    try {
      return await route.handler(request);
    } catch (err) {
      console.error('[Fetch] Unhandled error:', err.message);
      return error('Internal server error', 500,
        env.ENVIRONMENT !== 'production' ? err.message : null);
    }
  },

  async queue(batch, env, ctx) {
    for (const message of batch.messages) {
      await handleQueueMessage(message, env);
    }
  },
};
