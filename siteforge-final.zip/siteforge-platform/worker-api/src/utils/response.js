/**
 * Standardized API response helpers.
 */

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
  'Access-Control-Max-Age': '86400',
};

export function success(data = null, meta = {}, status = 200) {
  return new Response(JSON.stringify({ success: true, data, error: null, meta }), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

export function error(message, status = 400, details = null, meta = {}) {
  return new Response(JSON.stringify({ success: false, data: null, error: { message, details, status }, meta }), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

export function created(data = null, meta = {}) { return success(data, meta, 201); }

export function noContent() {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

export function redirect(url, status = 302) {
  return new Response(null, { status, headers: { Location: url, ...CORS_HEADERS } });
}

export async function parseBody(request) {
  try {
    const text = await request.text();
    if (!text) return {};
    return JSON.parse(text);
  } catch (e) {
    return null;
  }
}

export function getPagination(request, defaultLimit = 20, maxLimit = 100) {
  const url = new URL(request.url);
  const page = Math.max(1, parseInt(url.searchParams.get('page')) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(url.searchParams.get('limit')) || defaultLimit));
  return { page, limit, offset: (page - 1) * limit };
}

export function validateRequired(body, fields) {
  if (!body) return fields;
  return fields.filter(f => body[f] === undefined || body[f] === null || body[f] === '');
}
