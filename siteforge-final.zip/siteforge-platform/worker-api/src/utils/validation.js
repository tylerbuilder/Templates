/**
 * Input validation utilities.
 */

const ZIM_PHONE_REGEX = /^(\+263|0)(7[1-8])\d{7}$/;
const SUBDOMAIN_REGEX = /^[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]$/;
const SITE_NAME_REGEX = /^[a-zA-Z0-9\s\-'&.,!?()]{2,100}$/;
const SLUG_REGEX = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const RESERVED_SUBDOMAINS = ['www', 'admin', 'api', 'mail', 'ftp', 'smtp', 'pop', 'ns1', 'ns2', 'app', 'blog', 'shop', 'store'];

export function validatePhone(phone) {
  if (!phone) return { valid: false, error: 'Phone number is required' };
  if (!ZIM_PHONE_REGEX.test(phone)) {
    return { valid: false, error: 'Invalid Zimbabwe phone number. Use format: 0771234567 or +263771234567' };
  }
  const normalized = phone.startsWith('0') ? '+263' + phone.slice(1) : phone;
  return { valid: true, normalized };
}

export function validateSubdomain(subdomain) {
  if (!subdomain) return { valid: false, error: 'Subdomain is required' };
  if (!SUBDOMAIN_REGEX.test(subdomain)) {
    return { valid: false, error: 'Subdomain must be 3-63 characters, lowercase letters, numbers, and hyphens only' };
  }
  if (RESERVED_SUBDOMAINS.includes(subdomain.toLowerCase())) {
    return { valid: false, error: 'This subdomain is reserved' };
  }
  return { valid: true, normalized: subdomain.toLowerCase() };
}

export function validateSiteName(name) {
  if (!name) return { valid: false, error: 'Site name is required' };
  if (name.length < 2 || name.length > 100) {
    return { valid: false, error: 'Site name must be between 2 and 100 characters' };
  }
  if (!SITE_NAME_REGEX.test(name)) {
    return { valid: false, error: 'Site name contains invalid characters' };
  }
  return { valid: true, sanitized: name.trim() };
}

export function validateTemplateId(templateId, availableTemplates) {
  if (!templateId) return { valid: false, error: 'Template ID is required' };
  if (!availableTemplates.includes(templateId)) {
    return { valid: false, error: 'Invalid template ID' };
  }
  return { valid: true };
}

export function validateContent(content, templateSchema) {
  if (!content || typeof content !== 'object') return { valid: false, error: 'Content must be a JSON object' };
  const missingFields = [];
  if (templateSchema?.required) {
    for (const field of templateSchema.required) {
      if (content[field] === undefined || content[field] === null) missingFields.push(field);
    }
  }
  if (missingFields.length > 0) {
    return { valid: false, error: `Missing required fields: ${missingFields.join(', ')}`, missingFields };
  }
  const sanitized = {};
  for (const [key, value] of Object.entries(content)) {
    sanitized[key] = typeof value === 'string' ? sanitizeHTML(value) : value;
  }
  return { valid: true, sanitized };
}

function sanitizeHTML(html) {
  if (!html) return '';
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
    .replace(/on\w+\s*=\s*[^\s>]+/gi, '')
    .replace(/javascript\s*:/gi, '')
    .trim();
}

export function validateEmail(email) {
  if (!email) return { valid: true };
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) return { valid: false, error: 'Invalid email address' };
  return { valid: true };
}

export function validatePagination(page, limit) {
  const p = Math.max(1, parseInt(page) || 1);
  const l = Math.min(100, Math.max(1, parseInt(limit) || 20));
  return { page: p, limit: l, offset: (p - 1) * l };
}

export function validateSlug(slug) {
  if (!slug) return { valid: false, error: 'Slug is required' };
  if (!SLUG_REGEX.test(slug)) return { valid: false, error: 'Slug must be lowercase letters, numbers, and hyphens only' };
  return { valid: true };
}
