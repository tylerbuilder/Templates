/**
 * GitHub integration — creates customer repos, triggers APK builds via Actions.
 *
 * Fixes vs original:
 *  - handleBuildComplete now properly verifies HMAC-SHA256 webhook signature
 *  - pemToArrayBuffer correctly strips both PKCS8 and RSA PRIVATE KEY headers
 *  - pushToRepo already used the correct tree-based batch API (no file-by-file calls)
 */

import { success, error, parseBody, validateRequired } from './utils/response.js';

export async function handleTriggerBuild(request) {
  const userId = request.userId;
  const body = await parseBody(request);
  if (!body) return error('Invalid body', 400);
  const missing = validateRequired(body, ['siteId']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const siteId = body.siteId;
  const db = request.env.DB;

  const site = await db.prepare('SELECT * FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);
  if (!site.has_native_app) return error('Native app not purchased for this site', 402);
  if (site.app_rebuilds_this_month >= 5) return error('Monthly rebuild limit (5) reached.', 429);

  await request.env.BUILD_QUEUE.send({ type: 'build-apk', payload: { siteId: parseInt(siteId) } });
  await db.prepare('UPDATE sites SET app_build_status = ?, app_rebuilds_this_month = app_rebuilds_this_month + 1 WHERE id = ?').bind('building', siteId).run();

  return success({ message: 'Build queued', siteId: parseInt(siteId) });
}

export async function handleBuildComplete(request) {
  // Read raw body first so we can verify the HMAC before parsing
  const rawBody = await request.text();

  const signature = request.headers.get('X-Hub-Signature-256');
  const webhookSecret = request.env.GITHUB_WEBHOOK_SECRET;

  if (webhookSecret) {
    if (!signature) return error('Missing signature', 401);
    const verified = await verifyWebhookSignature(rawBody, signature, webhookSecret);
    if (!verified) return error('Invalid signature', 401);
  }

  let body;
  try { body = JSON.parse(rawBody); } catch (e) { return error('Invalid JSON', 400); }

  const missing = validateRequired(body, ['siteId', 'status']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const { siteId, status, apkUrl, logOutput } = body;
  const db = request.env.DB;

  if (status === 'success' && apkUrl) {
    await db.prepare('UPDATE sites SET app_build_status = ?, app_apk_url = ?, updated_at = datetime("now") WHERE id = ?').bind('ready', apkUrl, siteId).run();
  } else if (status === 'failed') {
    await db.prepare('UPDATE sites SET app_build_status = ? WHERE id = ?').bind('failed', siteId).run();
  }

  await db.prepare(
    `INSERT INTO build_logs (site_id, build_type, status, log_output, started_at, completed_at) VALUES (?, 'apk', ?, ?, datetime('now', '-5 minutes'), datetime('now'))`
  ).bind(siteId, status, logOutput || null).run();

  return success({ message: 'Build status recorded' });
}

export async function handleBuildJob(payload, env) {
  const { siteId } = payload;
  const db = env.DB;

  console.log(`[Build] Starting APK build for site ${siteId}`);

  const logResult = await db.prepare('INSERT INTO build_logs (site_id, build_type, status, started_at) VALUES (?, ?, ?, datetime("now"))').bind(siteId, 'apk', 'running').run();
  const buildLogId = logResult.meta.last_row_id;

  try {
    const site = await db.prepare('SELECT * FROM sites WHERE id = ?').bind(siteId).first();
    if (!site) throw new Error('Site not found');

    const content = JSON.parse(site.content_json || '{}');
    const appConfig = site.app_config ? JSON.parse(site.app_config) : {};
    const githubToken = await getGitHubInstallationToken(env);
    const org = env.GITHUB_ORG;
    const repoName = site.github_repo_name || `app-${site.subdomain}`;

    const repoExists = await checkRepoExists(org, repoName, githubToken);
    if (!repoExists) {
      await createCustomerRepo(org, repoName, githubToken);
      await db.prepare('UPDATE sites SET github_repo_name = ? WHERE id = ?').bind(repoName, siteId).run();
    }

    const appFiles = await prepareAppFiles(site, content, appConfig, env);
    await pushToRepo(org, repoName, githubToken, appFiles);
    await triggerWorkflow(org, repoName, githubToken, siteId, env);

    await db.prepare('UPDATE build_logs SET status = ?, completed_at = datetime("now") WHERE id = ?').bind('success', buildLogId).run();
    console.log(`[Build] APK build triggered for site ${siteId}`);

  } catch (err) {
    console.error(`[Build] Failed site ${siteId}:`, err.message);
    await db.prepare('UPDATE sites SET app_build_status = ? WHERE id = ?').bind('failed', siteId).run();
    await db.prepare('UPDATE build_logs SET status = ?, log_output = ?, completed_at = datetime("now") WHERE id = ?').bind('failed', err.message, buildLogId).run();
    throw err;
  }
}

// ─── GitHub App auth ─────────────────────────────────────────────────────────

async function getGitHubInstallationToken(env) {
  const appId = env.GITHUB_APP_ID;
  const privateKey = env.GITHUB_APP_PRIVATE_KEY;
  const installationId = env.GITHUB_APP_INSTALLATION_ID;

  if (!appId || !privateKey || !installationId) throw new Error('GitHub App not configured');

  const jwt = await generateGitHubJWT(appId, privateKey);

  const res = await fetch(`https://api.github.com/app/installations/${installationId}/access_tokens`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${jwt}`, Accept: 'application/vnd.github.v3+json', 'User-Agent': 'SiteForge/1.0' },
  });

  const data = await res.json();
  if (!data.token) throw new Error(`Failed to get installation token: ${JSON.stringify(data)}`);
  return data.token;
}

async function generateGitHubJWT(appId, privateKey) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const payload = { iat: now - 60, exp: now + 600, iss: String(appId) };

  const headerB64 = btoa(JSON.stringify(header)).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const payloadB64 = btoa(JSON.stringify(payload)).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const signingInput = `${headerB64}.${payloadB64}`;

  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    pemToArrayBuffer(privateKey),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', cryptoKey, new TextEncoder().encode(signingInput));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  return `${signingInput}.${sigB64}`;
}

function pemToArrayBuffer(pem) {
  // Strip all PEM header/footer variants (PKCS8, RSA PRIVATE KEY, etc.)
  const b64 = pem
    .replace(/-----BEGIN [A-Z ]+-----/g, '')
    .replace(/-----END [A-Z ]+-----/g, '')
    .replace(/\s/g, '');
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

// ─── Webhook signature verification ──────────────────────────────────────────

async function verifyWebhookSignature(body, signatureHeader, secret) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(body));
  const hexSig = 'sha256=' + Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
  // Constant-time compare
  if (hexSig.length !== signatureHeader.length) return false;
  let diff = 0;
  for (let i = 0; i < hexSig.length; i++) diff |= hexSig.charCodeAt(i) ^ signatureHeader.charCodeAt(i);
  return diff === 0;
}

// ─── Repo management ─────────────────────────────────────────────────────────

async function checkRepoExists(org, repoName, token) {
  const res = await fetch(`https://api.github.com/repos/${org}/${repoName}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json', 'User-Agent': 'SiteForge/1.0' },
  });
  return res.ok;
}

async function createCustomerRepo(org, repoName, token) {
  const res = await fetch(`https://api.github.com/orgs/${org}/repos`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json', 'Content-Type': 'application/json', 'User-Agent': 'SiteForge/1.0' },
    body: JSON.stringify({ name: repoName, private: true, auto_init: false, description: 'Customer app — SiteForge' }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(`Failed to create repo: ${JSON.stringify(err)}`);
  }
}

async function prepareAppFiles(site, content, appConfig, env) {
  const files = {};

  // Fetch and hydrate site template files
  const templateFiles = await fetchTemplateForApp(site.template_id, env);
  for (const [path, fileContent] of Object.entries(templateFiles)) {
    if (typeof fileContent === 'string') {
      let out = fileContent;
      for (const [key, val] of Object.entries(content)) {
        out = out.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), String(val ?? ''));
      }
      files[`site/${path}`] = out;
    }
  }

  files['app-config.json'] = JSON.stringify({
    appName: appConfig.appName || content.site_name || 'My App',
    appIcon: appConfig.appIcon || 'default-icon.png',
    splashColor: appConfig.splashColor || '#ffffff',
    splashLogo: appConfig.splashLogo || '',
    bottomNav: appConfig.bottomNav || [
      { label: 'Home', page: 'site/index.html', icon: 'home' },
      { label: 'About', page: 'site/about.html', icon: 'info' },
      { label: 'Contact', page: 'site/contact.html', icon: 'phone' },
    ],
    whatsappNumber: appConfig.whatsappNumber || content.whatsapp || '',
    phoneNumber: appConfig.phoneNumber || content.phone || '',
    address: appConfig.address || content.address || '',
    primaryColor: appConfig.primaryColor || '#1d1d1f',
    accentColor: appConfig.accentColor || '#2997ff',
    enableOffline: true,
    enablePushNotifications: appConfig.enablePushNotifications || false,
    siteId: site.id,
    siteUrl: site.live_url || '',
  }, null, 2);

  return files;
}

async function fetchTemplateForApp(templateId, env) {
  const cacheKey = `template:${templateId}:files`;
  try {
    const cached = await env.CONTENT_CACHE.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch (e) { /* miss */ }

  const GITHUB_RAW = 'https://raw.githubusercontent.com';
  const repo = env.TEMPLATES_REPO;
  const knownFiles = ['index.html', 'about.html', 'menu.html', 'contact.html', 'services.html', 'gallery.html', 'assets/css/style.css', 'assets/js/main.js'];
  const files = {};

  if (repo) {
    await Promise.all(knownFiles.map(async file => {
      try {
        const res = await fetch(`${GITHUB_RAW}/${repo}/main/templates/${templateId}/${file}`);
        if (res.ok) files[file] = await res.text();
      } catch (e) { /* skip */ }
    }));
  }

  return files;
}

// ─── Batch push to GitHub via Tree API ──────────────────────────────────────
// Uses a single commit per push (no per-file API calls).

async function pushToRepo(org, repoName, token, files) {
  const branch = 'main';
  const headers = { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json', 'Content-Type': 'application/json', 'User-Agent': 'SiteForge/1.0' };

  // Get current HEAD SHA (may not exist on first push)
  let baseSha = null;
  try {
    const refRes = await fetch(`https://api.github.com/repos/${org}/${repoName}/git/refs/heads/${branch}`, { headers });
    if (refRes.ok) {
      const refData = await refRes.json();
      baseSha = refData.object?.sha;
    }
  } catch (e) { /* first push */ }

  // Build tree
  const tree = Object.entries(files).map(([path, content]) => ({
    path,
    mode: '100644',
    type: 'blob',
    content: typeof content === 'string' ? content : JSON.stringify(content),
  }));

  // Create tree object
  const treeRes = await fetch(`https://api.github.com/repos/${org}/${repoName}/git/trees`, {
    method: 'POST', headers,
    body: JSON.stringify({ base_tree: baseSha, tree }),
  });
  const treeData = await treeRes.json();
  if (!treeData.sha) throw new Error(`Tree creation failed: ${JSON.stringify(treeData)}`);

  // Create commit
  const commitRes = await fetch(`https://api.github.com/repos/${org}/${repoName}/git/commits`, {
    method: 'POST', headers,
    body: JSON.stringify({ message: `Site update — ${new Date().toISOString()}`, tree: treeData.sha, parents: baseSha ? [baseSha] : [] }),
  });
  const commitData = await commitRes.json();
  if (!commitData.sha) throw new Error(`Commit failed: ${JSON.stringify(commitData)}`);

  // Update or create branch ref
  if (baseSha) {
    await fetch(`https://api.github.com/repos/${org}/${repoName}/git/refs/heads/${branch}`, {
      method: 'PATCH', headers, body: JSON.stringify({ sha: commitData.sha, force: false }),
    });
  } else {
    await fetch(`https://api.github.com/repos/${org}/${repoName}/git/refs`, {
      method: 'POST', headers, body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: commitData.sha }),
    });
  }
}

async function triggerWorkflow(org, repoName, token, siteId, env) {
  const res = await fetch(`https://api.github.com/repos/${org}/${repoName}/dispatches`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json', 'Content-Type': 'application/json', 'User-Agent': 'SiteForge/1.0' },
    body: JSON.stringify({
      event_type: 'build-customer-app',
      client_payload: { site_id: siteId, callback_url: `${env.WORKER_API_URL}/api/builds/complete`, platform_api_key: env.PLATFORM_API_KEY || '' },
    }),
  });
  if (!res.ok) console.warn(`[Build] Workflow dispatch failed for ${repoName}: ${res.status}`);
}
