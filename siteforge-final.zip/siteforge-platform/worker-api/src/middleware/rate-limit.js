/**
 * Rate limiting middleware.
 * Sliding window using D1.
 */

const RATE_LIMITS = {
  '/api/auth/send-otp':    { max: 5,   windowMs: 15 * 60 * 1000 },
  '/api/auth/verify-otp':  { max: 10,  windowMs: 15 * 60 * 1000 },
  default:                 { max: 200, windowMs: 60 * 1000 },
};

export async function checkRateLimit(request, env) {
  const db = env.DB;
  if (!db) return { allowed: true };

  const url = new URL(request.url);
  const pathname = url.pathname;
  const config = RATE_LIMITS[pathname] || RATE_LIMITS.default;

  const identifier = getClientIP(request);
  const now = Date.now();
  const windowStart = new Date(now - config.windowMs).toISOString();

  try {
    const existing = await db.prepare(
      'SELECT SUM(hits) as total FROM rate_limits WHERE identifier = ? AND endpoint = ? AND window_start >= ?'
    ).bind(identifier, pathname, windowStart).first();

    const total = existing?.total || 0;

    if (total >= config.max) {
      const retryAfter = Math.ceil(config.windowMs / 1000);
      return { allowed: false, retryAfter, error: `Rate limit exceeded. Try again in ${retryAfter} seconds.` };
    }

    const currentWindow = new Date(now).toISOString();
    await db.prepare(
      'INSERT INTO rate_limits (identifier, endpoint, hits, window_start) VALUES (?, ?, 1, ?) ON CONFLICT(identifier, endpoint, window_start) DO UPDATE SET hits = hits + 1'
    ).bind(identifier, pathname, currentWindow).run();

    return { allowed: true };
  } catch (e) {
    // Don't block on rate limit errors
    console.error('[RateLimit] Error:', e.message);
    return { allowed: true };
  }
}

function getClientIP(request) {
  return request.headers.get('CF-Connecting-IP') ||
         request.headers.get('X-Forwarded-For') ||
         request.headers.get('X-Real-IP') ||
         'unknown';
}
