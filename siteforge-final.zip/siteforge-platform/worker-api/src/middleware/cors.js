/**
 * CORS middleware.
 */

const ALLOWED_ORIGINS = [
  'https://siteforge.pages.dev',
  'https://siteforge.co.zw',
  'https://app.siteforge.co.zw',
  'http://localhost:3000',
  'http://localhost:5173',
  'capacitor://localhost',
  'ionic://localhost',
  'http://localhost',
];

const CORS_HEADERS = {
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Allow-Credentials': 'true',
};

function getAllowedOrigin(origin) {
  if (!origin) return '*';
  if (ALLOWED_ORIGINS.includes(origin)) return origin;
  // Allow *.siteforge.co.zw
  if (/^https:\/\/[a-z0-9-]+\.siteforge\.co\.zw$/.test(origin)) return origin;
  return ALLOWED_ORIGINS[0];
}

export function handleCORS(request) {
  const origin = request.headers.get('Origin');
  return new Response(null, {
    status: 204,
    headers: { 'Access-Control-Allow-Origin': getAllowedOrigin(origin), ...CORS_HEADERS },
  });
}

export function addCORSHeaders(response, request) {
  const origin = request.headers.get('Origin');
  const newHeaders = new Headers(response.headers);
  newHeaders.set('Access-Control-Allow-Origin', getAllowedOrigin(origin));
  newHeaders.set('Access-Control-Allow-Credentials', 'true');
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers: newHeaders });
}
