/**
 * Templates handlers — list and get template details.
 */

import { success, error } from './utils/response.js';

const TEMPLATE_CATALOG = [
  { id: 'restaurant-1', name: 'Classic Bistro',       category: 'restaurant',   description: 'Warm, image-rich design for restaurants and takeaways.',         thumbnail: '/templates/restaurant-1/thumbnail.jpg', pages: ['home','about','menu','contact'],            features: ['whatsapp_button','google_maps','menu_section','social_links'] },
  { id: 'restaurant-2', name: 'Modern Eatery',        category: 'restaurant',   description: 'Clean, modern design with bold typography for contemporary cafes.', thumbnail: '/templates/restaurant-2/thumbnail.jpg', pages: ['home','about','menu','contact'],            features: ['whatsapp_button','instagram_feed','menu_section','reservation_button'] },
  { id: 'restaurant-3', name: 'Takeaway Express',     category: 'restaurant',   description: 'Bold, colorful design for takeaway and delivery businesses.',      thumbnail: '/templates/restaurant-3/thumbnail.jpg', pages: ['home','menu','contact'],                   features: ['whatsapp_button','menu_section','order_button'] },
  { id: 'salon-1',      name: 'Elegance Salon',       category: 'salon',        description: 'Elegant design for hair and beauty salons.',                       thumbnail: '/templates/salon-1/thumbnail.jpg',      pages: ['home','services','gallery','contact'],      features: ['whatsapp_button','booking_button','gallery','price_list'] },
  { id: 'salon-2',      name: 'Modern Cuts',          category: 'salon',        description: 'Sleek, modern design for barbershops and modern salons.',           thumbnail: '/templates/salon-2/thumbnail.jpg',      pages: ['home','services','contact'],               features: ['whatsapp_button','booking_button','price_list'] },
  { id: 'church-1',     name: 'Grace Fellowship',     category: 'church',       description: 'Warm, welcoming design for churches and ministries.',              thumbnail: '/templates/church-1/thumbnail.jpg',     pages: ['home','about','events','contact'],          features: ['donate_button','events_calendar','social_links','youtube_embed'] },
  { id: 'church-2',     name: 'City Worship',         category: 'church',       description: 'Bold design for contemporary churches.',                           thumbnail: '/templates/church-2/thumbnail.jpg',     pages: ['home','about','contact'],                  features: ['donate_button','youtube_embed','social_links'] },
  { id: 'retail-1',     name: 'ShopFront',            category: 'retail',       description: 'Clean retail design with product showcase grid.',                  thumbnail: '/templates/retail-1/thumbnail.jpg',     pages: ['home','products','about','contact'],        features: ['product_grid','whatsapp_button','social_links'] },
  { id: 'retail-2',     name: 'Market Stall',         category: 'retail',       description: 'Bold, colorful design for market stalls.',                         thumbnail: '/templates/retail-2/thumbnail.jpg',     pages: ['home','products','contact'],               features: ['product_grid','whatsapp_button','price_display'] },
  { id: 'portfolio-1',  name: 'Creative Portfolio',   category: 'portfolio',    description: 'Minimal portfolio design for creatives and freelancers.',           thumbnail: '/templates/portfolio-1/thumbnail.jpg',  pages: ['home','about','contact'],                  features: ['portfolio_grid','social_links','cv_download'] },
  { id: 'professional-1', name: 'Trust & Counsel',   category: 'professional', description: 'Professional design for law firms and consulting businesses.',       thumbnail: '/templates/professional-1/thumbnail.jpg',pages: ['home','services','contact'],               features: ['contact_form','google_maps','social_links'] },
  { id: 'events-1',     name: 'Showtime',             category: 'events',       description: 'Vibrant events page for DJs, MCs, and event planners.',            thumbnail: '/templates/events-1/thumbnail.jpg',     pages: ['home','gallery','services','contact'],      features: ['gallery','video_embed','booking_button','social_links'] },
  { id: 'realestate-1', name: 'Property Showcase',    category: 'realestate',   description: 'Clean property listing design for real estate agents.',             thumbnail: '/templates/realestate-1/thumbnail.jpg', pages: ['home','about','contact'],                  features: ['property_grid','google_maps','whatsapp_button','contact_form'] },
  { id: 'education-1',  name: 'Learn Hub',            category: 'education',    description: 'Friendly design for tutors and training providers.',                thumbnail: '/templates/education-1/thumbnail.jpg',  pages: ['home','about','contact'],                  features: ['course_grid','contact_form','social_links'] },
  { id: 'ngo-1',        name: 'Impact Foundation',    category: 'ngo',          description: 'Compassionate design for NGOs and charities.',                     thumbnail: '/templates/ngo-1/thumbnail.jpg',        pages: ['home','about','contact'],                  features: ['donate_button','impact_stories','social_links'] },
];

async function getMergedCatalog(env) {
  try {
    const dynamic = await env.CONTENT_CACHE.get('template-catalog');
    if (dynamic) {
      const parsed = JSON.parse(dynamic);
      const ids = new Set(TEMPLATE_CATALOG.map(t => t.id));
      return [...TEMPLATE_CATALOG, ...parsed.filter(t => !ids.has(t.id))];
    }
  } catch (e) { /* fallthrough */ }
  return TEMPLATE_CATALOG;
}

export async function handleListTemplates(request) {
  const url = new URL(request.url);
  const category = url.searchParams.get('category');
  const search = url.searchParams.get('search')?.toLowerCase();

  let catalog = await getMergedCatalog(request.env);

  if (category && category !== 'all') catalog = catalog.filter(t => t.category === category);
  if (search) catalog = catalog.filter(t => t.name.toLowerCase().includes(search) || t.description.toLowerCase().includes(search) || t.category.toLowerCase().includes(search));

  const categories = [...new Set((await getMergedCatalog(request.env)).map(t => t.category))];

  return success({ templates: catalog, categories, total: catalog.length });
}

export async function handleGetTemplate(request) {
  const templateId = request.params.id;
  const catalog = await getMergedCatalog(request.env);
  const template = catalog.find(t => t.id === templateId);

  if (!template) return error('Template not found', 404);

  return success({ template: { ...template, defaultContent: getDefaultContent(templateId) } });
}

function getDefaultContent(templateId) {
  const category = templateId.split('-')[0];
  const defaults = {
    restaurant: { site_name: 'Our Restaurant', hero_headline: 'Fresh Food, Great Taste', hero_subheadline: 'Serving Harare since 2005', about_text: 'We are a family-owned restaurant serving the community.', phone: '+263 77 123 4567', whatsapp: '+263771234567', address: '123 Samora Machel Ave, Harare', email: 'hello@ourrestaurant.co.zw' },
    salon:       { site_name: 'Elegance Salon', hero_headline: 'Look Your Best', hero_subheadline: 'Professional hair and beauty in Harare', about_text: 'Premium hair and beauty services in a relaxing environment.', phone: '+263 77 123 4567', whatsapp: '+263771234567', address: '45 Julius Nyerere Way, Harare', email: '' },
    church:      { site_name: 'Grace Fellowship', hero_headline: 'Welcome Home', hero_subheadline: 'A place to belong, believe, and become', about_text: 'Join us every Sunday at 9am and 11am for worship.', phone: '+263 77 123 4567', whatsapp: '+263771234567', address: '78 Church Road, Harare', email: 'info@gracefellowship.co.zw' },
    retail:      { site_name: 'ShopFront', hero_headline: 'Quality Products, Great Prices', hero_subheadline: 'Your trusted retail store', about_text: 'We stock a wide range of products at competitive prices.', phone: '+263 77 123 4567', whatsapp: '+263771234567', address: '10 Market Street, Harare', email: 'shop@shopfront.co.zw' },
    portfolio:   { site_name: 'My Portfolio', hero_headline: 'Creative Work', hero_subheadline: 'Designer, Developer, Creator', about_text: 'I create beautiful digital experiences.', phone: '+263 77 123 4567', whatsapp: '+263771234567', email: 'hello@myportfolio.co.zw' },
    professional:{ site_name: 'Trust & Counsel', hero_headline: 'Expert Legal Services', hero_subheadline: 'Trusted advisors for your legal needs', about_text: 'Expert legal counsel with integrity and professionalism.', phone: '+263 77 123 4567', whatsapp: '+263771234567', address: '5 Legal Row, Harare', email: 'info@trustandcounsel.co.zw' },
    events:      { site_name: 'Showtime Events', hero_headline: 'Unforgettable Events', hero_subheadline: 'Planning and production for every occasion', about_text: 'We make your special moments extraordinary.', phone: '+263 77 123 4567', whatsapp: '+263771234567', email: 'book@showtime.co.zw' },
    realestate:  { site_name: 'Property Showcase', hero_headline: 'Find Your Dream Home', hero_subheadline: 'Premium properties in Harare', about_text: 'We help you find the perfect property.', phone: '+263 77 123 4567', whatsapp: '+263771234567', email: 'sales@propertyshowcase.co.zw', address: '22 Estate Road, Harare' },
    education:   { site_name: 'Learn Hub', hero_headline: 'Learn Without Limits', hero_subheadline: 'Quality education for everyone', about_text: 'Accessible learning resources for students of all ages.', phone: '+263 77 123 4567', whatsapp: '+263771234567', email: 'hello@learnhub.co.zw', address: '3 College Road, Harare' },
    ngo:         { site_name: 'Impact Foundation', hero_headline: 'Making a Difference', hero_subheadline: 'Empowering communities across Zimbabwe', about_text: 'We work to create lasting change in underserved communities.', phone: '+263 77 123 4567', whatsapp: '+263771234567', email: 'info@impactfoundation.org.zw', address: '15 Hope Street, Harare' },
  };
  return { ...(defaults[category] || defaults.restaurant), hero_image: '', facebook_url: '', instagram_url: '', footer_text: `© ${new Date().getFullYear()} All rights reserved.` };
}
