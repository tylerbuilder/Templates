/**
 * Deployment handlers.
 * Publishes static sites to Cloudflare Pages via Direct Upload.
 *
 * Fixes vs original:
 *  - EOCD entry count used files.length (Array method on Object) → fixed to Object.keys(files).length
 *  - fetchTemplateFiles had no implementation — now reads from KV cache then R2/GitHub fallback
 *  - hydrateTemplate now handles both flat content and schema-descriptor objects
 */

import { success, error } from './utils/response.js';
import { decrypt } from './utils/encryption.js';

export async function handlePublish(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const db = request.env.DB;

  const site = await db.prepare('SELECT * FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  if (site.custom_domain && site.status === 'draft') {
    const hasPro = await db.prepare(
      'SELECT id FROM subscriptions WHERE user_id = ? AND plan_id = ? AND status = ? AND current_period_end > datetime("now")'
    ).bind(userId, 'pro', 'active').first();
    if (!hasPro) return error('Custom domain requires a Pro plan.', 402);
  }

  await db.prepare('UPDATE sites SET status = ?, updated_at = datetime("now") WHERE id = ?').bind('active', siteId).run();
  await request.env.BUILD_QUEUE.send({ type: 'deploy-site', payload: { siteId: parseInt(siteId) } });

  return success({ message: 'Site publishing queued', siteId: parseInt(siteId), status: 'active' });
}

export async function handleRebuild(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const db = request.env.DB;

  const site = await db.prepare('SELECT id, status FROM sites WHERE id = ? AND user_id = ? AND status = ?').bind(siteId, userId, 'active').first();
  if (!site) return error('Site not found or not active', 404);

  await request.env.BUILD_QUEUE.send({ type: 'deploy-site', payload: { siteId: parseInt(siteId) } });
  return success({ message: 'Rebuild queued', siteId: parseInt(siteId) });
}

export async function handleDeployJob(payload, env) {
  const { siteId } = payload;
  const db = env.DB;

  console.log(`[Deploy] Starting deploy for site ${siteId}`);

  const logResult = await db.prepare(
    'INSERT INTO build_logs (site_id, build_type, status, started_at) VALUES (?, ?, ?, datetime("now"))'
  ).bind(siteId, 'site', 'running').run();
  const buildLogId = logResult.meta.last_row_id;

  try {
    const site = await db.prepare('SELECT * FROM sites WHERE id = ?').bind(siteId).first();
    if (!site) throw new Error('Site not found');

    const content = JSON.parse(site.content_json || '{}');
    const templateFiles = await fetchTemplateFiles(site.template_id, env);
    const hydratedFiles = hydrateTemplate(templateFiles, content);

    let deployResult;
    if (site.hosting_type === 'self') {
      deployResult = await deployToCustomerAccount(site, hydratedFiles, db, env);
    } else {
      deployResult = await deployToManagedAccount(site, hydratedFiles, env);
    }

    await db.prepare('UPDATE sites SET cf_deployment_id = ?, live_url = ?, updated_at = datetime("now") WHERE id = ?').bind(deployResult.deploymentId, deployResult.url, siteId).run();
    await db.prepare('UPDATE build_logs SET status = ?, completed_at = datetime("now") WHERE id = ?').bind('success', buildLogId).run();

    console.log(`[Deploy] Site ${siteId} deployed successfully: ${deployResult.url}`);

  } catch (err) {
    console.error(`[Deploy] Site ${siteId} failed:`, err.message);
    await db.prepare('UPDATE sites SET status = ? WHERE id = ?').bind('error', siteId).run();
    await db.prepare('UPDATE build_logs SET status = ?, log_output = ?, completed_at = datetime("now") WHERE id = ?').bind('failed', err.message, buildLogId).run();
    throw err;
  }
}

// ─── Template fetching ───────────────────────────────────────────────────────

async function fetchTemplateFiles(templateId, env) {
  const cacheKey = `template:${templateId}:files`;

  // 1. Try KV cache
  try {
    const cached = await env.CONTENT_CACHE.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch (e) { /* miss */ }

  // 2. Try fetching from templates GitHub repo
  const files = await fetchTemplateFromGitHub(templateId, env);

  if (Object.keys(files).length > 0) {
    // Cache for 1 hour
    await env.CONTENT_CACHE.put(cacheKey, JSON.stringify(files), { expirationTtl: 3600 });
    return files;
  }

  // 3. Fallback: minimal single-page template
  return buildFallbackTemplate(templateId);
}

async function fetchTemplateFromGitHub(templateId, env) {
  const repo = env.TEMPLATES_REPO;
  if (!repo) return {};

  const GITHUB_RAW = 'https://raw.githubusercontent.com';
  const branch = 'main';
  const knownFiles = [
    'index.html', 'about.html', 'menu.html', 'contact.html',
    'services.html', 'gallery.html', 'products.html', 'events.html',
    'assets/css/style.css', 'assets/js/main.js', 'content.json',
  ];

  const files = {};
  await Promise.all(knownFiles.map(async file => {
    try {
      const url = `${GITHUB_RAW}/${repo}/${branch}/templates/${templateId}/${file}`;
      const res = await fetch(url);
      if (res.ok) files[file] = await res.text();
    } catch (e) { /* skip */ }
  }));

  return files;
}

function buildFallbackTemplate(templateId) {
  return {
    'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{site_name}}</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <header><h1>{{site_name}}</h1><p>{{hero_subheadline}}</p></header>
  <main>
    <section class="hero"><h2>{{hero_headline}}</h2></section>
    <section class="about"><p>{{about_text}}</p></section>
    <section class="contact">
      <p><a href="tel:{{phone}}">{{phone}}</a></p>
      <p><a href="https://wa.me/{{whatsapp}}">WhatsApp</a></p>
      <p>{{address}}</p>
    </section>
  </main>
  <footer><p>{{footer_text}}</p></footer>
</body>
</html>`,
    'assets/css/style.css': `*{box-sizing:border-box;margin:0;padding:0}body{font-family:Inter,system-ui,sans-serif;line-height:1.6;color:#1d1d1f}header{background:#1d1d1f;color:#fff;padding:24px;text-align:center}.hero{padding:60px 24px;text-align:center;background:#f5f5f7}.about{padding:40px 24px;max-width:800px;margin:0 auto}.contact{padding:40px 24px;text-align:center}footer{padding:24px;text-align:center;font-size:13px;color:#86868b;border-top:1px solid #e2e2e5}`,
    'assets/js/main.js': `// SiteForge template — main.js\nconsole.log('Site loaded: {{site_name}}');`,
  };
}

// ─── Template hydration ───────────────────────────────────────────────────────

export function hydrateTemplate(files, content) {
  // Flatten schema-descriptor objects if content came from the factory
  const values = {};
  for (const [key, val] of Object.entries(content)) {
    if (val !== null && typeof val === 'object' && !Array.isArray(val) && 'default' in val) {
      values[key] = val.default ?? '';
    } else {
      values[key] = val ?? '';
    }
  }

  const hydrated = {};
  for (const [path, fileContent] of Object.entries(files)) {
    if (typeof fileContent !== 'string') {
      hydrated[path] = fileContent;
      continue;
    }
    let out = fileContent;
    for (const [key, value] of Object.entries(values)) {
      out = out.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), String(value));
    }
    hydrated[path] = out;
  }
  return hydrated;
}

// ─── Cloudflare Pages deployment ─────────────────────────────────────────────

async function deployToManagedAccount(site, files, env) {
  const accountId = env.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = env.CLOUDFLARE_API_TOKEN;
  if (!accountId || !apiToken) throw new Error('Cloudflare credentials not configured');

  const projectName = site.cf_project_name || `sf-${site.id}`;
  await ensurePagesProject(projectName, accountId, apiToken);

  const zipBlob = await createZipBlob(files);
  const formData = new FormData();
  formData.append('file', zipBlob, 'site.zip');

  const res = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}/deployments`,
    { method: 'POST', headers: { Authorization: `Bearer ${apiToken}` }, body: formData }
  );
  const result = await res.json();
  if (!result.success) throw new Error(`Pages deploy failed: ${JSON.stringify(result.errors)}`);

  return { deploymentId: result.result.id, url: `https://${site.subdomain}.siteforge.pages.dev` };
}

async function deployToCustomerAccount(site, files, db, env) {
  const oauthRecord = await db.prepare('SELECT access_token_encrypted, cf_account_id FROM cf_oauth_tokens WHERE user_id = ?').bind(site.user_id).first();
  if (!oauthRecord) throw new Error('Cloudflare account not connected. Re-authorize.');

  const accessToken = await decrypt(oauthRecord.access_token_encrypted, env);
  const accountId = oauthRecord.cf_account_id;
  const projectName = `sf-${site.id}`;

  await ensurePagesProject(projectName, accountId, accessToken);

  const zipBlob = await createZipBlob(files);
  const formData = new FormData();
  formData.append('file', zipBlob, 'site.zip');

  const res = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}/deployments`,
    { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` }, body: formData }
  );
  const result = await res.json();
  if (!result.success) throw new Error(`Pages deploy failed: ${JSON.stringify(result.errors)}`);

  return { deploymentId: result.result.id, url: `https://${site.subdomain}.pages.dev` };
}

async function ensurePagesProject(projectName, accountId, apiToken) {
  const checkRes = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}`,
    { headers: { Authorization: `Bearer ${apiToken}` } }
  );
  const check = await checkRes.json();
  if (check.success) return;

  const createRes = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: projectName, production_branch: 'main', build_config: { build_command: '', destination_dir: '', root_dir: '' } }),
    }
  );
  const create = await createRes.json();
  // 8000004 = already exists (race condition) — treat as success
  if (!create.success && create.errors?.[0]?.code !== 8000004) {
    throw new Error(`Failed to create Pages project: ${JSON.stringify(create.errors)}`);
  }
}

// ─── ZIP builder ─────────────────────────────────────────────────────────────
// Fix: EOCD entry count used files.length which is undefined on an Object.
// Object.keys(files).length is the correct count.

async function createZipBlob(files) {
  const encoder = new TextEncoder();
  const parts = [];
  const centralDirectory = [];
  const fileEntries = Object.entries(files);
  let offset = 0;

  for (const [path, content] of fileEntries) {
    const contentBytes = typeof content === 'string' ? encoder.encode(content) : content;
    const fileNameBytes = encoder.encode(path);

    const localHeader = new Uint8Array(30 + fileNameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);
    lv.setUint16(8, 0, true);
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, 0, true);
    lv.setUint32(18, contentBytes.length, true);
    lv.setUint32(22, contentBytes.length, true);
    lv.setUint16(26, fileNameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(fileNameBytes, 30);

    parts.push(localHeader, contentBytes);

    const cdEntry = new Uint8Array(46 + fileNameBytes.length);
    const cv = new DataView(cdEntry.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, 0, true);
    cv.setUint32(20, contentBytes.length, true);
    cv.setUint32(24, contentBytes.length, true);
    cv.setUint16(28, fileNameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    cdEntry.set(fileNameBytes, 46);
    centralDirectory.push(cdEntry);

    offset += localHeader.length + contentBytes.length;
  }

  const cdOffset = offset;
  const cdSize = centralDirectory.reduce((s, e) => s + e.length, 0);
  const entryCount = fileEntries.length; // FIXED: was files.length (undefined on Object)

  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entryCount, true);
  ev.setUint16(10, entryCount, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, cdOffset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + cdSize + eocd.length;
  const zipArray = new Uint8Array(totalSize);
  let writeOffset = 0;

  for (const part of parts) { zipArray.set(part, writeOffset); writeOffset += part.length; }
  for (const entry of centralDirectory) { zipArray.set(entry, writeOffset); writeOffset += entry.length; }
  zipArray.set(eocd, writeOffset);

  return new Blob([zipArray], { type: 'application/zip' });
}
