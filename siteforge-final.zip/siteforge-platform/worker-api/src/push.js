/**
 * Push notification handlers — Firebase Cloud Messaging.
 */

import { success, error, parseBody, validateRequired } from './utils/response.js';

const LIMITS = { push_small: { campaigns: 5, recipients: 500 }, push_medium: { campaigns: 15, recipients: 2000 }, push_large: { campaigns: 999999, recipients: 10000 } };

export async function handleRegisterDevice(request) {
  const body = await parseBody(request);
  if (!body) return error('Invalid body', 400);
  const missing = validateRequired(body, ['siteId', 'fcmToken']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const db = request.env.DB;
  const site = await db.prepare('SELECT id, has_native_app FROM sites WHERE id = ? AND status = ?').bind(body.siteId, 'active').first();
  if (!site) return error('Site not found', 404);
  if (!site.has_native_app) return error('This site does not have a native app', 400);

  const existing = await db.prepare('SELECT id FROM push_subscribers WHERE site_id = ? AND fcm_token = ?').bind(body.siteId, body.fcmToken).first();
  if (existing) {
    await db.prepare('UPDATE push_subscribers SET last_seen_at = datetime("now"), is_active = 1 WHERE id = ?').bind(existing.id).run();
  } else {
    await db.prepare('INSERT INTO push_subscribers (site_id, fcm_token, app_install_id) VALUES (?, ?, ?)').bind(body.siteId, body.fcmToken, body.appInstallId || null).run();
  }

  return success({ message: 'Device registered', siteId: parseInt(body.siteId) });
}

export async function handleSendPush(request) {
  const userId = request.userId;
  const body = await parseBody(request);
  if (!body) return error('Invalid body', 400);
  const missing = validateRequired(body, ['siteId', 'title', 'message']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const db = request.env.DB;
  const site = await db.prepare('SELECT id, has_native_app FROM sites WHERE id = ? AND user_id = ? AND status = ?').bind(body.siteId, userId, 'active').first();
  if (!site) return error('Site not found', 404);
  if (!site.has_native_app) return error('No native app for this site', 402);

  const pushSub = await db.prepare(
    `SELECT s.plan_id FROM subscriptions s WHERE s.user_id = ? AND s.site_id = ? AND s.plan_id LIKE 'push_%' AND s.status = 'active' AND s.current_period_end > datetime('now') LIMIT 1`
  ).bind(userId, body.siteId).first();
  if (!pushSub) return error('No active push subscription.', 402);

  const planLimit = LIMITS[pushSub.plan_id];
  const monthCampaigns = await db.prepare(
    `SELECT COUNT(*) as count FROM push_campaigns WHERE site_id = ? AND created_at >= datetime('now', 'start of month')`
  ).bind(body.siteId).first();

  if (monthCampaigns.count >= planLimit.campaigns) return error(`Monthly campaign limit (${planLimit.campaigns}) reached.`, 429);

  const subCount = await db.prepare('SELECT COUNT(*) as count FROM push_subscribers WHERE site_id = ? AND is_active = 1').bind(body.siteId).first();
  if (subCount.count === 0) return error('No active subscribers', 400);
  if (subCount.count > planLimit.recipients) return error(`Recipient limit (${planLimit.recipients}) exceeded.`, 429);

  const campaignResult = await db.prepare(
    `INSERT INTO push_campaigns (site_id, user_id, title, message, target_url, status) VALUES (?, ?, ?, ?, ?, 'sending')`
  ).bind(body.siteId, userId, body.title, body.message, body.targetUrl || null).run();

  await request.env.BUILD_QUEUE.send({ type: 'send-push-campaign', payload: { campaignId: campaignResult.meta.last_row_id } });
  return success({ message: 'Campaign queued', campaignId: campaignResult.meta.last_row_id, estimatedRecipients: subCount.count });
}

export async function handleListCampaigns(request) {
  const userId = request.userId;
  const url = new URL(request.url);
  const siteId = url.searchParams.get('siteId');
  if (!siteId) return error('siteId is required', 400);

  const db = request.env.DB;
  const campaigns = await db.prepare(
    `SELECT pc.*, (SELECT COUNT(*) FROM push_subscribers WHERE site_id = ? AND is_active = 1) as subscriber_count
     FROM push_campaigns pc WHERE pc.site_id = ? AND pc.user_id = ? ORDER BY pc.created_at DESC LIMIT 50`
  ).bind(siteId, siteId, userId).all();

  return success({ campaigns: campaigns.results, total: campaigns.results.length });
}

export async function handlePushJob(payload, env) {
  const { campaignId } = payload;
  const db = env.DB;
  const fcmServerKey = env.FCM_SERVER_KEY;

  if (!fcmServerKey) {
    await db.prepare('UPDATE push_campaigns SET status = ? WHERE id = ?').bind('failed', campaignId).run();
    return;
  }

  const campaign = await db.prepare('SELECT * FROM push_campaigns WHERE id = ?').bind(campaignId).first();
  if (!campaign) return;

  const subscribers = await db.prepare('SELECT fcm_token FROM push_subscribers WHERE site_id = ? AND is_active = 1').bind(campaign.site_id).all();

  let sentCount = 0;
  // FCM recommends batching up to 500 tokens per request — send individually here for clarity; batch in production
  for (const sub of subscribers.results) {
    try {
      const res = await fetch('https://fcm.googleapis.com/fcm/send', {
        method: 'POST',
        headers: { Authorization: `key=${fcmServerKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: sub.fcm_token,
          notification: { title: campaign.title, body: campaign.message },
          data: { target_url: campaign.target_url || '', campaign_id: String(campaignId), site_id: String(campaign.site_id) },
        }),
      });
      const result = await res.json();
      if (result.success) {
        sentCount++;
      } else if (result.results?.[0]?.error === 'NotRegistered') {
        await db.prepare('UPDATE push_subscribers SET is_active = 0 WHERE fcm_token = ?').bind(sub.fcm_token).run();
      }
    } catch (e) {
      console.error('[Push] Send error:', e.message);
    }
  }

  await db.prepare('UPDATE push_campaigns SET status = ?, sent_at = datetime("now"), delivered_count = ? WHERE id = ?').bind('sent', sentCount, campaignId).run();
  console.log(`[Push] Campaign ${campaignId}: ${sentCount}/${subscribers.results.length} delivered`);
}
