/**
 * Admin bootstrap endpoints.
 * POST /api/admin/provision — run initial setup (idempotent).
 * GET  /api/admin/status   — health + config check.
 *
 * Both are protected by the CRON_SECRET header.
 */

import { success, error } from './utils/response.js';

function isAuthorized(request) {
  const secret = request.env.CRON_SECRET;
  if (!secret) return false;
  return request.headers.get('Authorization') === `Bearer ${secret}`;
}

export async function handleProvision(request) {
  if (!isAuthorized(request)) return error('Unauthorized', 401);

  const env = request.env;
  const results = [];

  // Clean expired rate limit rows
  try {
    const windowCutoff = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    await env.DB.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(windowCutoff).run();
    results.push('Pruned rate_limits');
  } catch (e) { results.push(`rate_limits prune failed: ${e.message}`); }

  // Clean expired/revoked auth tokens
  try {
    await env.DB.prepare(`DELETE FROM auth_tokens WHERE expires_at < datetime('now', '-1 day') OR revoked_at IS NOT NULL`).run();
    results.push('Pruned auth_tokens');
  } catch (e) { results.push(`auth_tokens prune failed: ${e.message}`); }

  // Clean used OTPs
  try {
    await env.DB.prepare(`DELETE FROM otp_codes WHERE used_at IS NOT NULL OR expires_at < datetime('now')`).run();
    results.push('Pruned otp_codes');
  } catch (e) { results.push(`otp_codes prune failed: ${e.message}`); }

  // Reset monthly app rebuild counters on first of month
  try {
    const now = new Date();
    if (now.getDate() === 1) {
      await env.DB.prepare('UPDATE sites SET app_rebuilds_this_month = 0').run();
      results.push('Reset app_rebuilds_this_month');
    }
  } catch (e) { results.push(`rebuild reset failed: ${e.message}`); }

  return success({ message: 'Provision complete', results });
}

export async function handleStatus(request) {
  if (!isAuthorized(request)) return error('Unauthorized', 401);

  const env = request.env;
  const checks = {};

  try {
    await env.DB.prepare('SELECT 1').run();
    checks.db = 'ok';
  } catch (e) { checks.db = `error: ${e.message}`; }

  try {
    await env.CONTENT_CACHE.get('_health');
    checks.kv = 'ok';
  } catch (e) { checks.kv = `error: ${e.message}`; }

  checks.paynow     = env.PAYNOW_INTEGRATION_ID    ? 'configured' : 'missing';
  checks.github_app = env.GITHUB_APP_ID             ? 'configured' : 'missing';
  checks.cloudflare = env.CLOUDFLARE_API_TOKEN      ? 'configured' : 'missing';
  checks.fcm        = env.FCM_SERVER_KEY            ? 'configured' : 'missing';
  checks.encryption = env.ENCRYPTION_KEY            ? 'configured' : 'missing';

  const allOk = Object.values(checks).every(v => v === 'ok' || v === 'configured');

  return success({ status: allOk ? 'healthy' : 'degraded', checks, timestamp: new Date().toISOString() });
}
