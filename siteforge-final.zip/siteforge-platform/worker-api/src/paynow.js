/**
 * Paynow integration — EcoCash, OneMoney, Visa/Mastercard.
 */

import { success, error, parseBody, validateRequired } from './utils/response.js';
import { sha256 } from './utils/encryption.js';

const PAYNOW_INITIATE_URL = 'https://www.paynow.co.zw/interface/initiatetransaction';
const PAYNOW_RECURRING_URL = 'https://www.paynow.co.zw/interface/recurringtransaction';

const PLAN_AMOUNTS = { pro: 3.00, native_app: 30.00, push_small: 3.00, push_medium: 6.00, push_large: 12.00 };
const VALID_PLANS = Object.keys(PLAN_AMOUNTS);

export async function handleInitiatePayment(request) {
  const userId = request.userId;
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const missing = validateRequired(body, ['planId']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);
  if (!VALID_PLANS.includes(body.planId)) return error('Invalid plan', 400);

  const db = request.env.DB;
  const integrationId = request.env.PAYNOW_INTEGRATION_ID;
  const integrationSecret = request.env.PAYNOW_INTEGRATION_SECRET;
  if (!integrationId || !integrationSecret) return error('Payment not configured', 500);

  const amount = PLAN_AMOUNTS[body.planId];
  const billingCycle = body.planId === 'native_app' ? 'annual' : 'monthly';
  const reference = `SF-${userId}-${Date.now().toString(36).toUpperCase()}`;

  const hashString = `${integrationId}${reference}${amount.toFixed(2)}${integrationSecret}`;
  const hash = (await sha256(hashString)).toUpperCase();

  const formData = new URLSearchParams();
  formData.set('id', integrationId);
  formData.set('reference', reference);
  formData.set('amount', amount.toFixed(2));
  formData.set('hash', hash);
  formData.set('returnurl', `${request.env.PLATFORM_URL}/payment/complete?ref=${reference}`);
  formData.set('resulturl', `${request.env.WORKER_API_URL}/api/paynow/callback`);
  if (body.email) formData.set('email', body.email);
  if (body.siteId) formData.set('custom1', String(body.siteId));

  try {
    const res = await fetch(PAYNOW_INITIATE_URL, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: formData.toString() });
    const responseText = await res.text();
    const params = new URLSearchParams(responseText);

    const status = params.get('status');
    const browserUrl = params.get('browserurl');

    if (status !== 'Ok' || !browserUrl) return error(params.get('error') || 'Payment initiation failed', 400);

    const verifyHash = (await sha256(`${integrationId}${reference}${status}${integrationSecret}`)).toUpperCase();
    if (params.get('hash') !== verifyHash) return error('Hash verification failed', 400);

    await db.prepare(
      `INSERT INTO payments (user_id, paynow_reference, amount, currency, status, paynow_response) VALUES (?, ?, ?, 'USD', 'pending', ?)`
    ).bind(userId, reference, amount, responseText).run();

    return success({ reference, browserUrl, pollUrl: params.get('pollurl'), amount, currency: 'USD', planId: body.planId, billingCycle });
  } catch (err) {
    console.error('[Paynow] Initiation error:', err.message);
    return error('Payment service unavailable. Please try again.', 503);
  }
}

export async function handlePaymentCallback(request) {
  const body = await request.text();
  const params = new URLSearchParams(body);
  const status = params.get('status');
  const reference = params.get('reference');
  const paynowReference = params.get('paynowreference');
  const hash = params.get('hash');

  const integrationId = request.env.PAYNOW_INTEGRATION_ID;
  const integrationSecret = request.env.PAYNOW_INTEGRATION_SECRET;
  const expectedHash = (await sha256(`${integrationId}${reference}${status}${paynowReference}${integrationSecret}`)).toUpperCase();

  if (hash !== expectedHash) return error('Hash verification failed', 400);

  const db = request.env.DB;
  const payment = await db.prepare('SELECT id, user_id, amount FROM payments WHERE paynow_reference = ?').bind(reference).first();
  if (!payment) return error('Payment not found', 404);

  await db.prepare(`UPDATE payments SET status = ?, paynow_response = paynow_response || ? WHERE id = ?`).bind(status === 'Paid' ? 'paid' : 'failed', '\nCB: ' + body, payment.id).run();

  if (status === 'Paid') {
    const siteId = params.get('custom1');
    await activateSubscription(payment.user_id, siteId, parseFloat(params.get('amount')), reference, db, request.env);
  }

  return new Response('OK', { status: 200, headers: { 'Content-Type': 'text/plain' } });
}

export async function handlePaymentStatus(request) {
  const userId = request.userId;
  const reference = request.params.ref;
  const db = request.env.DB;

  const payment = await db.prepare('SELECT id, status, amount, paynow_reference FROM payments WHERE paynow_reference = ? AND user_id = ?').bind(reference, userId).first();
  if (!payment) return error('Payment not found', 404);

  return success({ reference: payment.paynow_reference, status: payment.status, amount: payment.amount });
}

export async function handleRecurringCharge(request) {
  const authHeader = request.headers.get('Authorization');
  if (authHeader !== `Bearer ${request.env.CRON_SECRET}`) return error('Unauthorized', 401);

  const body = await parseBody(request);
  if (!body?.subscriptionId) return error('subscriptionId is required', 400);

  const db = request.env.DB;
  const integrationId = request.env.PAYNOW_INTEGRATION_ID;
  const integrationSecret = request.env.PAYNOW_INTEGRATION_SECRET;

  const subscription = await db.prepare('SELECT * FROM subscriptions WHERE id = ? AND status = ?').bind(body.subscriptionId, 'active').first();
  if (!subscription) return error('Active subscription not found', 404);
  if (!subscription.paynow_token) return error('No recurring token', 400);

  const reference = `RENEWAL-${subscription.id}-${Date.now().toString(36).toUpperCase()}`;

  try {
    const formData = new URLSearchParams();
    formData.set('id', integrationId);
    formData.set('token', subscription.paynow_token);
    formData.set('amount', subscription.amount.toFixed(2));
    formData.set('reference', reference);
    formData.set('resulturl', `${request.env.WORKER_API_URL}/api/paynow/callback`);

    const res = await fetch(PAYNOW_RECURRING_URL, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: formData.toString() });
    const responseText = await res.text();
    const status = new URLSearchParams(responseText).get('status');

    if (status === 'Ok') {
      const newPeriodEnd = new Date();
      subscription.billing_cycle === 'annual' ? newPeriodEnd.setFullYear(newPeriodEnd.getFullYear() + 1) : newPeriodEnd.setMonth(newPeriodEnd.getMonth() + 1);
      await db.prepare('UPDATE subscriptions SET current_period_end = ?, current_period_start = datetime("now") WHERE id = ?').bind(newPeriodEnd.toISOString(), body.subscriptionId).run();
      await db.prepare(`INSERT INTO payments (user_id, subscription_id, paynow_reference, amount, currency, status, paynow_response) VALUES (?, ?, ?, ?, 'USD', 'paid', ?)`).bind(subscription.user_id, body.subscriptionId, reference, subscription.amount, responseText).run();
      return success({ message: 'Recurring charge successful', reference });
    } else {
      await db.prepare('UPDATE subscriptions SET status = ? WHERE id = ?').bind('past_due', body.subscriptionId).run();
      return error('Recurring charge failed', 402, { paynowResponse: responseText });
    }
  } catch (err) {
    console.error('[Paynow] Recurring charge error:', err.message);
    return error('Recurring charge failed', 500);
  }
}

export async function handleRenewalJob(payload, env) {
  const db = env.DB;
  const subscriptions = await db.prepare(
    `SELECT id FROM subscriptions WHERE status = 'active' AND current_period_end <= datetime('now', '+3 days') AND paynow_token IS NOT NULL`
  ).all();
  for (const sub of subscriptions.results) {
    await env.BUILD_QUEUE.send({ type: 'process-renewal', payload: { subscriptionId: sub.id } });
  }
  console.log(`[Renewal] Queued ${subscriptions.results.length} renewals`);
}

async function activateSubscription(userId, siteId, amount, paynowReference, db, env) {
  let planId = 'pro';
  if (amount >= 30) planId = 'native_app';
  else if (amount >= 12) planId = 'push_large';
  else if (amount >= 6) planId = 'push_medium';
  else if (amount >= 3) planId = 'push_small';

  await db.prepare(`UPDATE subscriptions SET status = 'expired' WHERE user_id = ? AND plan_id = ? AND status = 'active'`).bind(userId, planId).run();

  const periodEnd = new Date();
  planId === 'native_app' ? periodEnd.setFullYear(periodEnd.getFullYear() + 1) : periodEnd.setMonth(periodEnd.getMonth() + 1);
  const billingCycle = planId === 'native_app' ? 'annual' : 'monthly';

  await db.prepare(
    `INSERT INTO subscriptions (user_id, site_id, plan_id, status, paynow_reference, amount, currency, billing_cycle, current_period_start, current_period_end)
     VALUES (?, ?, ?, 'active', ?, ?, 'USD', ?, datetime('now'), ?)`
  ).bind(userId, siteId || null, planId, paynowReference, amount, billingCycle, periodEnd.toISOString()).run();

  if (planId === 'native_app' && siteId) {
    await db.prepare('UPDATE sites SET has_native_app = 1, app_build_status = ? WHERE id = ?').bind('idle', siteId).run();
    await env.BUILD_QUEUE.send({ type: 'build-apk', payload: { siteId: parseInt(siteId) } });
  }

  console.log(`[Paynow] Activated ${planId} for user ${userId}`);
}
