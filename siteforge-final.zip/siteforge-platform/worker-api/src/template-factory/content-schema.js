/**
 * Template Factory - Content Schema Generator.
 * Produces field definitions for each industry.
 * All fields include a `default` so page-assembler can resolve them immediately.
 */

import { INDUSTRIES } from './industries.js';

const BASE_FIELDS = {
  site_name:        { type: 'text',     label: 'Business Name',       default: 'My Business',             required: true },
  hero_headline:    { type: 'text',     label: 'Hero Headline',        default: 'Welcome to Our Business', required: true },
  hero_subheadline: { type: 'text',     label: 'Hero Subheadline',     default: 'Serving our community with excellence', required: false },
  hero_image:       { type: 'image',    label: 'Hero Image',           default: '',                        required: false },
  about_text:       { type: 'textarea', label: 'About Us',             default: 'We are dedicated to serving our customers with the highest quality products and services.', required: false },
  about_image:      { type: 'image',    label: 'About Image',          default: '',                        required: false },
  phone:            { type: 'tel',      label: 'Phone Number',         default: '+263 77 123 4567',        required: false },
  whatsapp:         { type: 'tel',      label: 'WhatsApp Number',      default: '+263771234567',           required: false },
  email:            { type: 'email',    label: 'Email Address',        default: '',                        required: false },
  address:          { type: 'text',     label: 'Address',              default: 'Harare, Zimbabwe',        required: false },
  facebook_url:     { type: 'url',      label: 'Facebook URL',         default: '',                        required: false },
  instagram_url:    { type: 'url',      label: 'Instagram URL',        default: '',                        required: false },
  twitter_url:      { type: 'url',      label: 'Twitter / X URL',      default: '',                        required: false },
  footer_text:      { type: 'text',     label: 'Footer Text',          default: `© ${new Date().getFullYear()} All rights reserved.`, required: true },
};

const INDUSTRY_EXTRA_FIELDS = {
  restaurant:   { menu_headline: { type: 'text', label: 'Menu Page Headline', default: 'Our Menu', required: false }, menu_pdf: { type: 'url', label: 'Menu PDF URL', default: '', required: false }, reservation_url: { type: 'url', label: 'Reservation Link', default: '', required: false } },
  takeaway:     { menu_headline: { type: 'text', label: 'Menu Headline', default: 'Order Now', required: false }, order_url: { type: 'url', label: 'Online Order Link', default: '', required: false } },
  cafe:         { menu_headline: { type: 'text', label: 'Menu Headline', default: 'Our Menu', required: false } },
  salon:        { services_headline: { type: 'text', label: 'Services Headline', default: 'Our Services', required: false }, booking_url: { type: 'url', label: 'Booking Link', default: '', required: false } },
  barbershop:   { services_headline: { type: 'text', label: 'Services Headline', default: 'Our Services', required: false }, booking_url: { type: 'url', label: 'Booking Link', default: '', required: false } },
  church:       { service_times: { type: 'text', label: 'Service Times', default: 'Sundays at 9am & 11am', required: false }, youtube_url: { type: 'url', label: 'YouTube Channel', default: '', required: false }, donate_url: { type: 'url', label: 'Donation Link', default: '', required: false } },
  ngo:          { donate_url: { type: 'url', label: 'Donation Link', default: '', required: false }, mission_statement: { type: 'textarea', label: 'Mission Statement', default: '', required: false } },
  charity:      { donate_url: { type: 'url', label: 'Donation Link', default: '', required: false } },
  retail:       { products_headline: { type: 'text', label: 'Products Headline', default: 'Our Products', required: false } },
  portfolio:    { linkedin_url: { type: 'url', label: 'LinkedIn URL', default: '', required: false }, cv_url: { type: 'url', label: 'CV / Resume URL', default: '', required: false } },
  realestate:   { google_maps_embed: { type: 'textarea', label: 'Google Maps Embed Code', default: '', required: false } },
  gym:          { membership_url: { type: 'url', label: 'Membership Sign-Up Link', default: '', required: false }, class_schedule_url: { type: 'url', label: 'Class Schedule URL', default: '', required: false } },
  clinic:       { booking_url: { type: 'url', label: 'Appointment Booking Link', default: '', required: false } },
  dentist:      { booking_url: { type: 'url', label: 'Appointment Booking Link', default: '', required: false } },
  events:       { booking_url: { type: 'url', label: 'Event Enquiry / Booking Link', default: '', required: false } },
  photography:  { instagram_url: { type: 'url', label: 'Instagram / Portfolio Link', default: '', required: false } },
  school:       { enrollment_url: { type: 'url', label: 'Enrolment Link', default: '', required: false } },
};

/**
 * Generate the content schema for an industry.
 * Returns { schema, defaultContent, fields }.
 */
export function generateContentSchema(industryId) {
  const industry = INDUSTRIES.find(i => i.id === industryId);
  if (!industry) throw new Error(`Unknown industry: ${industryId}`);

  const extraFields = INDUSTRY_EXTRA_FIELDS[industryId] || {};
  const schema = { ...BASE_FIELDS, ...extraFields };

  // Derive page-specific labels from industry name
  schema.site_name.default = `${industry.name} — My Business`;
  schema.hero_headline.default = getDefaultHeadline(industry);

  // Build flat defaultContent map (what gets stored in DB and passed to templates)
  const defaultContent = {};
  for (const [key, field] of Object.entries(schema)) {
    defaultContent[key] = field.default;
  }

  // Build ordered field list for the editor UI
  const fields = Object.entries(schema).map(([key, field]) => ({ key, ...field }));

  return { schema, defaultContent, fields };
}

function getDefaultHeadline(industry) {
  const headlines = {
    restaurant:   'Fresh Food, Great Taste',
    takeaway:     'Order Fresh, Delivered Fast',
    cafe:         'Great Coffee, Great Vibes',
    bakery:       'Freshly Baked Every Day',
    catering:     'Making Every Event Delicious',
    bar:          'Where Great Nights Happen',
    hotel:        'Your Home Away From Home',
    salon:        'Look Your Best, Every Day',
    barbershop:   'Sharp Cuts, Great Style',
    spa:          'Relax. Restore. Renew.',
    gym:          'Train Hard. Live Well.',
    church:       'Welcome Home',
    ngo:          'Making a Difference',
    charity:      'Together We Can',
    retail:       'Quality Products, Great Prices',
    law:          'Expert Legal Services',
    accounting:   'Your Numbers, Our Expertise',
    realestate:   'Find Your Dream Property',
    clinic:       'Quality Healthcare for Everyone',
    dentist:      'Healthy Smiles for All',
    portfolio:    'Creative Work That Speaks',
    events:       'Unforgettable Events',
    photography:  'Capturing Life\'s Best Moments',
    construction: 'Built to Last',
    farming:      'From Our Farm to Your Table',
    logistics:    'Reliable Delivery, Every Time',
    taxi:         'Safe. Fast. Affordable.',
  };
  return headlines[industry.id] || `Welcome to ${industry.name}`;
}

/**
 * Generate a placeholder-to-field mapping for template hydration.
 * Used at deploy-time to substitute {{key}} tokens in HTML files.
 */
export function generatePlaceholderMap(schema) {
  const map = {};
  for (const [key] of Object.entries(schema)) {
    map[`{{${key}}}`] = key;
  }
  return map;
}
