/**
 * Template Factory - Page Assembler
 *
 * Fixes vs original:
 *  1. resolveContentValues() extracts .default from schema descriptors — content is actually used
 *  2. buildCSSVariables() + buildHead() injected into EVERY page (not just home)
 *  3. buildNav() reads industry.pages dynamically on EVERY page (not hardcoded)
 *  4. assembleServicesPage, assembleGalleryPage, assembleProductsPage are real implementations
 *  5. images.hero / images.about properly flow through resolveContentValues fallback
 */

import { DESIGN_SYSTEMS } from './design-systems.js';

// ─── Public entry point ───────────────────────────────────────────────────────

export function assemblePage(pageType, industry, designSystem, content, images) {
  const design = (typeof designSystem === 'string')
    ? (DESIGN_SYSTEMS.find(d => d.id === designSystem) || DESIGN_SYSTEMS[0])
    : designSystem;

  const v = resolveContentValues(content, images);

  switch (pageType) {
    case 'home':     return assembleHomePage(industry, design, v);
    case 'about':    return assembleAboutPage(industry, design, v);
    case 'contact':  return assembleContactPage(industry, design, v);
    case 'menu':     return assembleMenuPage(industry, design, v);
    case 'services': return assembleServicesPage(industry, design, v);
    case 'gallery':  return assembleGalleryPage(industry, design, v);
    case 'products': return assembleProductsPage(industry, design, v);
    default:         return assembleHomePage(industry, design, v);
  }
}

// ─── Content resolution ───────────────────────────────────────────────────────

function resolveContentValues(content, images) {
  const v = {};
  for (const [key, field] of Object.entries(content || {})) {
    if (field === null || typeof field !== 'object' || Array.isArray(field)) {
      v[key] = field ?? '';
    } else if ('default' in field) {
      // Schema descriptor — use the default
      v[key] = field.default ?? '';
    } else {
      v[key] = '';
    }
  }
  // Fallback image keys from the images map
  if (!v.hero_image  && images?.hero)  v.hero_image  = images.hero;
  if (!v.about_image && images?.about) v.about_image = images.about;
  return v;
}

// ─── Shared helpers ───────────────────────────────────────────────────────────

function buildCSSVariables(design) {
  return `<style>
:root {
  --color-primary:        ${design.colors.primary};
  --color-primary-dark:   ${design.colors.primaryDark};
  --color-secondary:      ${design.colors.secondary};
  --color-accent:         ${design.colors.accent || '#86868b'};
  --color-background:     ${design.colors.background};
  --color-background-alt: ${design.colors.backgroundAlt};
  --color-text:           ${design.colors.text};
  --color-text-secondary: ${design.colors.textSecondary};
  --color-border:         ${design.colors.border};
  --border-radius:        ${design.borderRadius};
  --shadow:               ${design.shadow};
  --font-family:          ${design.typography.fontFamily};
  --heading-size:         ${design.typography.headingSize};
  --heading-weight:       ${design.typography.headingWeight};
  --body-size:            ${design.typography.bodySize};
  ${design.glassEffect ? `--glass-effect: ${design.glassEffect};` : ''}
}
</style>`;
}

const PAGE_LABELS = {
  home: 'Home', about: 'About', menu: 'Menu', services: 'Services',
  gallery: 'Gallery', products: 'Products', contact: 'Contact',
  events: 'Events', work: 'Work', portfolio: 'Portfolio',
  listings: 'Listings', courses: 'Courses', booking: 'Book',
  projects: 'Projects', sermons: 'Sermons', donate: 'Donate',
};

const PAGE_ICONS = {
  home:     `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
  about:    `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  menu:     `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`,
  services: `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  gallery:  `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`,
  products: `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>`,
  contact:  `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.77 1h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l.91-.91a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
};

function buildNav(industry, activePage) {
  // Always include contact; deduplicate
  const pages = industry.pages.includes('contact')
    ? industry.pages
    : [...industry.pages, 'contact'];

  const sidebarLinks = pages.map(p => {
    const label = PAGE_LABELS[p] || p.charAt(0).toUpperCase() + p.slice(1);
    const icon  = PAGE_ICONS[p] || PAGE_ICONS.about;
    const href  = p === 'home' ? 'index.html' : `${p}.html`;
    const active = p === activePage ? ' sidebar__link--active' : '';
    return `      <a href="${href}" class="sidebar__link${active}">${icon} <span>${label}</span></a>`;
  }).join('\n');

  const bottomItems = pages.slice(0, 5).map(p => {
    const label = PAGE_LABELS[p] || p.charAt(0).toUpperCase() + p.slice(1);
    const icon  = PAGE_ICONS[p] || PAGE_ICONS.about;
    const href  = p === 'home' ? 'index.html' : `${p}.html`;
    const active = p === activePage ? ' bottom-nav__item--active' : '';
    return `      <a href="${href}" class="bottom-nav__item${active}">${icon}<span>${label}</span></a>`;
  }).join('\n');

  return { sidebarLinks, bottomItems };
}

function buildHead(title, design) {
  return `
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>${title}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  ${buildCSSVariables(design)}`;
}

function buildWhatsAppFAB(whatsapp) {
  if (!whatsapp) return '';
  return `
  <a href="https://wa.me/${whatsapp}" class="fab" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347"/>
    </svg>
  </a>`;
}

function buildFooter(v) {
  return `
  <footer class="footer">
    <div class="container">
      <div class="footer__grid">
        <div class="footer__col">
          <h3>${v.site_name || ''}</h3>
          <p>${v.footer_text || ''}</p>
        </div>
        <div class="footer__col">
          <h4>Contact</h4>
          ${v.phone    ? `<p><a href="tel:${v.phone}">${v.phone}</a></p>`            : ''}
          ${v.email    ? `<p><a href="mailto:${v.email}">${v.email}</a></p>`          : ''}
          ${v.address  ? `<p>${v.address}</p>`                                        : ''}
        </div>
      </div>
    </div>
  </footer>`;
}

// ─── Page assemblers ──────────────────────────────────────────────────────────

function assembleHomePage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'home');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`${v.site_name} - ${industry.name}`, design)}
  <meta name="description" content="${v.hero_subheadline || v.hero_headline}">
</head>
<body>
  <div class="app-layout">

    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>

    <main class="main-content">

      <section class="hero">
        ${v.hero_image ? `<div class="hero__image"><img src="${v.hero_image}" alt="${v.site_name}" loading="lazy"><div class="hero__overlay"></div></div>` : '<div class="hero__image hero__image--placeholder"></div>'}
        <div class="hero__content">
          <h1 class="hero__headline">${v.hero_headline}</h1>
          <p class="hero__subheadline">${v.hero_subheadline || ''}</p>
          <div class="hero__actions">
            <a href="contact.html" class="btn btn--primary">Get in Touch</a>
            ${v.whatsapp ? `<a href="https://wa.me/${v.whatsapp}" class="btn btn--whatsapp" target="_blank" rel="noopener">WhatsApp Us</a>` : ''}
          </div>
        </div>
      </section>

      ${industry.pages.includes('about') ? `
      <section class="about-preview">
        <div class="container">
          <h2 class="section-title">About Us</h2>
          <div class="about-preview__grid">
            <div class="about-preview__text">
              <p>${v.about_text || ''}</p>
              <a href="about.html" class="btn btn--outline">Learn More</a>
            </div>
            ${v.about_image ? `<div class="about-preview__image"><img src="${v.about_image}" alt="About ${v.site_name}" loading="lazy"></div>` : ''}
          </div>
        </div>
      </section>` : ''}

      <section class="cta">
        <div class="container">
          <h2 class="cta__title">Ready to get started?</h2>
          <p class="cta__text">Contact us today.</p>
          ${v.phone ? `<a href="tel:${v.phone}" class="btn btn--primary">Call Now</a>` : '<a href="contact.html" class="btn btn--primary">Contact Us</a>'}
        </div>
      </section>

    </main>

    <nav class="bottom-nav">
${bottomItems}
    </nav>

  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleAboutPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'about');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`About - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header">
        <h1>About Us</h1>
        <p>${industry.name}</p>
      </div>
      <section class="about-section">
        <div class="container">
          <div class="about-section__grid">
            ${v.about_image ? `<div class="about-section__image"><img src="${v.about_image}" alt="About ${v.site_name}" loading="lazy"></div>` : ''}
            <div class="about-section__content">
              <h2>Our Story</h2>
              <p>${v.about_text || ''}</p>
              <div class="contact-details">
                ${v.phone   ? `<p><strong>Phone:</strong> <a href="tel:${v.phone}">${v.phone}</a></p>` : ''}
                ${v.email   ? `<p><strong>Email:</strong> <a href="mailto:${v.email}">${v.email}</a></p>` : ''}
                ${v.address ? `<p><strong>Address:</strong> ${v.address}</p>` : ''}
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleContactPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'contact');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`Contact - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header"><h1>Contact Us</h1><p>We would love to hear from you</p></div>
      <section class="contact-section">
        <div class="container">
          <div class="contact-section__grid">
            <div class="contact-info">
              <h2>Get in Touch</h2>
              ${v.phone    ? `<div class="contact-info__item"><strong>Phone</strong><p><a href="tel:${v.phone}">${v.phone}</a></p></div>` : ''}
              ${v.whatsapp ? `<div class="contact-info__item"><strong>WhatsApp</strong><p><a href="https://wa.me/${v.whatsapp}" target="_blank" rel="noopener">${v.whatsapp}</a></p></div>` : ''}
              ${v.email    ? `<div class="contact-info__item"><strong>Email</strong><p><a href="mailto:${v.email}">${v.email}</a></p></div>` : ''}
              ${v.address  ? `<div class="contact-info__item"><strong>Address</strong><p>${v.address}</p></div>` : ''}
            </div>
            <div class="contact-form">
              <h2>Send a Message</h2>
              <div class="form">
                <input type="text"  name="name"    placeholder="Your Name"    class="form__input">
                <input type="email" name="email"   placeholder="Your Email"   class="form__input">
                <input type="tel"   name="phone"   placeholder="Your Phone"   class="form__input">
                <textarea name="message" placeholder="Your Message" rows="4" class="form__input"></textarea>
                <button type="button" class="btn btn--primary js-send-message">Send Message</button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleMenuPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'menu');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`Menu - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header"><h1>${v.menu_headline || 'Our Menu'}</h1></div>
      <section class="menu-section">
        <div class="container">
          <div class="menu-grid js-menu-grid">
            <p class="placeholder-hint">Menu items appear here once edited.</p>
          </div>
          ${v.menu_pdf ? `<div class="menu-pdf"><a href="${v.menu_pdf}" class="btn btn--outline" target="_blank" rel="noopener">View Full Menu PDF</a></div>` : ''}
          ${v.whatsapp ? `<div class="menu-order"><a href="https://wa.me/${v.whatsapp}?text=I'd+like+to+order..." class="btn btn--whatsapp" target="_blank" rel="noopener">Order via WhatsApp</a></div>` : ''}
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleServicesPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'services');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`Services - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header"><h1>${v.services_headline || 'Our Services'}</h1><p>What we offer</p></div>
      <section class="services-section">
        <div class="container">
          <div class="services-grid js-services-grid">
            <p class="placeholder-hint">Services appear here once edited.</p>
          </div>
        </div>
      </section>
      <section class="cta">
        <div class="container">
          <h2 class="cta__title">Interested in our services?</h2>
          <a href="contact.html" class="btn btn--primary">Contact Us</a>
          ${v.whatsapp ? `<a href="https://wa.me/${v.whatsapp}" class="btn btn--whatsapp" target="_blank" rel="noopener">Chat on WhatsApp</a>` : ''}
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleGalleryPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'gallery');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`Gallery - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header"><h1>Gallery</h1><p>Our work in pictures</p></div>
      <section class="gallery-section">
        <div class="container">
          <div class="gallery-grid js-gallery-grid">
            <p class="placeholder-hint">Gallery images appear here once edited.</p>
          </div>
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}

function assembleProductsPage(industry, design, v) {
  const { sidebarLinks, bottomItems } = buildNav(industry, 'products');

  return `<!DOCTYPE html>
<html lang="en">
<head>${buildHead(`Products - ${v.site_name}`, design)}
</head>
<body>
  <div class="app-layout">
    <aside class="sidebar">
      <div class="sidebar__logo">${v.site_name}</div>
      <nav class="sidebar__nav">
${sidebarLinks}
      </nav>
    </aside>
    <main class="main-content">
      <div class="page-header"><h1>${v.products_headline || 'Products'}</h1><p>Browse what we have available</p></div>
      <section class="products-section">
        <div class="container">
          <div class="products-grid js-products-grid">
            <p class="placeholder-hint">Products appear here once edited.</p>
          </div>
        </div>
      </section>
    </main>
    <nav class="bottom-nav">
${bottomItems}
    </nav>
  </div>
  ${buildWhatsAppFAB(v.whatsapp)}
  ${buildFooter(v)}
  <script src="assets/js/main.js"></script>
</body>
</html>`;
}
