/**
 * Template Factory - Industries catalog.
 * 50+ industries across 14 categories.
 */

export const INDUSTRIES = [
  // Food & Hospitality (8)
  { id: 'restaurant',   name: 'Restaurants',        category: 'food',         pages: ['home','about','menu','contact'],                icon: 'utensils' },
  { id: 'takeaway',     name: 'Takeaway & Delivery', category: 'food',         pages: ['home','menu','contact'],                       icon: 'package' },
  { id: 'cafe',         name: 'Cafes & Coffee Shops',category: 'food',         pages: ['home','menu','about','contact'],               icon: 'coffee' },
  { id: 'bakery',       name: 'Bakeries',            category: 'food',         pages: ['home','products','about','contact'],           icon: 'layers' },
  { id: 'catering',     name: 'Catering Services',   category: 'food',         pages: ['home','menus','gallery','contact'],            icon: 'utensils' },
  { id: 'bar',          name: 'Bars & Nightlife',    category: 'food',         pages: ['home','events','gallery','contact'],           icon: 'music' },
  { id: 'hotel',        name: 'Hotels & Lodges',     category: 'food',         pages: ['home','rooms','about','contact'],              icon: 'home' },
  { id: 'butchery',     name: 'Butcheries & Delis',  category: 'food',         pages: ['home','products','about','contact'],           icon: 'shopping-bag' },

  // Beauty & Wellness (6)
  { id: 'salon',        name: 'Hair & Beauty Salons',category: 'beauty',       pages: ['home','services','gallery','contact'],         icon: 'scissors' },
  { id: 'barbershop',   name: 'Barbershops',         category: 'beauty',       pages: ['home','services','gallery','contact'],         icon: 'scissors' },
  { id: 'spa',          name: 'Spas & Massage',      category: 'beauty',       pages: ['home','services','booking','contact'],         icon: 'heart' },
  { id: 'nails',        name: 'Nail Salons',         category: 'beauty',       pages: ['home','services','gallery','contact'],         icon: 'star' },
  { id: 'gym',          name: 'Gyms & Fitness',      category: 'beauty',       pages: ['home','classes','membership','contact'],       icon: 'activity' },
  { id: 'wellness',     name: 'Wellness Centers',    category: 'beauty',       pages: ['home','services','about','contact'],           icon: 'heart' },

  // Retail & Shopping (6)
  { id: 'retail',       name: 'Retail Shops',        category: 'retail',       pages: ['home','products','about','contact'],           icon: 'shopping-bag' },
  { id: 'boutique',     name: 'Clothing Boutiques',  category: 'retail',       pages: ['home','products','gallery','contact'],         icon: 'tag' },
  { id: 'electronics',  name: 'Electronics Shops',   category: 'retail',       pages: ['home','products','services','contact'],        icon: 'monitor' },
  { id: 'pharmacy',     name: 'Pharmacies',          category: 'retail',       pages: ['home','services','about','contact'],           icon: 'plus-circle' },
  { id: 'hardware',     name: 'Hardware Shops',      category: 'retail',       pages: ['home','products','services','contact'],        icon: 'tool' },
  { id: 'supermarket',  name: 'Supermarkets',        category: 'retail',       pages: ['home','products','about','contact'],           icon: 'shopping-cart' },

  // Professional Services (6)
  { id: 'law',          name: 'Law Firms',           category: 'professional', pages: ['home','services','team','contact'],            icon: 'briefcase' },
  { id: 'accounting',   name: 'Accounting Firms',    category: 'professional', pages: ['home','services','team','contact'],            icon: 'bar-chart' },
  { id: 'realestate',   name: 'Real Estate Agents',  category: 'professional', pages: ['home','listings','about','contact'],          icon: 'home' },
  { id: 'insurance',    name: 'Insurance Brokers',   category: 'professional', pages: ['home','products','about','contact'],           icon: 'shield' },
  { id: 'consulting',   name: 'Business Consulting', category: 'professional', pages: ['home','services','about','contact'],           icon: 'trending-up' },
  { id: 'it',           name: 'IT & Tech Services',  category: 'professional', pages: ['home','services','portfolio','contact'],       icon: 'monitor' },

  // Health & Medical (6)
  { id: 'clinic',       name: 'Medical Clinics',     category: 'health',       pages: ['home','services','about','contact'],           icon: 'plus-circle' },
  { id: 'dentist',      name: 'Dental Practices',    category: 'health',       pages: ['home','services','about','contact'],           icon: 'smile' },
  { id: 'optometrist',  name: 'Optometrists',        category: 'health',       pages: ['home','services','products','contact'],        icon: 'eye' },
  { id: 'physio',       name: 'Physiotherapy',       category: 'health',       pages: ['home','services','about','contact'],           icon: 'activity' },
  { id: 'mental',       name: 'Mental Health',       category: 'health',       pages: ['home','services','about','contact'],           icon: 'heart' },
  { id: 'veterinary',   name: 'Veterinary Clinics',  category: 'health',       pages: ['home','services','about','contact'],           icon: 'plus-circle' },

  // Faith & Community (4)
  { id: 'church',       name: 'Churches',            category: 'faith',        pages: ['home','about','events','contact'],             icon: 'home' },
  { id: 'mosque',       name: 'Mosques',             category: 'faith',        pages: ['home','about','events','contact'],             icon: 'home' },
  { id: 'ngo',          name: 'Nonprofits & NGOs',   category: 'community',    pages: ['home','about','projects','contact'],           icon: 'users' },
  { id: 'charity',      name: 'Charities',           category: 'community',    pages: ['home','about','events','contact'],             icon: 'heart' },

  // Education (5)
  { id: 'school',       name: 'Schools',             category: 'education',    pages: ['home','about','contact'],                     icon: 'book' },
  { id: 'tutoring',     name: 'Tutoring Centers',    category: 'education',    pages: ['home','services','about','contact'],           icon: 'book-open' },
  { id: 'music',        name: 'Music Schools',       category: 'education',    pages: ['home','lessons','about','contact'],            icon: 'music' },
  { id: 'driving',      name: 'Driving Schools',     category: 'education',    pages: ['home','courses','about','contact'],            icon: 'navigation' },
  { id: 'language',     name: 'Language Schools',    category: 'education',    pages: ['home','courses','about','contact'],            icon: 'globe' },

  // Events & Entertainment (6)
  { id: 'events',       name: 'Event Planners',      category: 'events',       pages: ['home','services','gallery','contact'],         icon: 'calendar' },
  { id: 'photography',  name: 'Photographers',       category: 'events',       pages: ['home','portfolio','packages','contact'],       icon: 'camera' },
  { id: 'dj',           name: 'DJs & Entertainment', category: 'events',       pages: ['home','services','gallery','contact'],         icon: 'music' },
  { id: 'venue',        name: 'Event Venues',        category: 'events',       pages: ['home','gallery','packages','contact'],         icon: 'map-pin' },
  { id: 'decoration',   name: 'Event Decor',         category: 'events',       pages: ['home','portfolio','packages','contact'],       icon: 'star' },
  { id: 'catering-events', name: 'Event Catering',   category: 'events',       pages: ['home','menus','gallery','contact'],            icon: 'utensils' },

  // Trades & Construction (6)
  { id: 'construction', name: 'Construction',        category: 'trades',       pages: ['home','projects','services','contact'],        icon: 'tool' },
  { id: 'plumbing',     name: 'Plumbers',            category: 'trades',       pages: ['home','services','about','contact'],           icon: 'droplet' },
  { id: 'electrician',  name: 'Electricians',        category: 'trades',       pages: ['home','services','about','contact'],           icon: 'zap' },
  { id: 'painting',     name: 'Painters',            category: 'trades',       pages: ['home','services','gallery','contact'],         icon: 'edit' },
  { id: 'landscaping',  name: 'Landscaping',         category: 'trades',       pages: ['home','services','gallery','contact'],         icon: 'feather' },
  { id: 'renovation',   name: 'Home Renovation',     category: 'trades',       pages: ['home','services','projects','contact'],        icon: 'home' },

  // Creative & Freelance (5)
  { id: 'portfolio',    name: 'Creative Portfolios', category: 'creative',     pages: ['home','about','contact'],                     icon: 'grid' },
  { id: 'designer',     name: 'Graphic Designers',   category: 'creative',     pages: ['home','portfolio','services','contact'],       icon: 'pen-tool' },
  { id: 'developer',    name: 'Web Developers',      category: 'creative',     pages: ['home','portfolio','services','contact'],       icon: 'code' },
  { id: 'writer',       name: 'Writers & Authors',   category: 'creative',     pages: ['home','about','contact'],                     icon: 'file-text' },
  { id: 'artist',       name: 'Artists',             category: 'creative',     pages: ['home','gallery','about','contact'],            icon: 'image' },

  // Transport & Logistics (4)
  { id: 'logistics',    name: 'Logistics & Delivery',category: 'transport',    pages: ['home','services','about','contact'],           icon: 'truck' },
  { id: 'taxi',         name: 'Taxi Services',       category: 'transport',    pages: ['home','services','about','contact'],           icon: 'navigation' },
  { id: 'transport',    name: 'Public Transport',    category: 'transport',    pages: ['home','about','contact'],                     icon: 'truck' },
  { id: 'courier',      name: 'Courier Services',    category: 'transport',    pages: ['home','services','about','contact'],           icon: 'package' },

  // Agriculture (3)
  { id: 'farming',      name: 'Farms',               category: 'agriculture',  pages: ['home','products','about','contact'],           icon: 'feather' },
  { id: 'agribusiness', name: 'Agribusiness',        category: 'agriculture',  pages: ['home','products','services','contact'],        icon: 'trending-up' },
  { id: 'livestock',    name: 'Livestock Farming',   category: 'agriculture',  pages: ['home','products','about','contact'],           icon: 'feather' },

  // Automotive (4)
  { id: 'mechanic',     name: 'Auto Repair',         category: 'automotive',   pages: ['home','services','about','contact'],           icon: 'tool' },
  { id: 'dealership',   name: 'Car Dealerships',     category: 'automotive',   pages: ['home','inventory','about','contact'],          icon: 'navigation' },
  { id: 'carwash',      name: 'Car Washes',          category: 'automotive',   pages: ['home','services','about','contact'],           icon: 'droplet' },
  { id: 'tyres',        name: 'Tyre Shops',          category: 'automotive',   pages: ['home','products','services','contact'],        icon: 'circle' },
];

export const INDUSTRY_CATEGORIES = [
  { id: 'food',         name: 'Food & Hospitality' },
  { id: 'beauty',       name: 'Beauty & Wellness' },
  { id: 'retail',       name: 'Retail & Shopping' },
  { id: 'professional', name: 'Professional Services' },
  { id: 'health',       name: 'Health & Medical' },
  { id: 'faith',        name: 'Faith & Community' },
  { id: 'community',    name: 'Community' },
  { id: 'education',    name: 'Education' },
  { id: 'events',       name: 'Events & Entertainment' },
  { id: 'trades',       name: 'Trades & Construction' },
  { id: 'creative',     name: 'Creative & Freelance' },
  { id: 'transport',    name: 'Transport & Logistics' },
  { id: 'agriculture',  name: 'Agriculture' },
  { id: 'automotive',   name: 'Automotive' },
];
