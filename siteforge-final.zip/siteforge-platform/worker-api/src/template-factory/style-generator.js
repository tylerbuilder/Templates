/**
 * Template Factory - CSS Generator.
 * Produces a complete style.css from a design system + industry.
 * Every rule is written with CSS custom properties so the page-level
 * :root block (injected by buildCSSVariables) can override any value.
 */

export function generateStylesheet(designSystem, industry) {
  const d = designSystem;
  const isGlass = d.id === 'glassmorphism';
  const isDark  = d.id === 'dark-premium';

  return `
/* ============================================================
   SiteForge Generated Stylesheet
   Design System : ${d.name}
   Industry      : ${industry.name}
   ============================================================ */

/* ---------- Reset & base ---------- */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }

body {
  font-family: var(--font-family);
  font-size: var(--body-size);
  line-height: 1.6;
  color: var(--color-text);
  background: var(--color-background);
  min-height: 100vh;
  overflow-x: hidden;
}

img { display: block; max-width: 100%; height: auto; object-fit: cover; }
a  { color: var(--color-primary); text-decoration: none; }
a:hover { text-decoration: underline; }

/* ---------- Layout ---------- */
.app-layout {
  display: grid;
  grid-template-columns: 240px 1fr;
  grid-template-rows: 1fr auto;
  min-height: 100vh;
}

.sidebar {
  grid-row: 1 / -1;
  background: ${isGlass ? 'rgba(0,0,0,0.3)' : isDark ? '#111' : 'var(--color-background-alt)'};
  ${isGlass ? 'backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);' : ''}
  border-right: 1px solid var(--color-border);
  padding: 24px 0;
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}

.sidebar__logo {
  font-size: 18px;
  font-weight: 700;
  color: var(--color-text);
  padding: 0 20px 24px;
  border-bottom: 1px solid var(--color-border);
  margin-bottom: 12px;
}

.sidebar__nav { display: flex; flex-direction: column; gap: 2px; padding: 0 12px; }

.sidebar__link {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: calc(var(--border-radius) / 1.5);
  color: var(--color-text-secondary);
  font-size: 14px;
  font-weight: 500;
  transition: all 0.15s ease;
  text-decoration: none;
}

.sidebar__link:hover, .sidebar__link--active {
  background: var(--color-primary);
  color: #fff;
  text-decoration: none;
}

.sidebar__link svg { flex-shrink: 0; opacity: 0.8; }

.main-content {
  grid-column: 2;
  min-width: 0;
}

/* ---------- Bottom nav (mobile) ---------- */
.bottom-nav {
  display: none;
  grid-column: 1 / -1;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: var(--color-background);
  ${isGlass ? 'backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); background: rgba(255,255,255,0.85);' : ''}
  border-top: 1px solid var(--color-border);
  z-index: 100;
  padding: 6px 0 max(6px, env(safe-area-inset-bottom));
}

.bottom-nav__item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  flex: 1;
  padding: 6px 4px;
  color: var(--color-text-secondary);
  font-size: 11px;
  font-weight: 500;
  text-decoration: none;
  transition: color 0.15s;
}

.bottom-nav__item--active, .bottom-nav__item:hover { color: var(--color-primary); text-decoration: none; }

/* ---------- Hero ---------- */
.hero {
  position: relative;
  min-height: 480px;
  display: flex;
  align-items: center;
  background: var(--color-background-alt);
  overflow: hidden;
}

.hero__image {
  position: absolute; inset: 0;
}

.hero__image img { width: 100%; height: 100%; object-fit: cover; }

.hero__image--placeholder { background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%); }

.hero__overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to bottom, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.55) 100%);
}

.hero__content {
  position: relative;
  z-index: 1;
  padding: 60px 40px;
  max-width: 680px;
}

.hero__headline {
  font-size: clamp(32px, 5vw, var(--heading-size));
  font-weight: var(--heading-weight);
  color: #fff;
  line-height: 1.15;
  margin-bottom: 16px;
}

.hero__subheadline { font-size: 18px; color: rgba(255,255,255,0.85); margin-bottom: 32px; }

.hero__actions { display: flex; gap: 12px; flex-wrap: wrap; }

/* ---------- Buttons ---------- */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  border-radius: var(--border-radius);
  font-family: var(--font-family);
  font-size: 15px;
  font-weight: 600;
  line-height: 1;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.15s ease;
  text-decoration: none;
  white-space: nowrap;
}

.btn--primary {
  background: var(--color-primary);
  color: #fff;
  border-color: var(--color-primary);
  box-shadow: var(--shadow);
}
.btn--primary:hover { background: var(--color-primary-dark); border-color: var(--color-primary-dark); text-decoration: none; color: #fff; }

.btn--outline {
  background: transparent;
  color: var(--color-primary);
  border-color: var(--color-primary);
}
.btn--outline:hover { background: var(--color-primary); color: #fff; text-decoration: none; }

.btn--whatsapp {
  background: #25D366;
  color: #fff;
  border-color: #25D366;
}
.btn--whatsapp:hover { background: #1ebe5a; border-color: #1ebe5a; text-decoration: none; color: #fff; }

.btn--text { background: none; border: none; color: var(--color-primary); padding: 0; font-weight: 600; }
.btn--text:hover { text-decoration: underline; }

/* ---------- Container & sections ---------- */
.container { width: 100%; max-width: 960px; margin: 0 auto; padding: 0 24px; }

section { padding: 60px 0; }

.page-header {
  background: var(--color-background-alt);
  border-bottom: 1px solid var(--color-border);
  padding: 40px;
}

.page-header h1 { font-size: 36px; font-weight: 700; margin-bottom: 6px; }
.page-header p  { color: var(--color-text-secondary); }

.section-title { font-size: 32px; font-weight: 700; margin-bottom: 32px; text-align: center; }

/* ---------- About preview ---------- */
.about-preview__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  align-items: center;
}

.about-preview__text p { font-size: 17px; line-height: 1.7; color: var(--color-text-secondary); margin-bottom: 24px; }
.about-preview__image img { border-radius: var(--border-radius); box-shadow: var(--shadow); }

/* ---------- CTA ---------- */
.cta { background: var(--color-background-alt); text-align: center; }
.cta__title { font-size: 28px; font-weight: 700; margin-bottom: 12px; }
.cta__text  { color: var(--color-text-secondary); margin-bottom: 24px; }

/* ---------- About section ---------- */
.about-section__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 48px; align-items: start; }
.about-section__image img { border-radius: var(--border-radius); width: 100%; }
.about-section__content h2 { font-size: 28px; font-weight: 700; margin-bottom: 16px; }
.about-section__content p  { color: var(--color-text-secondary); line-height: 1.7; margin-bottom: 24px; }
.contact-details p { margin-bottom: 8px; font-size: 15px; }

/* ---------- Contact ---------- */
.contact-section__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 48px; }
.contact-info h2 { font-size: 24px; font-weight: 700; margin-bottom: 20px; }
.contact-info__item { margin-bottom: 16px; }
.contact-info__item strong { display: block; font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--color-text-secondary); margin-bottom: 4px; }
.contact-info__item p, .contact-info__item a { font-size: 16px; color: var(--color-text); }
.contact-form h2 { font-size: 24px; font-weight: 700; margin-bottom: 20px; }

/* ---------- Form ---------- */
.form { display: flex; flex-direction: column; gap: 12px; }
.form__input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid var(--color-border);
  border-radius: calc(var(--border-radius) / 1.5);
  font-family: var(--font-family);
  font-size: 15px;
  background: var(--color-background);
  color: var(--color-text);
  transition: border-color 0.15s;
  appearance: none;
}
.form__input:focus { outline: none; border-color: var(--color-primary); }
textarea.form__input { resize: vertical; min-height: 100px; }

/* ---------- Grid placeholders (menu, services, gallery, products) ---------- */
.menu-grid, .services-grid, .gallery-grid, .products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 24px;
}

.placeholder-hint {
  grid-column: 1 / -1;
  text-align: center;
  color: var(--color-text-secondary);
  padding: 48px;
  border: 2px dashed var(--color-border);
  border-radius: var(--border-radius);
  font-size: 15px;
}

.menu-pdf, .menu-order { margin-top: 32px; text-align: center; }

/* ---------- FAB ---------- */
.fab {
  position: fixed;
  bottom: 90px;
  right: 20px;
  width: 52px;
  height: 52px;
  background: #25D366;
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 16px rgba(37,211,102,0.4);
  z-index: 200;
  transition: transform 0.15s, box-shadow 0.15s;
  text-decoration: none;
}
.fab:hover { transform: scale(1.08); box-shadow: 0 6px 20px rgba(37,211,102,0.5); text-decoration: none; }

/* ---------- Footer ---------- */
.footer {
  background: ${isDark ? '#0D0D0D' : 'var(--color-background-alt)'};
  border-top: 1px solid var(--color-border);
  padding: 48px 0 32px;
}

.footer__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.footer__col h3 { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
.footer__col h4 { font-size: 14px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--color-text-secondary); margin-bottom: 12px; }
.footer__col p  { font-size: 14px; color: var(--color-text-secondary); margin-bottom: 4px; }
.footer__col a  { color: var(--color-text-secondary); }
.footer__col a:hover { color: var(--color-primary); }

/* ---------- Glassmorphism overrides ---------- */
${isGlass ? `
.sidebar__link:hover, .sidebar__link--active { background: rgba(255,255,255,0.2); }
.form__input { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color: #fff; }
.form__input::placeholder { color: rgba(255,255,255,0.5); }
` : ''}

/* ---------- Dark-premium overrides ---------- */
${isDark ? `
.hero__headline, .hero__subheadline { text-shadow: 0 2px 8px rgba(0,0,0,0.5); }
.sidebar { border-right-color: #222; }
` : ''}

/* ---------- Responsive ---------- */
@media (max-width: 768px) {
  .app-layout {
    grid-template-columns: 1fr;
    padding-bottom: 68px;
  }

  .sidebar { display: none; }

  .bottom-nav {
    display: flex;
    align-items: stretch;
  }

  .fab { bottom: 80px; }

  .hero { min-height: 360px; }
  .hero__content { padding: 40px 20px; }

  .about-preview__grid,
  .about-section__grid,
  .contact-section__grid,
  .footer__grid { grid-template-columns: 1fr; }

  .page-header { padding: 24px 20px; }
  .page-header h1 { font-size: 28px; }

  section { padding: 40px 0; }
  .container { padding: 0 16px; }

  .menu-grid, .services-grid, .products-grid {
    grid-template-columns: 1fr 1fr;
  }

  .gallery-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }

  .hero__actions { flex-direction: column; }
  .btn { justify-content: center; }
}

@media (max-width: 480px) {
  .menu-grid, .services-grid, .products-grid { grid-template-columns: 1fr; }
  .gallery-grid { grid-template-columns: repeat(2, 1fr); }
  .hero__headline { font-size: 28px; }
}
`.trim();
}

/**
 * Generates a minimal main.js for template pages.
 * Handles: contact form submission via WhatsApp, smooth scroll, image lazy loading.
 */
export function generateMainJS(content) {
  const whatsapp = (content?.whatsapp?.default ?? content?.whatsapp) || '';
  const siteName = (content?.site_name?.default ?? content?.site_name) || 'Our Business';

  return `
/* SiteForge - main.js — generated */
(function () {
  'use strict';

  // Contact form → WhatsApp
  const sendBtn = document.querySelector('.js-send-message');
  if (sendBtn) {
    sendBtn.addEventListener('click', function () {
      const name    = (document.querySelector('[name="name"]')?.value    || '').trim();
      const email   = (document.querySelector('[name="email"]')?.value   || '').trim();
      const phone   = (document.querySelector('[name="phone"]')?.value   || '').trim();
      const message = (document.querySelector('[name="message"]')?.value || '').trim();
      if (!name || !message) { alert('Please enter your name and message.'); return; }
      const whatsapp = '${whatsapp}';
      if (whatsapp) {
        const text = encodeURIComponent('Hi ${siteName}!\\nName: ' + name + '\\nMessage: ' + message + (phone ? '\\nPhone: ' + phone : '') + (email ? '\\nEmail: ' + email : ''));
        window.open('https://wa.me/' + whatsapp + '?text=' + text, '_blank');
      } else {
        alert('Thank you for your message, ' + name + '! We will be in touch soon.');
      }
    });
  }

  // Lazy image loading polyfill for older WebView
  if ('loading' in HTMLImageElement.prototype === false) {
    const images = document.querySelectorAll('img[loading="lazy"]');
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const img = entry.target;
          if (img.dataset.src) img.src = img.dataset.src;
          observer.unobserve(img);
        }
      });
    });
    images.forEach(function (img) { observer.observe(img); });
  }

  console.log('[SiteForge] ${siteName} loaded');
})();
`.trim();
}
