/**
 * Template Factory - Design Systems (8 visual styles)
 */

export const DESIGN_SYSTEMS = [
  {
    id: 'apple',
    name: 'Apple-Inspired',
    description: 'Clean, white space, large typography, rounded corners',
    colors: { primary: '#0071e3', primaryDark: '#005bb5', secondary: '#2997ff', accent: '#86868b', background: '#ffffff', backgroundAlt: '#f5f5f7', text: '#1d1d1f', textSecondary: '#86868b', border: '#e2e2e5' },
    typography: { fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", headingSize: '56px', headingWeight: '700', bodySize: '17px' },
    borderRadius: '12px', buttonStyle: 'pill', shadow: '0 2px 8px rgba(0,0,0,0.04)',
  },
  {
    id: 'glassmorphism',
    name: 'Glassmorphism',
    description: 'Frosted glass effects, blur backgrounds, modern',
    colors: { primary: '#ffffff', primaryDark: '#f0f0f0', secondary: 'rgba(255,255,255,0.8)', accent: '#667eea', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', backgroundAlt: 'rgba(255,255,255,0.1)', text: '#ffffff', textSecondary: 'rgba(255,255,255,0.7)', border: 'rgba(255,255,255,0.2)' },
    typography: { fontFamily: "'Inter', system-ui, sans-serif", headingSize: '52px', headingWeight: '600', bodySize: '16px' },
    borderRadius: '20px', buttonStyle: 'rounded', shadow: '0 8px 32px rgba(0,0,0,0.1)', glassEffect: 'backdrop-filter: blur(10px);',
  },
  {
    id: 'bold-colorful',
    name: 'Bold & Colorful',
    description: 'Vibrant colors, bold typography, high contrast',
    colors: { primary: '#FF6B35', primaryDark: '#e55a26', secondary: '#F7C59F', accent: '#1B4332', background: '#ffffff', backgroundAlt: '#FFF8F0', text: '#1a1a1a', textSecondary: '#555555', border: '#FFD6B8' },
    typography: { fontFamily: "'Inter', 'DM Sans', system-ui, sans-serif", headingSize: '60px', headingWeight: '800', bodySize: '16px' },
    borderRadius: '8px', buttonStyle: 'square', shadow: '4px 4px 0px rgba(0,0,0,0.15)',
  },
  {
    id: 'warm-earthy',
    name: 'Warm & Earthy',
    description: 'Natural tones, organic feel, welcoming atmosphere',
    colors: { primary: '#8B5E3C', primaryDark: '#6d4a2f', secondary: '#D4A574', accent: '#4A7C59', background: '#FDF6EC', backgroundAlt: '#F5ECD8', text: '#2C1810', textSecondary: '#6B4A2A', border: '#E8D5BA' },
    typography: { fontFamily: "'Merriweather', 'Georgia', serif", headingSize: '48px', headingWeight: '700', bodySize: '16px' },
    borderRadius: '4px', buttonStyle: 'rounded', shadow: '0 4px 16px rgba(139,94,60,0.15)',
  },
  {
    id: 'dark-premium',
    name: 'Dark Premium',
    description: 'Dark backgrounds, gold accents, premium aesthetic',
    colors: { primary: '#D4AF37', primaryDark: '#b8992f', secondary: '#C0A060', accent: '#F5E6C8', background: '#0D0D0D', backgroundAlt: '#1a1a1a', text: '#F5F5F5', textSecondary: '#A0A0A0', border: '#2A2A2A' },
    typography: { fontFamily: "'Inter', system-ui, sans-serif", headingSize: '54px', headingWeight: '700', bodySize: '16px' },
    borderRadius: '6px', buttonStyle: 'rounded', shadow: '0 4px 24px rgba(0,0,0,0.4)',
  },
  {
    id: 'minimal-clean',
    name: 'Minimal Clean',
    description: 'Maximum whitespace, subtle typography, editorial feel',
    colors: { primary: '#000000', primaryDark: '#333333', secondary: '#666666', accent: '#E8E8E8', background: '#FAFAFA', backgroundAlt: '#F0F0F0', text: '#1A1A1A', textSecondary: '#6B6B6B', border: '#E0E0E0' },
    typography: { fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif", headingSize: '52px', headingWeight: '400', bodySize: '16px' },
    borderRadius: '2px', buttonStyle: 'square', shadow: 'none',
  },
  {
    id: 'playful-fun',
    name: 'Playful & Fun',
    description: 'Rounded shapes, bright colors, friendly and approachable',
    colors: { primary: '#6C63FF', primaryDark: '#5a52d5', secondary: '#FF6584', accent: '#43D8C9', background: '#FEFEFE', backgroundAlt: '#F8F5FF', text: '#2D2D2D', textSecondary: '#6B6B6B', border: '#E8E0FF' },
    typography: { fontFamily: "'Inter', 'Nunito', system-ui, sans-serif", headingSize: '50px', headingWeight: '700', bodySize: '16px' },
    borderRadius: '20px', buttonStyle: 'pill', shadow: '0 8px 24px rgba(108,99,255,0.15)',
  },
  {
    id: 'professional-trust',
    name: 'Professional Trust',
    description: 'Navy and grey palette, conveying authority and reliability',
    colors: { primary: '#1B3A6B', primaryDark: '#14305a', secondary: '#2E5EAA', accent: '#E8A020', background: '#FFFFFF', backgroundAlt: '#F4F6FA', text: '#1A2B4A', textSecondary: '#5B6E8A', border: '#D1D9E6' },
    typography: { fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif", headingSize: '48px', headingWeight: '700', bodySize: '16px' },
    borderRadius: '6px', buttonStyle: 'rounded', shadow: '0 2px 12px rgba(27,58,107,0.1)',
  },
];
