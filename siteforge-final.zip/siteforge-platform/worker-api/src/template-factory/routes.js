/**
 * Template Factory HTTP route handlers.
 * NOTE: /featured, /new, /trending must be registered BEFORE /api/templates/:id
 *       in the main routes table — this is enforced in src/index.js.
 */

import { success, error, parseBody } from '../utils/response.js';
import { INDUSTRIES, DESIGN_SYSTEMS } from './index.js';
import { generateSingleTemplate, generateAllTemplates, pushAllTemplatesToGitHub } from './index.js';

export async function handleListIndustries(request) {
  const url = new URL(request.url);
  const category = url.searchParams.get('category');

  let list = INDUSTRIES;
  if (category) list = INDUSTRIES.filter(i => i.category === category);

  const categories = [...new Set(INDUSTRIES.map(i => i.category))].map(c => ({
    id: c,
    name: c.charAt(0).toUpperCase() + c.slice(1).replace(/-/g, ' '),
    count: INDUSTRIES.filter(i => i.category === c).length,
  }));

  return success({ industries: list, categories, total: list.length });
}

export async function handleListDesignSystems(request) {
  return success({
    designSystems: DESIGN_SYSTEMS.map(d => ({
      id: d.id,
      name: d.name,
      description: d.description,
      colors: { primary: d.colors.primary, background: d.colors.background, text: d.colors.text },
      borderRadius: d.borderRadius,
    })),
    total: DESIGN_SYSTEMS.length,
  });
}

export async function handleGenerateTemplates(request) {
  // Protect with platform API key
  const apiKey = request.headers.get('X-Platform-Key');
  if (apiKey !== request.env.PLATFORM_API_KEY) return error('Unauthorized', 401);

  const body = await parseBody(request);

  const options = {
    industriesFilter: body?.industries || null,
    designFilter:     body?.designSystems || null,
    dryRun:           body?.dryRun === true,
  };

  const results = await generateAllTemplates(request.env, options);

  // Push to GitHub unless it's a dry run
  if (!options.dryRun && results.generated.length > 0) {
    try {
      const templateObjects = [];
      for (const g of results.generated) {
        const [industryId, ...rest] = g.id.split('-');
        const designSystemId = rest.join('-');
        const t = await generateSingleTemplate(industryId, designSystemId, request.env);
        templateObjects.push(t);
      }
      const pushResults = await pushAllTemplatesToGitHub(request.env, templateObjects);
      results.push = pushResults;
    } catch (err) {
      console.error('[Factory] GitHub push error:', err.message);
      results.pushError = err.message;
    }
  }

  return success({
    message: options.dryRun ? 'Dry run complete' : 'Template generation complete',
    generated: results.generated.length,
    failed: results.failed.length,
    details: results,
  });
}

// ─── Template discovery helpers ───────────────────────────────────────────────

async function getCachedCatalog(env) {
  try {
    const cached = await env.CONTENT_CACHE.get('template-catalog');
    if (cached) return JSON.parse(cached);
  } catch (e) { /* miss */ }
  return null;
}

export async function handleFeaturedTemplates(request) {
  const catalog = await getCachedCatalog(request.env);
  const templates = catalog || generateStaticCatalog();

  // Featured = one representative per category
  const seen = new Set();
  const featured = templates.filter(t => {
    const cat = t.category || t.id.split('-')[0];
    if (seen.has(cat)) return false;
    seen.add(cat);
    return true;
  }).slice(0, 8);

  return success({ templates: featured, total: featured.length });
}

export async function handleNewTemplates(request) {
  const catalog = await getCachedCatalog(request.env);
  const templates = catalog || generateStaticCatalog();

  // Newest = sorted by generatedAt desc
  const newest = [...templates]
    .sort((a, b) => new Date(b.generatedAt || 0) - new Date(a.generatedAt || 0))
    .slice(0, 12);

  return success({ templates: newest, total: newest.length });
}

export async function handleTrendingTemplates(request) {
  // In production, trending would be derived from site creation analytics.
  // For now, return a curated fixed list of high-demand categories.
  const trendingCategories = ['restaurant', 'salon', 'church', 'retail', 'portfolio'];

  const catalog = await getCachedCatalog(request.env);
  const templates = catalog || generateStaticCatalog();

  const trending = templates
    .filter(t => trendingCategories.includes(t.category || t.id.split('-')[0]))
    .slice(0, 12);

  return success({ templates: trending, total: trending.length });
}

// Static fallback catalog (when KV hasn't been populated yet)
function generateStaticCatalog() {
  return INDUSTRIES.slice(0, 20).map(industry => ({
    id: `${industry.id}-apple`,
    name: `${industry.name} — Apple-Inspired`,
    category: industry.category,
    description: `Clean, professional design for ${industry.name.toLowerCase()}.`,
    thumbnail: `https://placehold.co/600x400/0071e3/fff?text=${encodeURIComponent(industry.name)}`,
    generatedAt: new Date().toISOString(),
  }));
}
