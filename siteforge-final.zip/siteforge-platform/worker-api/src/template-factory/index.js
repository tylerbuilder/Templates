/**
 * Template Factory — orchestrator.
 *
 * Fixes vs original:
 *  - getGitHubToken() was a stub returning null; now delegates to
 *    getGitHubInstallationToken re-exported from github-build.js
 *  - pushAllTemplatesToGitHub batches ALL files into ONE commit per
 *    template (tree API) — no per-file API calls
 *  - Style and JS files are properly generated per template
 */

import { INDUSTRIES } from './industries.js';
import { DESIGN_SYSTEMS } from './design-systems.js';
import { generateContentSchema } from './content-schema.js';
import { assemblePage } from './page-assembler.js';
import { generateStylesheet, generateMainJS } from './style-generator.js';

// Re-exported so the factory's own routes can call it
export { INDUSTRIES, DESIGN_SYSTEMS };

// ─── Single template generation ───────────────────────────────────────────────

export async function generateSingleTemplate(industryId, designSystemId, env) {
  const industry = INDUSTRIES.find(i => i.id === industryId);
  if (!industry) throw new Error(`Unknown industry: ${industryId}`);

  const designSystem = DESIGN_SYSTEMS.find(d => d.id === designSystemId) || DESIGN_SYSTEMS[0];
  const { schema, defaultContent, fields } = generateContentSchema(industryId);

  const templateId = `${industryId}-${designSystemId}`;

  // Assemble all pages declared by the industry
  const pages = {};
  for (const page of industry.pages) {
    const filename = page === 'home' ? 'index.html' : `${page}.html`;
    pages[filename] = assemblePage(page, industry, designSystem, schema, {});
  }

  // CSS and JS using resolved defaults
  const css = generateStylesheet(designSystem, industry);
  const js  = generateMainJS(defaultContent);

  const thumbnail = `https://placehold.co/600x400/${designSystem.colors.primary.replace('#', '')}/${designSystem.id === 'glassmorphism' ? 'fff' : 'fff'}?text=${encodeURIComponent(industry.name)}`;

  const template = {
    id: templateId,
    name: `${industry.name} — ${designSystem.name}`,
    category: industry.category,
    industryId,
    designSystemId,
    description: `${designSystem.description} for ${industry.name.toLowerCase()}.`,
    thumbnail,
    pages: Object.fromEntries([
      ...Object.entries(pages),
      ['assets/css/style.css', css],
      ['assets/js/main.js',  js],
      ['content.json',       JSON.stringify(defaultContent, null, 2)],
    ]),
    schema: fields,
    defaultContent,
    features: industry.pages,
    generatedAt: new Date().toISOString(),
  };

  return template;
}

// ─── Bulk generation ──────────────────────────────────────────────────────────

export async function generateAllTemplates(env, options = {}) {
  const { industriesFilter, designFilter, dryRun = false } = options;

  const targetIndustries = industriesFilter
    ? INDUSTRIES.filter(i => industriesFilter.includes(i.id))
    : INDUSTRIES;

  const targetDesigns = designFilter
    ? DESIGN_SYSTEMS.filter(d => designFilter.includes(d.id))
    : DESIGN_SYSTEMS;

  const results = { generated: [], failed: [] };

  for (const industry of targetIndustries) {
    for (const design of targetDesigns) {
      try {
        const template = await generateSingleTemplate(industry.id, design.id, env);
        results.generated.push({ id: template.id, name: template.name });

        if (!dryRun && env?.CONTENT_CACHE) {
          // Cache individual template files in KV
          await env.CONTENT_CACHE.put(
            `template:${template.id}:files`,
            JSON.stringify(template.pages),
            { expirationTtl: 86400 * 7 } // 7 days
          );
        }

        console.log(`[Factory] Generated: ${template.id}`);
      } catch (err) {
        console.error(`[Factory] Failed ${industry.id}/${design.id}:`, err.message);
        results.failed.push({ id: `${industry.id}-${design.id}`, error: err.message });
      }
    }
  }

  // Update the catalog KV entry
  if (!dryRun && env?.CONTENT_CACHE && results.generated.length > 0) {
    const catalogEntries = results.generated.map(g => ({
      id: g.id,
      name: g.name,
      category: g.id.split('-')[0],
      generatedAt: new Date().toISOString(),
    }));
    await env.CONTENT_CACHE.put('template-catalog', JSON.stringify(catalogEntries), { expirationTtl: 86400 * 7 });
  }

  return results;
}

// ─── GitHub push — all files in ONE commit per template ──────────────────────

export async function pushAllTemplatesToGitHub(env, templates) {
  // Lazy import to avoid circular deps
  const { getGitHubInstallationTokenForFactory } = await import('./github-token.js');
  const token = await getGitHubInstallationTokenForFactory(env);

  const org  = env.GITHUB_ORG;
  const repo = env.TEMPLATES_REPO?.split('/')[1] || 'templates';
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github.v3+json',
    'Content-Type': 'application/json',
    'User-Agent': 'SiteForge/1.0',
  };

  const results = { pushed: [], failed: [] };

  // Get current HEAD SHA
  let baseSha = null;
  try {
    const refRes = await fetch(`https://api.github.com/repos/${org}/${repo}/git/refs/heads/main`, { headers });
    if (refRes.ok) baseSha = (await refRes.json()).object?.sha;
  } catch (e) { /* first push */ }

  // Build one giant tree for all templates in a single commit
  const treeItems = [];

  for (const template of templates) {
    for (const [filePath, content] of Object.entries(template.pages)) {
      treeItems.push({
        path: `templates/${template.id}/${filePath}`,
        mode: '100644',
        type: 'blob',
        content: typeof content === 'string' ? content : JSON.stringify(content, null, 2),
      });
    }
    // Metadata file
    treeItems.push({
      path: `templates/${template.id}/template.json`,
      mode: '100644',
      type: 'blob',
      content: JSON.stringify({ id: template.id, name: template.name, category: template.category, industryId: template.industryId, designSystemId: template.designSystemId, schema: template.schema, features: template.features, generatedAt: template.generatedAt }, null, 2),
    });
  }

  try {
    // Create tree
    const treeRes = await fetch(`https://api.github.com/repos/${org}/${repo}/git/trees`, {
      method: 'POST', headers,
      body: JSON.stringify({ base_tree: baseSha, tree: treeItems }),
    });
    const treeData = await treeRes.json();
    if (!treeData.sha) throw new Error(`Tree creation failed: ${JSON.stringify(treeData)}`);

    // Create commit
    const commitRes = await fetch(`https://api.github.com/repos/${org}/${repo}/git/commits`, {
      method: 'POST', headers,
      body: JSON.stringify({ message: `[factory] Regenerate ${templates.length} templates — ${new Date().toISOString()}`, tree: treeData.sha, parents: baseSha ? [baseSha] : [] }),
    });
    const commitData = await commitRes.json();
    if (!commitData.sha) throw new Error(`Commit failed: ${JSON.stringify(commitData)}`);

    // Update or create ref
    if (baseSha) {
      await fetch(`https://api.github.com/repos/${org}/${repo}/git/refs/heads/main`, {
        method: 'PATCH', headers, body: JSON.stringify({ sha: commitData.sha }),
      });
    } else {
      await fetch(`https://api.github.com/repos/${org}/${repo}/git/refs`, {
        method: 'POST', headers, body: JSON.stringify({ ref: 'refs/heads/main', sha: commitData.sha }),
      });
    }

    templates.forEach(t => results.pushed.push(t.id));
    console.log(`[Factory] Pushed ${templates.length} templates in 1 commit (sha: ${commitData.sha})`);
  } catch (err) {
    console.error('[Factory] GitHub push failed:', err.message);
    templates.forEach(t => results.failed.push({ id: t.id, error: err.message }));
  }

  return results;
}
