/**
 * Authentication handlers — phone OTP, no passwords.
 */

import { success, error, created, parseBody, validateRequired } from './utils/response.js';
import { sha256, generateToken, generateOTP, hashPhone, timingSafeEqual } from './utils/encryption.js';
import { validatePhone } from './utils/validation.js';

export async function handleSendOTP(request) {
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const missing = validateRequired(body, ['phone']);
  if (missing.length) return error(`Missing required fields: ${missing.join(', ')}`, 400);

  const phoneValidation = validatePhone(body.phone);
  if (!phoneValidation.valid) return error(phoneValidation.error, 400);

  const normalizedPhone = phoneValidation.normalized;
  const phoneHash = await hashPhone(normalizedPhone);
  const otp = generateOTP();
  const otpHash = await sha256(otp);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  const db = request.env.DB;

  await db.prepare(
    'UPDATE otp_codes SET used_at = datetime("now") WHERE phone_hash = ? AND used_at IS NULL AND expires_at > datetime("now")'
  ).bind(phoneHash).run();

  await db.prepare(
    'INSERT INTO otp_codes (phone_hash, otp_hash, expires_at) VALUES (?, ?, ?)'
  ).bind(phoneHash, otpHash, expiresAt).run();

  // Production: send via SMS gateway (Africa's Talking, etc.)
  // await sendSMS(normalizedPhone, `Your SiteForge code: ${otp}`);

  const isDev = request.env.ENVIRONMENT !== 'production';
  return success({
    message: 'OTP sent',
    phoneHash,
    expiresAt,
    ...(isDev && { otp }),
  });
}

export async function handleVerifyOTP(request) {
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const missing = validateRequired(body, ['phone', 'otp']);
  if (missing.length) return error(`Missing required fields: ${missing.join(', ')}`, 400);

  const phoneValidation = validatePhone(body.phone);
  if (!phoneValidation.valid) return error(phoneValidation.error, 400);

  const phoneHash = await hashPhone(phoneValidation.normalized);
  const otpHash = await sha256(String(body.otp));
  const db = request.env.DB;

  const otpRecord = await db.prepare(
    'SELECT id, otp_hash, expires_at, attempts FROM otp_codes WHERE phone_hash = ? AND used_at IS NULL AND expires_at > datetime("now") ORDER BY created_at DESC LIMIT 1'
  ).bind(phoneHash).first();

  if (!otpRecord) return error('OTP expired or not found. Request a new one.', 401);

  if (otpRecord.attempts >= 5) {
    await db.prepare('UPDATE otp_codes SET used_at = datetime("now") WHERE id = ?').bind(otpRecord.id).run();
    return error('Too many attempts. Request a new OTP.', 429);
  }

  if (!timingSafeEqual(otpRecord.otp_hash, otpHash)) {
    await db.prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?').bind(otpRecord.id).run();
    return error('Invalid OTP.', 401);
  }

  await db.prepare('UPDATE otp_codes SET used_at = datetime("now") WHERE id = ?').bind(otpRecord.id).run();

  let user = await db.prepare('SELECT id, status FROM users WHERE phone_hash = ?').bind(phoneHash).first();

  if (!user) {
    const result = await db.prepare(
      'INSERT INTO users (phone_hash, created_at, updated_at, last_login_at) VALUES (?, datetime("now"), datetime("now"), datetime("now"))'
    ).bind(phoneHash).run();
    user = { id: result.meta.last_row_id, status: 'active' };

    await db.prepare(
      `INSERT INTO subscriptions (user_id, plan_id, status, amount, currency, billing_cycle, current_period_start, current_period_end)
       VALUES (?, 'free', 'active', 0, 'USD', 'monthly', datetime('now'), datetime('now', '+100 years'))`
    ).bind(user.id).run();
  } else {
    await db.prepare('UPDATE users SET last_login_at = datetime("now"), updated_at = datetime("now") WHERE id = ?').bind(user.id).run();
  }

  if (user.status === 'suspended') return error('Account suspended. Contact support.', 403);

  const accessToken = generateToken(32);
  const refreshToken = generateToken(48);
  const accessTokenHash = await sha256(accessToken);
  const refreshTokenHash = await sha256(refreshToken);
  const accessExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  const refreshExpiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString();

  await db.prepare(
    'INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at) VALUES (?, ?, ?, ?)'
  ).bind(user.id, accessTokenHash, 'access', accessExpiresAt).run();

  await db.prepare(
    'INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at) VALUES (?, ?, ?, ?)'
  ).bind(user.id, refreshTokenHash, 'refresh', refreshExpiresAt).run();

  const sitesCount = await db.prepare(
    'SELECT COUNT(*) as count FROM sites WHERE user_id = ? AND status != ?'
  ).bind(user.id, 'deleted').first();

  return created({ accessToken, refreshToken, expiresAt: accessExpiresAt, user: { id: user.id, status: user.status, sitesCount: sitesCount?.count || 0 } });
}

export async function handleRefreshToken(request) {
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const missing = validateRequired(body, ['refreshToken']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const refreshTokenHash = await sha256(body.refreshToken);
  const db = request.env.DB;

  const record = await db.prepare(
    'SELECT id, user_id, expires_at FROM auth_tokens WHERE token_hash = ? AND token_type = ? AND revoked_at IS NULL'
  ).bind(refreshTokenHash, 'refresh').first();

  if (!record) return error('Invalid refresh token', 401);
  if (new Date(record.expires_at) < new Date()) return error('Refresh token expired. Please log in again.', 401);

  await db.prepare('UPDATE auth_tokens SET revoked_at = datetime("now") WHERE id = ?').bind(record.id).run();

  const accessToken = generateToken(32);
  const newRefreshToken = generateToken(48);
  const accessExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  const refreshExpiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString();

  await db.prepare(
    'INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at) VALUES (?, ?, ?, ?)'
  ).bind(record.user_id, await sha256(accessToken), 'access', accessExpiresAt).run();

  await db.prepare(
    'INSERT INTO auth_tokens (user_id, token_hash, token_type, expires_at) VALUES (?, ?, ?, ?)'
  ).bind(record.user_id, await sha256(newRefreshToken), 'refresh', refreshExpiresAt).run();

  return success({ accessToken, refreshToken: newRefreshToken, expiresAt: accessExpiresAt });
}

export async function handleGetMe(request) {
  const userId = request.userId;
  const db = request.env.DB;

  const user = await db.prepare('SELECT id, status, created_at, last_login_at FROM users WHERE id = ?').bind(userId).first();
  if (!user) return error('User not found', 404);

  const sites = await db.prepare(
    'SELECT id, site_name, subdomain, custom_domain, status, live_url, has_native_app, created_at FROM sites WHERE user_id = ? AND status != ? ORDER BY created_at DESC'
  ).bind(userId, 'deleted').all();

  const subscriptions = await db.prepare(
    'SELECT id, plan_id, status, amount, billing_cycle, current_period_end FROM subscriptions WHERE user_id = ? AND status = ?'
  ).bind(userId, 'active').all();

  return success({ user: { id: user.id, status: user.status, createdAt: user.created_at, lastLoginAt: user.last_login_at }, sites: sites.results, subscriptions: subscriptions.results });
}

export async function getUser(request) {
  const userId = request.userId;
  if (!userId) return null;
  return request.env.DB.prepare('SELECT id, status FROM users WHERE id = ?').bind(userId).first();
}

export async function hasActivePlan(userId, planId, env) {
  const sub = await env.DB.prepare(
    'SELECT id FROM subscriptions WHERE user_id = ? AND plan_id = ? AND status = ? AND current_period_end > datetime("now")'
  ).bind(userId, planId, 'active').first();
  return !!sub;
}

export async function hasNativeAppAccess(userId, siteId, env) {
  const sub = await env.DB.prepare(
    'SELECT id FROM subscriptions WHERE user_id = ? AND site_id = ? AND plan_id = ? AND status = ? AND current_period_end > datetime("now")'
  ).bind(userId, siteId, 'native_app', 'active').first();
  return !!sub;
}
