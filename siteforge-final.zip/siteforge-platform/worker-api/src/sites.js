/**
 * Sites CRUD handlers.
 */

import { success, error, created, noContent, parseBody, validateRequired, getPagination } from './utils/response.js';
import { validateSiteName, validateSubdomain, validateTemplateId, validateContent } from './utils/validation.js';

// Dynamic list — factory-generated templates are added at runtime via KV
const BUILTIN_TEMPLATES = [
  'restaurant-1', 'restaurant-2', 'restaurant-3',
  'salon-1', 'salon-2',
  'church-1', 'church-2',
  'retail-1', 'retail-2',
  'portfolio-1', 'professional-1',
  'events-1', 'realestate-1', 'education-1', 'ngo-1',
];

async function getAvailableTemplates(env) {
  try {
    const catalog = await env.CONTENT_CACHE.get('template-catalog');
    if (catalog) {
      const dynamic = JSON.parse(catalog).map(t => t.id);
      return [...new Set([...BUILTIN_TEMPLATES, ...dynamic])];
    }
  } catch (e) { /* fallthrough */ }
  return BUILTIN_TEMPLATES;
}

const TEMPLATE_SCHEMA = { required: ['site_name', 'hero_headline', 'footer_text'] };

function defaultContent(templateId) {
  return {
    site_name: 'My Website',
    hero_headline: 'Welcome',
    hero_subheadline: 'Your site is ready',
    hero_image: '',
    about_text: 'Welcome to my website.',
    phone: '',
    whatsapp: '',
    email: '',
    address: '',
    facebook_url: '',
    instagram_url: '',
    footer_text: `© ${new Date().getFullYear()} All rights reserved.`,
  };
}

export async function handleCreateSite(request) {
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const missing = validateRequired(body, ['siteName', 'templateId']);
  if (missing.length) return error(`Missing: ${missing.join(', ')}`, 400);

  const userId = request.userId;
  const db = request.env.DB;

  const nameValidation = validateSiteName(body.siteName);
  if (!nameValidation.valid) return error(nameValidation.error, 400);

  const available = await getAvailableTemplates(request.env);
  const templateValidation = validateTemplateId(body.templateId, available);
  if (!templateValidation.valid) return error(templateValidation.error, 400);

  let subdomain = body.subdomain || (
    body.siteName.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').substring(0, 55)
    + '-' + Math.random().toString(36).substring(2, 6)
  );

  const subdomainValidation = validateSubdomain(subdomain);
  if (!subdomainValidation.valid) return error(subdomainValidation.error, 400);

  const existing = await db.prepare('SELECT id FROM sites WHERE subdomain = ? AND status != ?').bind(subdomainValidation.normalized, 'deleted').first();
  if (existing) return error('Subdomain already taken.', 409);

  const content = defaultContent(body.templateId);
  content.site_name = nameValidation.sanitized;

  const result = await db.prepare(
    `INSERT INTO sites (user_id, template_id, site_name, subdomain, content_json, hosting_type, status)
     VALUES (?, ?, ?, ?, ?, 'managed', 'draft')`
  ).bind(userId, body.templateId, nameValidation.sanitized, subdomainValidation.normalized, JSON.stringify(content)).run();

  const siteId = result.meta.last_row_id;
  const siteUrl = `https://${subdomainValidation.normalized}.siteforge.pages.dev`;

  await db.prepare('UPDATE sites SET live_url = ? WHERE id = ?').bind(siteUrl, siteId).run();

  return created({ site: { id: siteId, siteName: nameValidation.sanitized, subdomain: subdomainValidation.normalized, templateId: body.templateId, liveUrl: siteUrl, status: 'draft', content } });
}

export async function handleListSites(request) {
  const userId = request.userId;
  const db = request.env.DB;
  const { page, limit, offset } = getPagination(request);

  const sites = await db.prepare(
    `SELECT id, template_id, site_name, subdomain, custom_domain, status, live_url, has_native_app,
            app_build_status, app_apk_url, created_at, updated_at
     FROM sites WHERE user_id = ? AND status != ? ORDER BY created_at DESC LIMIT ? OFFSET ?`
  ).bind(userId, 'deleted', limit, offset).all();

  const total = await db.prepare('SELECT COUNT(*) as count FROM sites WHERE user_id = ? AND status != ?').bind(userId, 'deleted').first();

  return success({ sites: sites.results, pagination: { page, limit, total: total.count, totalPages: Math.ceil(total.count / limit) } });
}

export async function handleGetSite(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const db = request.env.DB;

  const site = await db.prepare('SELECT * FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  site.content = JSON.parse(site.content_json || '{}');
  site.appConfig = site.app_config ? JSON.parse(site.app_config) : null;
  delete site.content_json;
  delete site.app_config;

  return success({ site });
}

export async function handleUpdateSite(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const db = request.env.DB;

  const site = await db.prepare('SELECT id FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  const updates = [];
  const values = [];

  if (body.siteName !== undefined) {
    const nameValidation = validateSiteName(body.siteName);
    if (!nameValidation.valid) return error(nameValidation.error, 400);
    updates.push('site_name = ?');
    values.push(nameValidation.sanitized);
  }

  if (body.customDomain !== undefined) {
    const hasPro = await db.prepare(
      'SELECT id FROM subscriptions WHERE user_id = ? AND plan_id = ? AND status = ? AND current_period_end > datetime("now")'
    ).bind(userId, 'pro', 'active').first();
    if (!hasPro && body.customDomain) return error('Custom domain requires a Pro plan.', 402);
    updates.push('custom_domain = ?');
    values.push(body.customDomain || null);
  }

  if (!updates.length) return error('No valid fields to update', 400);
  updates.push('updated_at = datetime("now")');
  values.push(siteId);

  await db.prepare(`UPDATE sites SET ${updates.join(', ')} WHERE id = ?`).bind(...values).run();
  return success({ message: 'Site updated' });
}

export async function handleDeleteSite(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const db = request.env.DB;

  const site = await db.prepare('SELECT id FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  await db.prepare('UPDATE sites SET status = ?, updated_at = datetime("now") WHERE id = ?').bind('deleted', siteId).run();
  return noContent();
}

export async function handleGetContent(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const db = request.env.DB;

  const site = await db.prepare('SELECT id, content_json, template_id FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  return success({ siteId: parseInt(siteId), templateId: site.template_id, content: JSON.parse(site.content_json || '{}') });
}

export async function handleUpdateContent(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const body = await parseBody(request);
  if (!body?.content || typeof body.content !== 'object') return error('content must be a JSON object', 400);
  const db = request.env.DB;

  const site = await db.prepare('SELECT id, template_id, content_json, status FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);

  const existing = JSON.parse(site.content_json || '{}');
  const merged = { ...existing, ...body.content };

  const contentValidation = validateContent(merged, TEMPLATE_SCHEMA);
  if (!contentValidation.valid) return error(contentValidation.error, 400);

  await db.prepare('UPDATE sites SET content_json = ?, updated_at = datetime("now") WHERE id = ?').bind(JSON.stringify(contentValidation.sanitized), siteId).run();
  await db.prepare('INSERT INTO content_revisions (site_id, content_json) VALUES (?, ?)').bind(siteId, JSON.stringify(contentValidation.sanitized)).run();

  if (site.status === 'active') {
    await request.env.BUILD_QUEUE.send({ type: 'deploy-site', payload: { siteId: parseInt(siteId) } });
  }

  return success({ message: 'Content updated', siteId: parseInt(siteId), queued: site.status === 'active' });
}

export async function handleUpdateAppConfig(request) {
  const userId = request.userId;
  const siteId = request.params.id;
  const body = await parseBody(request);
  if (!body) return error('Invalid request body', 400);
  const db = request.env.DB;

  const site = await db.prepare('SELECT id, has_native_app, app_build_status FROM sites WHERE id = ? AND user_id = ? AND status != ?').bind(siteId, userId, 'deleted').first();
  if (!site) return error('Site not found', 404);
  if (!site.has_native_app) return error('Native app not enabled. Purchase the add-on first.', 402);
  if (!body.appConfig || typeof body.appConfig !== 'object') return error('appConfig must be a JSON object', 400);
  if (body.appConfig.appName && (body.appConfig.appName.length < 2 || body.appConfig.appName.length > 30)) {
    return error('App name must be 2-30 characters', 400);
  }

  await db.prepare('UPDATE sites SET app_config = ?, updated_at = datetime("now") WHERE id = ?').bind(JSON.stringify(body.appConfig), siteId).run();

  if (site.app_build_status === 'ready') {
    await request.env.BUILD_QUEUE.send({ type: 'build-apk', payload: { siteId: parseInt(siteId) } });
  }

  return success({ message: 'App config updated', siteId: parseInt(siteId) });
}
