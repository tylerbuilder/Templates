/**
 * Cloudflare OAuth handlers.
 */

import { success, error, redirect } from './utils/response.js';
import { encrypt, decrypt } from './utils/encryption.js';

export async function handleOAuthRedirect(request) {
  const userId = request.userId;
  const url = new URL(request.url);
  const siteId = url.searchParams.get('siteId');
  if (!siteId) return error('Site ID is required', 400);

  const db = request.env.DB;
  const site = await db.prepare('SELECT id FROM sites WHERE id = ? AND user_id = ?').bind(siteId, userId).first();
  if (!site) return error('Site not found', 404);

  const clientId = request.env.CLOUDFLARE_OAUTH_CLIENT_ID;
  if (!clientId) return error('Cloudflare OAuth not configured', 500);

  const oauthUrl = new URL('https://dash.cloudflare.com/oauth2/auth');
  oauthUrl.searchParams.set('response_type', 'code');
  oauthUrl.searchParams.set('client_id', clientId);
  oauthUrl.searchParams.set('redirect_uri', `${request.env.WORKER_API_URL}/api/oauth/cloudflare/callback`);
  oauthUrl.searchParams.set('scope', ['com.cloudflare.api.account:read', 'com.cloudflare.api.pages:edit', 'com.cloudflare.api.dns:edit'].join(' '));
  oauthUrl.searchParams.set('state', `${userId}:${siteId}`);

  return redirect(oauthUrl.toString());
}

export async function handleOAuthCallback(request) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  if (errorParam) return redirect(`${request.env.PLATFORM_URL}/dashboard?error=oauth_denied`);
  if (!code || !state) return redirect(`${request.env.PLATFORM_URL}/dashboard?error=invalid_oauth`);

  const [userId, siteId] = state.split(':');
  if (!userId || !siteId) return redirect(`${request.env.PLATFORM_URL}/dashboard?error=invalid_state`);

  const db = request.env.DB;

  try {
    const tokenRes = await fetch('https://dash.cloudflare.com/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: request.env.CLOUDFLARE_OAUTH_CLIENT_ID,
        client_secret: request.env.CLOUDFLARE_OAUTH_CLIENT_SECRET,
        code,
        redirect_uri: `${request.env.WORKER_API_URL}/api/oauth/cloudflare/callback`,
        grant_type: 'authorization_code',
      }),
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) return redirect(`${request.env.PLATFORM_URL}/dashboard?error=token_exchange_failed`);

    const accountsRes = await fetch('https://api.cloudflare.com/client/v4/accounts', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const accountsData = await accountsRes.json();
    if (!accountsData.success || !accountsData.result.length) return redirect(`${request.env.PLATFORM_URL}/dashboard?error=no_accounts`);

    const accountId = accountsData.result[0].id;
    const env = request.env;
    const accessTokenEncrypted = await encrypt(tokenData.access_token, env);
    const refreshTokenEncrypted = await encrypt(tokenData.refresh_token, env);
    const expiresAt = new Date(Date.now() + (tokenData.expires_in || 86400) * 1000).toISOString();

    await db.prepare(
      `INSERT OR REPLACE INTO cf_oauth_tokens (user_id, cf_account_id, access_token_encrypted, refresh_token_encrypted, expires_at, updated_at)
       VALUES (?, ?, ?, ?, ?, datetime("now"))`
    ).bind(userId, accountId, accessTokenEncrypted, refreshTokenEncrypted, expiresAt).run();

    await db.prepare('UPDATE sites SET hosting_type = ? WHERE id = ? AND user_id = ?').bind('self', siteId, userId).run();
    return redirect(`${request.env.PLATFORM_URL}/dashboard?success=cloudflare_connected`);
  } catch (err) {
    console.error('[OAuth] Callback error:', err.message);
    return redirect(`${request.env.PLATFORM_URL}/dashboard?error=oauth_error`);
  }
}

export async function refreshOAuthToken(userId, db, env) {
  const record = await db.prepare('SELECT * FROM cf_oauth_tokens WHERE user_id = ?').bind(userId).first();
  if (!record) return null;

  if (new Date(record.expires_at) > new Date(Date.now() + 60 * 60 * 1000)) {
    return decrypt(record.access_token_encrypted, env);
  }

  try {
    const refreshToken = await decrypt(record.refresh_token_encrypted, env);
    const res = await fetch('https://dash.cloudflare.com/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: env.CLOUDFLARE_OAUTH_CLIENT_ID, client_secret: env.CLOUDFLARE_OAUTH_CLIENT_SECRET, refresh_token: refreshToken, grant_type: 'refresh_token' }),
    });
    const data = await res.json();
    if (!data.access_token) throw new Error('Refresh failed');

    const newExpiry = new Date(Date.now() + (data.expires_in || 86400) * 1000).toISOString();
    await db.prepare(`UPDATE cf_oauth_tokens SET access_token_encrypted = ?, refresh_token_encrypted = ?, expires_at = ?, updated_at = datetime("now") WHERE user_id = ?`).bind(await encrypt(data.access_token, env), await encrypt(data.refresh_token, env), newExpiry, userId).run();
    return data.access_token;
  } catch (err) {
    console.error('[OAuth] Refresh failed:', err.message);
    return null;
  }
}
