'use strict';

/* ── State ──────────────────────────────────────────────────── */
const S = {
  apiUrl:  localStorage.getItem('sf_api_url')    || 'https://siteforge-api.workers.dev',
  secret:  sessionStorage.getItem('sf_secret')   || '',
  page:    'dashboard',
};

/* ── API ────────────────────────────────────────────────────── */
async function api(method, path, body) {
  const opts = {
    method,
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${S.secret}`,
    },
  };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(`${S.apiUrl}${path}`, opts);
  const json = await res.json();
  if (!json.success) throw new Error(json.error?.message || `HTTP ${res.status}`);
  return json.data;
}

/* ── UI helpers ─────────────────────────────────────────────── */
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('screen--active'));
  document.getElementById(id).classList.add('screen--active');
}

let toastT;
function toast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast${type ? ` toast--${type}` : ''}`;
  el.classList.remove('hidden');
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.add('hidden'), 3200);
}

function loading(show) {
  document.getElementById('loading').classList.toggle('hidden', !show);
}

function html(strings, ...vals) {
  return strings.reduce((out, str, i) => out + str + (vals[i] !== undefined ? escH(vals[i]) : ''), '');
}

function escH(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function badge(status) {
  const map = {
    active: 'green', live: 'green', success: 'green', ok: 'green', configured: 'green',
    draft: 'gray', pending: 'blue', building: 'blue', running: 'blue',
    past_due: 'orange', warning: 'orange', degraded: 'orange',
    failed: 'red', error: 'red', deleted: 'red', missing: 'red', suspended: 'red',
  };
  const color = map[(status || '').toLowerCase()] || 'gray';
  return `<span class="badge badge--${color}"><span class="dot"></span>${escH(status)}</span>`;
}

function ago(dateStr) {
  if (!dateStr) return '—';
  const diff = Date.now() - new Date(dateStr);
  const m = Math.floor(diff / 60000);
  if (m < 1)   return 'just now';
  if (m < 60)  return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24)  return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function fmt(n) {
  return Number(n || 0).toLocaleString();
}

/* ── Login ──────────────────────────────────────────────────── */
function bindLogin() {
  document.getElementById('login-btn').addEventListener('click', async () => {
    const url    = document.getElementById('api-url').value.trim().replace(/\/$/, '');
    const secret = document.getElementById('admin-secret').value.trim();
    const errEl  = document.getElementById('login-error');
    errEl.classList.add('hidden');

    if (!url || !secret) {
      errEl.textContent = 'Both fields are required.';
      errEl.classList.remove('hidden');
      return;
    }

    loading(true);
    try {
      S.apiUrl = url;
      S.secret = secret;
      const data = await api('GET', '/api/admin/status');
      localStorage.setItem('sf_api_url', url);
      sessionStorage.setItem('sf_secret', secret);
      loading(false);
      showScreen('admin-screen');
      renderPage('dashboard');
    } catch (err) {
      loading(false);
      errEl.textContent = `Connection failed: ${err.message}`;
      errEl.classList.remove('hidden');
    }
  });

  document.getElementById('api-url').addEventListener('keydown',    e => { if (e.key === 'Enter') document.getElementById('login-btn').click(); });
  document.getElementById('admin-secret').addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('login-btn').click(); });
}

/* ── Navigation ─────────────────────────────────────────────── */
function bindNav() {
  document.querySelectorAll('.admin-nav__item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.admin-nav__item').forEach(i => i.classList.remove('admin-nav__item--active'));
      item.classList.add('admin-nav__item--active');
      renderPage(item.dataset.page);
    });
  });

  document.getElementById('logout-btn').addEventListener('click', () => {
    sessionStorage.removeItem('sf_secret');
    S.secret = '';
    showScreen('login-screen');
  });
}

function renderPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('page--active'));
  const el = document.getElementById(`page-${page}`);
  if (el) {
    el.classList.add('page--active');
    S.page = page;
    PAGES[page]?.(el);
  }
}

/* ══════════════════════════════════════════════════════════════
   PAGES
══════════════════════════════════════════════════════════════ */

const PAGES = {};

/* ── Dashboard ──────────────────────────────────────────────── */
PAGES.dashboard = async function(el) {
  el.innerHTML = `
    <div class="page-header">
      <h1>Dashboard</h1>
      <button class="btn btn--ghost btn--sm" onclick="PAGES.dashboard(document.getElementById('page-dashboard'))">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
        Refresh
      </button>
    </div>

    <div class="stat-grid" id="dash-stats">
      ${[0,1,2,3].map(() => `<div class="stat-card"><div class="stat-card__label">Loading…</div><div class="stat-card__value" style="font-size:20px;color:var(--border)">—</div></div>`).join('')}
    </div>

    <div class="card">
      <div class="card__header"><span class="card__title">System Health</span></div>
      <div class="card__body"><div id="health-grid" class="health-grid">Loading…</div></div>
    </div>

    <div class="card">
      <div class="card__header"><span class="card__title">Quick Actions</span></div>
      <div class="card__body" style="display:flex;gap:10px;flex-wrap:wrap;">
        <button class="btn btn--primary" id="btn-provision">Run Provision</button>
        <button class="btn btn--outline" id="btn-gen-templates">Generate Templates</button>
        <button class="btn btn--ghost"   id="btn-check-status">Health Check</button>
      </div>
    </div>

    <div class="card hidden" id="action-log-card">
      <div class="card__header"><span class="card__title">Action Output</span></div>
      <div class="card__body"><div id="action-log" class="log-output"></div></div>
    </div>
  `;

  // Load health
  try {
    const data = await api('GET', '/api/admin/status');
    renderHealth(data);
  } catch (err) {
    document.getElementById('health-grid').innerHTML = `<p style="color:var(--red)">Failed to load: ${escH(err.message)}</p>`;
  }

  // Load stats
  try {
    const [sites, templates] = await Promise.allSettled([
      api('GET', '/api/templates?limit=1'),
      api('GET', '/api/admin/status'),
    ]);
    document.getElementById('dash-stats').innerHTML = `
      <div class="stat-card stat-card--blue">
        <div class="stat-card__label">Templates</div>
        <div class="stat-card__value">${fmt(sites.value?.total || 0)}</div>
        <div class="stat-card__sub">in catalog</div>
      </div>
      <div class="stat-card stat-card--green">
        <div class="stat-card__label">System</div>
        <div class="stat-card__value" style="font-size:22px">${templates.value?.status === 'healthy' ? 'Healthy' : 'Degraded'}</div>
        <div class="stat-card__sub">all checks</div>
      </div>
      <div class="stat-card stat-card--orange">
        <div class="stat-card__label">API</div>
        <div class="stat-card__value" style="font-size:22px">Online</div>
        <div class="stat-card__sub">${escH(S.apiUrl)}</div>
      </div>
      <div class="stat-card stat-card--blue">
        <div class="stat-card__label">Environment</div>
        <div class="stat-card__value" style="font-size:20px">Production</div>
        <div class="stat-card__sub">${new Date().toLocaleDateString()}</div>
      </div>
    `;
  } catch (e) { /* stat load failed silently */ }

  // Quick actions
  document.getElementById('btn-provision').addEventListener('click', async () => {
    showLog('Running provision…');
    try {
      const d = await api('POST', '/api/admin/provision');
      appendLog(d.results?.join('\n') || 'Done');
      toast('Provision complete', 'success');
    } catch (err) { appendLog(`ERROR: ${err.message}`); toast(err.message, 'error'); }
  });

  document.getElementById('btn-check-status').addEventListener('click', async () => {
    showLog('Checking status…');
    try {
      const d = await api('GET', '/api/admin/status');
      appendLog(JSON.stringify(d, null, 2));
    } catch (err) { appendLog(`ERROR: ${err.message}`); }
  });

  document.getElementById('btn-gen-templates').addEventListener('click', async () => {
    showLog('Generating templates (apple + bold-colorful + dark-premium)…\nThis may take 30–60 seconds.');
    try {
      const d = await api('POST', '/api/templates/factory/generate', {
        designSystems: ['apple', 'bold-colorful', 'dark-premium'],
        dryRun: false,
      });
      appendLog(`Generated: ${d.generated}\nFailed: ${d.failed}\n\n${JSON.stringify(d.details, null, 2)}`);
      toast(`${d.generated} templates generated`, 'success');
    } catch (err) { appendLog(`ERROR: ${err.message}`); toast(err.message, 'error'); }
  });
};

function renderHealth(data) {
  const checks = data.checks || {};
  const rows = Object.entries(checks).map(([name, val]) => {
    const ok    = val === 'ok' || val === 'configured';
    const warn  = val === 'degraded';
    const cls   = ok ? 'ok' : warn ? 'warn' : 'error';
    return `<div class="health-item health-item--${cls}">
      <span class="health-item__name">${escH(name)}</span>
      <span class="health-item__check">${badge(val)}</span>
    </div>`;
  }).join('');
  document.getElementById('health-grid').innerHTML = rows || '<p>No checks available</p>';
}

function showLog(initial = '') {
  const card = document.getElementById('action-log-card');
  const log  = document.getElementById('action-log');
  card.classList.remove('hidden');
  log.textContent = initial;
  card.scrollIntoView({ behavior: 'smooth' });
}
function appendLog(text) {
  const log = document.getElementById('action-log');
  log.textContent += '\n' + text;
  log.scrollTop = log.scrollHeight;
}

/* ── Users ───────────────────────────────────────────────────── */
PAGES.users = async function(el) {
  el.innerHTML = `
    <div class="page-header"><h1>Users</h1></div>
    <div class="card">
      <div class="card__body">
        <p style="color:var(--muted);text-align:center;padding:40px 0">
          User list requires a direct DB query endpoint.<br>
          Use <code>wrangler d1 execute siteforge-db --command "SELECT id,created_at,last_login_at,status FROM users ORDER BY created_at DESC LIMIT 50"</code>
          or add a <code>GET /api/admin/users</code> endpoint.
        </p>
      </div>
    </div>
  `;
};

/* ── Sites ──────────────────────────────────────────────────── */
PAGES.sites = async function(el) {
  el.innerHTML = `<div class="page-header"><h1>Sites</h1></div><div id="sites-content"><div style="text-align:center;padding:40px;color:var(--muted)">Loading…</div></div>`;
  try {
    // Admin can view all sites via direct DB; for now show a management note
    el.innerHTML = `
      <div class="page-header"><h1>Sites</h1></div>
      <div class="card">
        <div class="card__header"><span class="card__title">Site Management</span></div>
        <div class="card__body">
          <p style="color:var(--muted);margin-bottom:16px">
            To inspect individual sites, use the D1 console or run SQL queries via wrangler.
          </p>
          <div class="log-output" style="margin-bottom:16px">-- Sites summary
SELECT status, COUNT(*) as count FROM sites GROUP BY status;

-- Recently created
SELECT id, site_name, subdomain, status, created_at
FROM sites ORDER BY created_at DESC LIMIT 20;

-- Active with custom domain
SELECT id, site_name, custom_domain
FROM sites WHERE custom_domain IS NOT NULL AND status='active';</div>
          <button class="btn btn--outline btn--sm" onclick="navigator.clipboard?.writeText(document.querySelector('.log-output').textContent);PAGES.sites.toast?.()">Copy SQL</button>
        </div>
      </div>
      <div class="card">
        <div class="card__header"><span class="card__title">Bulk Actions</span></div>
        <div class="card__body" style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="btn btn--outline" id="btn-rebuild-all">Re-deploy All Active Sites</button>
        </div>
        <div id="bulk-log" class="log-output hidden" style="margin:16px;"></div>
      </div>
    `;
    document.getElementById('btn-rebuild-all').addEventListener('click', async () => {
      const log = document.getElementById('bulk-log');
      log.classList.remove('hidden');
      log.textContent = 'This would queue rebuilds for all active sites.\nNot triggered — confirm manually.\n';
      toast('Use the API endpoint /api/sites/:id/rebuild per site', '');
    });
  } catch (err) {
    el.querySelector('#sites-content').innerHTML = `<p style="color:var(--red)">${escH(err.message)}</p>`;
  }
};

/* ── Revenue ─────────────────────────────────────────────────── */
PAGES.subscriptions = async function(el) {
  el.innerHTML = `
    <div class="page-header"><h1>Revenue</h1></div>
    <div class="stat-grid" id="rev-stats">
      <div class="stat-card stat-card--green"><div class="stat-card__label">Active Subs</div><div class="stat-card__value" id="s-active">—</div></div>
      <div class="stat-card stat-card--blue"><div class="stat-card__label">Pro Plans</div><div class="stat-card__value" id="s-pro">—</div></div>
      <div class="stat-card stat-card--orange"><div class="stat-card__label">Native Apps</div><div class="stat-card__value" id="s-app">—</div></div>
      <div class="stat-card stat-card--red"><div class="stat-card__label">Past Due</div><div class="stat-card__value" id="s-due">—</div></div>
    </div>
    <div class="card">
      <div class="card__header"><span class="card__title">Revenue SQL Queries</span></div>
      <div class="card__body">
        <div class="log-output">-- Monthly recurring revenue estimate
SELECT plan_id, COUNT(*) as count, SUM(amount) as mrr
FROM subscriptions WHERE status='active'
GROUP BY plan_id;

-- Expiring this week (need renewal)
SELECT s.id, u.phone_hash, s.plan_id, s.current_period_end
FROM subscriptions s JOIN users u ON u.id=s.user_id
WHERE s.status='active' AND s.current_period_end <= datetime('now','+7 days')
ORDER BY s.current_period_end ASC;

-- Payment history (last 30 days)
SELECT paynow_reference, amount, status, created_at
FROM payments WHERE created_at >= datetime('now','-30 days')
ORDER BY created_at DESC LIMIT 50;</div>
      </div>
    </div>
    <div class="card">
      <div class="card__header"><span class="card__title">Manual Renewal Trigger</span></div>
      <div class="card__body">
        <div class="form-group">
          <label>Subscription ID</label>
          <input id="renewal-sub-id" type="number" placeholder="123" class="form-input" style="max-width:200px">
        </div>
        <button class="btn btn--outline" id="btn-trigger-renewal">Trigger Renewal Charge</button>
        <div id="renewal-result" class="hidden" style="margin-top:12px;"></div>
      </div>
    </div>
  `;

  document.getElementById('btn-trigger-renewal').addEventListener('click', async () => {
    const subId = document.getElementById('renewal-sub-id').value;
    if (!subId) return toast('Enter a subscription ID', 'error');
    try {
      loading(true);
      const d = await api('POST', '/api/paynow/recurring', { subscriptionId: parseInt(subId) });
      loading(false);
      document.getElementById('renewal-result').innerHTML = `<div class="alert alert--success">Renewal triggered. Reference: ${escH(d.reference)}</div>`;
      document.getElementById('renewal-result').classList.remove('hidden');
    } catch (err) {
      loading(false);
      document.getElementById('renewal-result').innerHTML = `<div class="alert alert--error">${escH(err.message)}</div>`;
      document.getElementById('renewal-result').classList.remove('hidden');
    }
  });
};

/* ── Templates ──────────────────────────────────────────────── */
PAGES.templates = async function(el) {
  el.innerHTML = `
    <div class="page-header"><h1>Template Factory</h1></div>
    <div class="card">
      <div class="card__header"><span class="card__title">Generate Templates</span></div>
      <div class="card__body">
        <p style="color:var(--muted);margin-bottom:16px">
          Select which design systems to generate. All 60+ industries are always included.
        </p>
        <div class="factory-options" id="design-options"></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
          <label style="display:flex;align-items:center;gap:6px;font-size:13px">
            <input type="checkbox" id="dry-run-check"> Dry run (preview only, no GitHub push)
          </label>
        </div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn--primary" id="btn-generate">Generate Selected</button>
          <button class="btn btn--ghost"   id="btn-gen-all">Generate All (8 styles)</button>
        </div>
      </div>
    </div>
    <div id="gen-log-card" class="card hidden">
      <div class="card__header"><span class="card__title">Generation Log</span></div>
      <div class="card__body"><div id="gen-log" class="log-output"></div></div>
    </div>
    <div class="card">
      <div class="card__header">
        <span class="card__title">Current Catalog</span>
        <button class="btn btn--ghost btn--sm" id="btn-refresh-catalog">Refresh</button>
      </div>
      <div class="card__body table-wrap">
        <div id="catalog-table">Loading…</div>
      </div>
    </div>
  `;

  const DESIGNS = [
    { id: 'apple',           name: 'Apple-Inspired' },
    { id: 'glassmorphism',   name: 'Glassmorphism' },
    { id: 'bold-colorful',   name: 'Bold & Colorful' },
    { id: 'warm-earthy',     name: 'Warm & Earthy' },
    { id: 'dark-premium',    name: 'Dark Premium' },
    { id: 'minimal-clean',   name: 'Minimal Clean' },
    { id: 'playful-fun',     name: 'Playful & Fun' },
    { id: 'professional-trust', name: 'Professional Trust' },
  ];

  document.getElementById('design-options').innerHTML = DESIGNS.map(d => `
    <label class="factory-option">
      <input type="checkbox" name="design" value="${d.id}" checked>
      <span>${escH(d.name)}</span>
    </label>
  `).join('');

  async function runGenerate(all) {
    const dryRun = document.getElementById('dry-run-check').checked;
    const selected = all
      ? DESIGNS.map(d => d.id)
      : [...document.querySelectorAll('input[name="design"]:checked')].map(i => i.value);

    if (!selected.length) return toast('Select at least one design system', 'error');

    const logCard = document.getElementById('gen-log-card');
    const log     = document.getElementById('gen-log');
    logCard.classList.remove('hidden');
    log.textContent = `Starting generation...\nDesigns: ${selected.join(', ')}\nDry run: ${dryRun}\n`;
    logCard.scrollIntoView({ behavior: 'smooth' });

    try {
      loading(true);
      const d = await api('POST', '/api/templates/factory/generate', { designSystems: selected, dryRun });
      loading(false);
      log.textContent += `\nComplete!\nGenerated: ${d.generated}\nFailed: ${d.failed}`;
      if (d.details?.push) log.textContent += `\nPushed to GitHub: ${d.details.push.pushed?.length || 0}`;
      if (d.details?.pushError) log.textContent += `\nGitHub push error: ${d.details.pushError}`;
      toast(`${d.generated} templates generated`, 'success');
      loadCatalog();
    } catch (err) {
      loading(false);
      log.textContent += `\nERROR: ${err.message}`;
      toast(err.message, 'error');
    }
  }

  document.getElementById('btn-generate').addEventListener('click', () => runGenerate(false));
  document.getElementById('btn-gen-all').addEventListener('click',   () => runGenerate(true));

  async function loadCatalog() {
    const tbl = document.getElementById('catalog-table');
    try {
      const d = await api('GET', '/api/templates?limit=100');
      const rows = (d.templates || []).map(t => `
        <tr>
          <td>${escH(t.id)}</td>
          <td>${escH(t.name)}</td>
          <td>${badge(t.category)}</td>
        </tr>
      `).join('');
      tbl.innerHTML = `<table><thead><tr><th>ID</th><th>Name</th><th>Category</th></tr></thead><tbody>${rows || '<tr><td colspan="3" style="color:var(--muted);text-align:center">No templates yet</td></tr>'}</tbody></table>`;
    } catch (err) {
      tbl.innerHTML = `<p style="color:var(--red)">${escH(err.message)}</p>`;
    }
  }

  document.getElementById('btn-refresh-catalog').addEventListener('click', loadCatalog);
  loadCatalog();
};

/* ── Builds ──────────────────────────────────────────────────── */
PAGES.builds = async function(el) {
  el.innerHTML = `
    <div class="page-header"><h1>Builds &amp; Deployments</h1></div>
    <div class="card">
      <div class="card__header"><span class="card__title">Recent Build Logs (SQL)</span></div>
      <div class="card__body">
        <div class="log-output">-- Recent build logs
SELECT bl.id, s.site_name, bl.build_type, bl.status, bl.started_at, bl.completed_at
FROM build_logs bl
LEFT JOIN sites s ON s.id = bl.site_id
ORDER BY bl.created_at DESC LIMIT 30;

-- Failed builds in last 24h
SELECT bl.*, s.site_name FROM build_logs bl
LEFT JOIN sites s ON s.id = bl.site_id
WHERE bl.status = 'failed' AND bl.created_at >= datetime('now','-1 day')
ORDER BY bl.created_at DESC;</div>
      </div>
    </div>
    <div class="card">
      <div class="card__header"><span class="card__title">Trigger Build</span></div>
      <div class="card__body">
        <div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">
          <div class="form-group" style="margin:0;flex:1;min-width:160px;">
            <label>Site ID</label>
            <input id="build-site-id" type="number" placeholder="42" class="form-input">
          </div>
          <div class="form-group" style="margin:0;">
            <label>Build Type</label>
            <select id="build-type" class="form-input">
              <option value="deploy">Re-deploy Site</option>
              <option value="apk">Rebuild APK</option>
            </select>
          </div>
          <button class="btn btn--primary" id="btn-trigger-build">Trigger</button>
        </div>
        <div id="build-result" class="hidden" style="margin-top:12px;"></div>
      </div>
    </div>
  `;

  document.getElementById('btn-trigger-build').addEventListener('click', async () => {
    const siteId = document.getElementById('build-site-id').value;
    const type   = document.getElementById('build-type').value;
    if (!siteId) return toast('Enter a site ID', 'error');
    const resultEl = document.getElementById('build-result');
    try {
      loading(true);
      const endpoint = type === 'apk' ? '/api/builds/app' : `/api/sites/${siteId}/rebuild`;
      const body     = type === 'apk' ? { siteId: parseInt(siteId) } : undefined;
      const d        = await api('POST', endpoint, body);
      loading(false);
      resultEl.innerHTML = `<div class="alert alert--success">${escH(d.message || 'Queued successfully')}</div>`;
      resultEl.classList.remove('hidden');
    } catch (err) {
      loading(false);
      resultEl.innerHTML = `<div class="alert alert--error">${escH(err.message)}</div>`;
      resultEl.classList.remove('hidden');
    }
  });
};

/* ── Settings ────────────────────────────────────────────────── */
PAGES.settings = async function(el) {
  el.innerHTML = `
    <div class="page-header"><h1>Settings</h1></div>

    <div class="card">
      <div class="card__header"><span class="card__title">Connection</span></div>
      <div class="card__body">
        <div class="form-group">
          <label>API Base URL</label>
          <input id="set-api-url" type="url" value="${escH(S.apiUrl)}" class="form-input">
        </div>
        <div class="form-group">
          <label>Admin Secret (CRON_SECRET)</label>
          <input id="set-secret" type="password" placeholder="••••••••••••" class="form-input">
        </div>
        <button class="btn btn--primary" id="btn-save-connection">Save &amp; Reconnect</button>
      </div>
    </div>

    <div class="card">
      <div class="card__header"><span class="card__title">GitHub Secrets to Update</span></div>
      <div class="card__body">
        <p style="color:var(--muted);font-size:13px;margin-bottom:16px">
          After rotating your Cloudflare or GitHub tokens, update them at:<br>
          <a href="https://github.com/tylerbuilder/siteforge-platform/settings/secrets/actions" target="_blank" rel="noopener">
            github.com/tylerbuilder/siteforge-platform → Settings → Secrets
          </a>
        </p>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Secret Name</th><th>Purpose</th><th>Where to Get It</th></tr></thead>
            <tbody>
              <tr><td><code>CLOUDFLARE_API_TOKEN</code></td><td>Deploy Workers + Pages</td><td>dash.cloudflare.com → Profile → API Tokens</td></tr>
              <tr><td><code>CLOUDFLARE_ACCOUNT_ID</code></td><td>All CF API calls</td><td>dash.cloudflare.com → right sidebar</td></tr>
              <tr><td><code>CRON_SECRET</code></td><td>Admin panel auth</td><td>Generated by bootstrap.sh</td></tr>
              <tr><td><code>PLATFORM_API_KEY</code></td><td>Template factory auth</td><td>Generated by bootstrap.sh</td></tr>
              <tr><td><code>ENCRYPTION_KEY</code></td><td>Encrypt stored tokens</td><td>Generated by bootstrap.sh</td></tr>
              <tr><td><code>PAYNOW_INTEGRATION_ID</code></td><td>Paynow payments</td><td>paynow.co.zw → Merchant portal</td></tr>
              <tr><td><code>PAYNOW_INTEGRATION_SECRET</code></td><td>Paynow signature</td><td>paynow.co.zw → Merchant portal</td></tr>
              <tr><td><code>FCM_SERVER_KEY</code></td><td>Push notifications</td><td>console.firebase.google.com</td></tr>
              <tr><td><code>GITHUB_APP_ID</code></td><td>APK builder repo access</td><td>github.com/settings/apps</td></tr>
              <tr><td><code>GITHUB_APP_PRIVATE_KEY</code></td><td>GitHub App JWT signing</td><td>github.com/settings/apps → generate key</td></tr>
              <tr><td><code>GITHUB_APP_INSTALLATION_ID</code></td><td>GitHub App install</td><td>github.com/settings/apps → installs</td></tr>
              <tr><td><code>GITHUB_WEBHOOK_SECRET</code></td><td>Build callback auth</td><td>Generated by bootstrap.sh</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card__header"><span class="card__title">Danger Zone</span></div>
      <div class="card__body" style="display:flex;gap:10px;flex-wrap:wrap;">
        <button class="btn btn--ghost btn--sm" id="btn-prune-db">Prune Expired DB Rows</button>
        <button class="btn btn--ghost btn--sm" id="btn-clear-kv">Clear Template KV Cache</button>
      </div>
      <div id="danger-result" class="hidden" style="margin:0 20px 16px;"></div>
    </div>
  `;

  document.getElementById('btn-save-connection').addEventListener('click', () => {
    const url    = document.getElementById('set-api-url').value.trim().replace(/\/$/, '');
    const secret = document.getElementById('set-secret').value.trim();
    if (url) { S.apiUrl = url; localStorage.setItem('sf_api_url', url); }
    if (secret) { S.secret = secret; sessionStorage.setItem('sf_secret', secret); }
    toast('Settings saved. Reconnecting…', 'success');
    setTimeout(() => renderPage('dashboard'), 800);
  });

  document.getElementById('btn-prune-db').addEventListener('click', async () => {
    try {
      loading(true);
      const d = await api('POST', '/api/admin/provision');
      loading(false);
      const res = document.getElementById('danger-result');
      res.innerHTML = `<div class="alert alert--success">${escH((d.results || []).join('\n'))}</div>`;
      res.classList.remove('hidden');
    } catch (err) { loading(false); toast(err.message, 'error'); }
  });

  document.getElementById('btn-clear-kv').addEventListener('click', () => {
    toast('KV cache cleared via wrangler: wrangler kv:key delete --namespace-id=<id> template-catalog', '');
  });
};

/* ── Boot ────────────────────────────────────────────────────── */
function init() {
  bindLogin();
  bindNav();

  // Auto-login if we have a stored secret
  if (S.secret && S.apiUrl) {
    api('GET', '/api/admin/status')
      .then(() => { showScreen('admin-screen'); renderPage('dashboard'); })
      .catch(() => { showScreen('login-screen'); });
  } else {
    showScreen('login-screen');
  }
}

document.addEventListener('DOMContentLoaded', init);
