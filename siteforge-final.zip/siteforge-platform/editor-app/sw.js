/**
 * SiteForge Service Worker — offline-first PWA.
 * Cache-first for shell assets, network-first for API calls.
 */

const CACHE_VERSION = 'v1';
const SHELL_CACHE   = `siteforge-shell-${CACHE_VERSION}`;
const API_CACHE     = `siteforge-api-${CACHE_VERSION}`;

const SHELL_ASSETS = [
  '/',
  '/index.html',
  '/assets/css/editor.css',
  '/assets/js/offline-db.js',
  '/assets/js/app.js',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap',
];

// ── Install ───────────────────────────────────────────────────────────────────

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then(cache => cache.addAll(SHELL_ASSETS)).then(() => self.skipWaiting())
  );
});

// ── Activate ──────────────────────────────────────────────────────────────────

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== SHELL_CACHE && k !== API_CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// ── Fetch ─────────────────────────────────────────────────────────────────────

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Skip non-GET and DevTools requests
  if (event.request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // API calls — network-first, fall back to cache (GET only)
  if (url.hostname === 'api.siteforge.co.zw') {
    event.respondWith(networkFirstWithCache(event.request, API_CACHE));
    return;
  }

  // Shell assets — cache-first
  event.respondWith(cacheFirstWithNetwork(event.request, SHELL_CACHE));
});

async function cacheFirstWithNetwork(request, cacheName) {
  const cache    = await caches.open(cacheName);
  const cached   = await cache.match(request);
  if (cached) return cached;
  try {
    const fresh = await fetch(request);
    if (fresh.ok) cache.put(request, fresh.clone());
    return fresh;
  } catch (e) {
    // Return the app shell for navigation requests
    if (request.mode === 'navigate') {
      const shell = await caches.match('/index.html');
      if (shell) return shell;
    }
    return new Response('Offline', { status: 503, statusText: 'Service Unavailable' });
  }
}

async function networkFirstWithCache(request, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const fresh = await fetch(request);
    if (fresh.ok) cache.put(request, fresh.clone());
    return fresh;
  } catch (e) {
    const cached = await cache.match(request);
    if (cached) return cached;
    return new Response(JSON.stringify({ success: false, error: { message: 'Offline — no cached data' } }), {
      status: 503, headers: { 'Content-Type': 'application/json' },
    });
  }
}

// ── Push notifications ────────────────────────────────────────────────────────

self.addEventListener('push', event => {
  if (!event.data) return;
  try {
    const payload = event.data.json();
    event.waitUntil(
      self.registration.showNotification(payload.notification?.title || 'SiteForge', {
        body:   payload.notification?.body || '',
        icon:   '/icons/icon-192.png',
        badge:  '/icons/badge-72.png',
        data:   payload.data || {},
        actions: [{ action: 'open', title: 'Open' }],
      })
    );
  } catch (e) { console.error('[SW] Push parse error:', e); }
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const targetUrl = event.notification.data?.target_url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windowClients => {
      const existing = windowClients.find(c => c.url.includes(self.location.origin));
      if (existing) { existing.focus(); existing.postMessage({ type: 'notification-click', url: targetUrl }); }
      else clients.openWindow(targetUrl);
    })
  );
});
