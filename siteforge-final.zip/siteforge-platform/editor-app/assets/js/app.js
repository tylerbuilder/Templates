/**
 * SiteForge Editor — main application.
 * Offline-first: reads from IndexedDB, syncs when online.
 */

'use strict';

const API_BASE = 'https://api.siteforge.co.zw';

// ─── State ────────────────────────────────────────────────────────────────────

const State = {
  token:       null,
  userId:      null,
  currentSite: null,
  currentPage: 'home',
  sites:       [],
  templates:   [],
  dirty:       false,
  online:      navigator.onLine,
};

// ─── API ──────────────────────────────────────────────────────────────────────

async function api(method, path, body) {
  const headers = { 'Content-Type': 'application/json' };
  if (State.token) headers['Authorization'] = `Bearer ${State.token}`;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${API_BASE}${path}`, opts);
  const json = await res.json();
  if (!json.success) throw new Error(json.error?.message || 'Request failed');
  return json.data;
}

// ─── UI helpers ──────────────────────────────────────────────────────────────

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('screen--active'));
  document.getElementById(id).classList.add('screen--active');
}

function showLoading(msg = 'Loading…') {
  const el = document.getElementById('loading-overlay');
  document.getElementById('loading-message').textContent = msg;
  el.classList.remove('hidden');
}

function hideLoading() { document.getElementById('loading-overlay').classList.add('hidden'); }

let toastTimer = null;
function showToast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast${type ? ` toast--${type}` : ''}`;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 3000);
}

function setSaveStatus(msg) { document.getElementById('save-status').textContent = msg; }

// ─── Auth ─────────────────────────────────────────────────────────────────────

async function init() {
  State.token  = await SiteForgeDB.getSetting('authToken');
  State.userId = await SiteForgeDB.getSetting('userId');

  window.addEventListener('online',  () => { State.online = true;  document.getElementById('offline-badge').classList.add('hidden');    processSyncQueue(); });
  window.addEventListener('offline', () => { State.online = false; document.getElementById('offline-badge').classList.remove('hidden'); });

  if (!navigator.onLine) document.getElementById('offline-badge').classList.remove('hidden');

  if (State.token) {
    await loadDashboard();
  } else {
    showScreen('auth-screen');
  }

  bindAuthHandlers();
  bindDashboardHandlers();
  bindEditorHandlers();
}

function bindAuthHandlers() {
  document.getElementById('send-otp-btn').addEventListener('click', async () => {
    const phone = document.getElementById('phone-input').value.trim();
    if (!phone) return showAuthError('Enter your phone number');
    try {
      showLoading('Sending code…');
      await api('POST', '/api/auth/send-otp', { phone });
      hideLoading();
      document.querySelector('.auth-phone-display').textContent = `Code sent to ${phone}`;
      document.getElementById('otp-step-phone').classList.add('hidden');
      document.getElementById('otp-step-verify').classList.remove('hidden');
    } catch (err) { hideLoading(); showAuthError(err.message); }
  });

  document.getElementById('verify-otp-btn').addEventListener('click', async () => {
    const phone = document.getElementById('phone-input').value.trim();
    const otp   = document.getElementById('otp-input').value.trim();
    if (!otp || otp.length !== 6) return showAuthError('Enter the 6-digit code');
    try {
      showLoading('Verifying…');
      const data = await api('POST', '/api/auth/verify-otp', { phone, otp });
      await SiteForgeDB.saveSetting('authToken', data.accessToken);
      await SiteForgeDB.saveSetting('userId',    data.user.id);
      State.token  = data.accessToken;
      State.userId = data.user.id;
      hideLoading();
      await loadDashboard();
    } catch (err) { hideLoading(); showAuthError(err.message); }
  });

  document.getElementById('resend-otp-btn').addEventListener('click', () => {
    document.getElementById('otp-step-verify').classList.add('hidden');
    document.getElementById('otp-step-phone').classList.remove('hidden');
    document.getElementById('auth-error').classList.add('hidden');
  });

  document.getElementById('phone-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('send-otp-btn').click();
  });

  document.getElementById('otp-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('verify-otp-btn').click();
  });
}

function showAuthError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

async function loadDashboard() {
  showScreen('dashboard-screen');
  showLoading('Loading your sites…');

  // Load from IDB first (instant)
  const localSites = await SiteForgeDB.getSitesByUser(State.userId);
  renderSitesGrid(localSites);

  // Then fetch from API
  if (State.online) {
    try {
      const data = await api('GET', '/api/sites');
      State.sites = data.sites;
      for (const site of data.sites) await SiteForgeDB.saveSite({ ...site, userId: State.userId });
      renderSitesGrid(data.sites);
    } catch (err) {
      console.warn('[Dashboard] API fetch failed, using offline data:', err.message);
    }
  }

  hideLoading();
}

function renderSitesGrid(sites) {
  const grid  = document.getElementById('sites-grid');
  const empty = document.getElementById('empty-state');

  if (!sites || !sites.length) {
    grid.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  grid.innerHTML = sites.map(site => `
    <div class="site-card" data-site-id="${site.id}">
      <div class="site-card__thumb">
        <span class="site-card__status site-card__status--${site.status}">${site.status}</span>
      </div>
      <div class="site-card__body">
        <div class="site-card__name">${escHtml(site.site_name || site.siteName)}</div>
        <div class="site-card__url">${escHtml(site.live_url || site.liveUrl || site.subdomain + '.siteforge.pages.dev')}</div>
      </div>
      <div class="site-card__actions">
        <button class="btn btn--outline btn--sm js-edit-site" data-site-id="${site.id}">Edit</button>
        ${site.live_url || site.liveUrl ? `<a class="btn btn--ghost btn--sm" href="${site.live_url || site.liveUrl}" target="_blank" rel="noopener">View</a>` : ''}
      </div>
    </div>
  `).join('');

  grid.querySelectorAll('.js-edit-site').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      openEditor(parseInt(btn.dataset.siteId));
    });
  });
}

function bindDashboardHandlers() {
  document.getElementById('create-site-btn').addEventListener('click', openTemplateChooser);
  document.querySelector('.js-create-site-trigger')?.addEventListener('click', openTemplateChooser);
  document.getElementById('logout-btn').addEventListener('click', async () => {
    await SiteForgeDB.clearAuthData();
    State.token = null; State.userId = null;
    showScreen('auth-screen');
  });
}

// ─── Template chooser ─────────────────────────────────────────────────────────

async function openTemplateChooser() {
  showScreen('template-screen');

  // Load from cache first
  const cached = await SiteForgeDB.getAllTemplates();
  renderTemplates(cached);

  if (State.online) {
    try {
      const data = await api('GET', '/api/templates');
      State.templates = data.templates;
      for (const t of data.templates) await SiteForgeDB.saveTemplate(t);
      renderTemplates(data.templates);
      renderCategoryFilters(data.categories);
    } catch (err) { console.warn('[Templates] Load error:', err.message); }
  }
}

function renderTemplates(templates) {
  const grid = document.getElementById('template-grid');
  if (!templates?.length) {
    grid.innerHTML = '<p style="color:#86868b;text-align:center;padding:40px;grid-column:1/-1">No templates available offline. Connect to load templates.</p>';
    return;
  }

  grid.innerHTML = templates.map(t => `
    <div class="template-card" data-template-id="${t.id}">
      <div class="template-card__thumb">
        ${t.thumbnail ? `<img src="${t.thumbnail}" alt="${t.name}" loading="lazy">` : ''}
      </div>
      <div class="template-card__body">
        <div class="template-card__name">${escHtml(t.name)}</div>
        <div class="template-card__cat">${escHtml(t.category)}</div>
      </div>
    </div>
  `).join('');

  grid.querySelectorAll('.template-card').forEach(card => {
    card.addEventListener('click', () => createSiteFromTemplate(card.dataset.templateId));
  });
}

function renderCategoryFilters(categories) {
  const bar = document.querySelector('.template-filters');
  const chips = categories.map(c => `<button class="chip" data-category="${c}">${c.charAt(0).toUpperCase() + c.slice(1)}</button>`).join('');
  bar.innerHTML = `<button class="chip chip--active" data-category="all">All</button>${chips}`;

  bar.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      bar.querySelectorAll('.chip').forEach(c => c.classList.remove('chip--active'));
      chip.classList.add('chip--active');
      const cat = chip.dataset.category;
      const filtered = cat === 'all' ? State.templates : State.templates.filter(t => t.category === cat);
      renderTemplates(filtered);
    });
  });
}

async function createSiteFromTemplate(templateId) {
  const siteName = prompt('What\'s your business name?');
  if (!siteName) return;

  showLoading('Creating your site…');
  try {
    const data = await api('POST', '/api/sites', { siteName, templateId });
    await SiteForgeDB.saveSite({ ...data.site, userId: State.userId });
    State.sites.unshift(data.site);
    hideLoading();
    await openEditor(data.site.id);
  } catch (err) {
    hideLoading();
    showToast(err.message, 'error');
  }
}

// ─── Editor ───────────────────────────────────────────────────────────────────

async function openEditor(siteId) {
  showLoading('Opening editor…');

  // Load from IDB first
  let site    = await SiteForgeDB.getSite(siteId);
  let content = await SiteForgeDB.getContent(siteId);

  if (State.online) {
    try {
      const siteData    = await api('GET', `/api/sites/${siteId}`);
      const contentData = await api('GET', `/api/sites/${siteId}/content`);
      site    = siteData.site;
      content = contentData.content;
      await SiteForgeDB.saveSite({ ...site, userId: State.userId });
      await SiteForgeDB.saveContent(siteId, content);
    } catch (err) { console.warn('[Editor] API load error:', err.message); }
  }

  if (!site) { hideLoading(); showToast('Site not found', 'error'); return; }

  State.currentSite = { ...site, content: content || site.content || {} };
  State.dirty = false;

  showScreen('editor-screen');
  document.getElementById('editor-site-name').textContent = site.site_name || site.siteName;

  renderContentFields();
  renderPageTabs();
  renderPublishPanel();
  renderAppPanel();
  await updatePreview();

  hideLoading();
}

function renderContentFields() {
  const container = document.getElementById('content-fields');
  const content   = State.currentSite.content || {};

  const FIELD_DEFS = [
    { key: 'site_name',        label: 'Business Name',   type: 'text' },
    { key: 'hero_headline',    label: 'Hero Headline',   type: 'text' },
    { key: 'hero_subheadline', label: 'Subheadline',     type: 'text' },
    { key: 'about_text',       label: 'About Us',        type: 'textarea' },
    { key: 'phone',            label: 'Phone',           type: 'tel' },
    { key: 'whatsapp',         label: 'WhatsApp Number', type: 'tel' },
    { key: 'email',            label: 'Email',           type: 'email' },
    { key: 'address',          label: 'Address',         type: 'text' },
    { key: 'facebook_url',     label: 'Facebook URL',    type: 'url' },
    { key: 'instagram_url',    label: 'Instagram URL',   type: 'url' },
    { key: 'footer_text',      label: 'Footer Text',     type: 'text' },
  ];

  container.innerHTML = FIELD_DEFS.map(f => {
    const val = escHtml(String(content[f.key] || ''));
    if (f.type === 'textarea') {
      return `<div class="field-group"><label>${f.label}</label><textarea class="form-input js-content-field" data-key="${f.key}" rows="3">${val}</textarea></div>`;
    }
    return `<div class="field-group"><label>${f.label}</label><input type="${f.type || 'text'}" class="form-input js-content-field" data-key="${f.key}" value="${val}"></div>`;
  }).join('');

  container.querySelectorAll('.js-content-field').forEach(input => {
    input.addEventListener('input', () => {
      State.currentSite.content[input.dataset.key] = input.value;
      State.dirty = true;
      setSaveStatus('Unsaved changes');
      debouncedPreview();
    });
  });
}

function renderPageTabs() {
  const bar  = document.getElementById('preview-pages');
  const site = State.currentSite;
  const pages = ['home', 'about', 'menu', 'services', 'gallery', 'products', 'contact']
    .filter(p => {
      if (p === 'home' || p === 'contact') return true;
      // Show pages that have a corresponding HTML in the template
      return true;
    });

  bar.innerHTML = pages.map(p => `
    <button class="preview-page-btn${p === State.currentPage ? ' preview-page-btn--active' : ''}" data-page="${p}">
      ${p.charAt(0).toUpperCase() + p.slice(1)}
    </button>
  `).join('');

  bar.querySelectorAll('.preview-page-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      State.currentPage = btn.dataset.page;
      bar.querySelectorAll('.preview-page-btn').forEach(b => b.classList.remove('preview-page-btn--active'));
      btn.classList.add('preview-page-btn--active');
      updatePreview();
    });
  });
}

function renderPublishPanel() {
  const panel = document.getElementById('publish-status');
  const site  = State.currentSite;
  const status = site.status;
  const url    = site.live_url || site.liveUrl;

  panel.innerHTML = `
    <div class="publish-status-display">
      <strong>Status:</strong> ${status === 'active' ? 'Live' : status === 'draft' ? 'Draft' : status}
      ${url ? `<br><a href="${url}" target="_blank" rel="noopener">${url}</a>` : ''}
    </div>
  `;

  const liveLink = document.getElementById('live-url-link');
  if (url) { liveLink.href = url; liveLink.classList.remove('hidden'); }
  else { liveLink.classList.add('hidden'); }
}

function renderAppPanel() {
  const display  = document.getElementById('app-status-display');
  const configEl = document.getElementById('app-config-fields');
  const site     = State.currentSite;

  if (!site.has_native_app) {
    display.innerHTML = `<h3>Native App</h3><p>Add a native Android app for your business for $30/year.</p><button class="btn btn--primary" onclick="window.open('https://siteforge.co.zw/upgrade', '_blank')">Get the App Add-On</button>`;
    configEl.classList.add('hidden');
  } else {
    const buildStatus = site.app_build_status || 'unknown';
    display.innerHTML = `<h3>App Status: ${buildStatus}</h3>${site.app_apk_url ? `<a class="btn btn--outline btn--full" href="${site.app_apk_url}" target="_blank" download>Download APK</a>` : ''}`;
    configEl.classList.remove('hidden');
    const cfg = site.appConfig || {};
    document.getElementById('app-name').value          = cfg.appName || site.site_name || '';
    document.getElementById('app-primary-color').value = cfg.primaryColor || '#0071e3';
    document.getElementById('app-splash-color').value  = cfg.splashColor  || '#ffffff';
  }
}

const debouncedPreview = debounce(updatePreview, 600);

async function updatePreview() {
  const frame   = document.getElementById('preview-frame');
  const content = State.currentSite?.content || {};
  const page    = State.currentPage;

  // Build a minimal live preview from current content values
  const preview = buildPreviewHTML(page, content);
  const blob    = new Blob([preview], { type: 'text/html' });
  const url     = URL.createObjectURL(blob);
  frame.src     = url;
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function buildPreviewHTML(page, content) {
  const siteName = content.site_name || 'My Business';
  const primary  = '#0071e3';

  const headline = page === 'home'    ? (content.hero_headline    || 'Welcome')
                 : page === 'contact' ? 'Contact Us'
                 : page === 'about'   ? 'About Us'
                 : page.charAt(0).toUpperCase() + page.slice(1);

  return `<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escHtml(siteName)}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,system-ui,sans-serif;color:#1d1d1f;background:#fff}
.header{background:${primary};color:#fff;padding:16px 20px;display:flex;justify-content:space-between;align-items:center}
.header span{font-size:16px;font-weight:700}
.hero{background:linear-gradient(135deg,${primary},#005bb5);color:#fff;padding:48px 20px;text-align:center}
.hero h1{font-size:28px;font-weight:700;margin-bottom:10px}
.hero p{font-size:16px;opacity:.85;margin-bottom:24px}
.btn{display:inline-block;padding:12px 24px;border-radius:8px;font-weight:600;font-size:14px;background:#fff;color:${primary};text-decoration:none}
.section{padding:32px 20px}
.section h2{font-size:20px;font-weight:700;margin-bottom:12px}
.section p{font-size:15px;color:#555;line-height:1.6}
.contact-item{margin-bottom:12px}
.contact-item strong{display:block;font-size:12px;text-transform:uppercase;color:#86868b;margin-bottom:3px}
.footer{background:#f5f5f7;padding:20px;text-align:center;font-size:12px;color:#86868b;border-top:1px solid #e2e2e5}
</style></head><body>
<div class="header"><span>${escHtml(siteName)}</span></div>
${page === 'home' ? `
<div class="hero">
  <h1>${escHtml(content.hero_headline || 'Welcome')}</h1>
  <p>${escHtml(content.hero_subheadline || '')}</p>
  ${content.whatsapp ? `<a href="https://wa.me/${content.whatsapp}" class="btn">WhatsApp Us</a>` : '<a href="#" class="btn">Get in Touch</a>'}
</div>
<div class="section"><h2>About Us</h2><p>${escHtml(content.about_text || '')}</p></div>` : ''}
${page === 'about' ? `
<div class="section"><h2>About Us</h2><p>${escHtml(content.about_text || '')}</p></div>` : ''}
${page === 'contact' ? `
<div class="section">
  <h2>Contact Us</h2>
  ${content.phone   ? `<div class="contact-item"><strong>Phone</strong>${escHtml(content.phone)}</div>` : ''}
  ${content.whatsapp? `<div class="contact-item"><strong>WhatsApp</strong>${escHtml(content.whatsapp)}</div>` : ''}
  ${content.email   ? `<div class="contact-item"><strong>Email</strong>${escHtml(content.email)}</div>` : ''}
  ${content.address ? `<div class="contact-item"><strong>Address</strong>${escHtml(content.address)}</div>` : ''}
</div>` : ''}
${!['home','about','contact'].includes(page) ? `<div class="section"><h2>${escHtml(headline)}</h2><p>Content for this page will appear here once you edit and save.</p></div>` : ''}
<div class="footer">${escHtml(content.footer_text || `© ${new Date().getFullYear()} ${siteName}`)}</div>
</body></html>`;
}

// ─── Editor handlers ──────────────────────────────────────────────────────────

function bindEditorHandlers() {
  // Tab switching
  document.querySelectorAll('.editor-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.editor-tab').forEach(t => t.classList.remove('editor-tab--active'));
      document.querySelectorAll('.editor-panel').forEach(p => p.classList.remove('editor-panel--active'));
      tab.classList.add('editor-tab--active');
      document.getElementById(`tab-${tab.dataset.tab}`)?.classList.add('editor-panel--active');
    });
  });

  // Viewport toggle
  document.querySelectorAll('.viewport-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.viewport-btn').forEach(b => b.classList.remove('viewport-btn--active'));
      btn.classList.add('viewport-btn--active');
      const frame = document.getElementById('preview-frame');
      const wrap  = document.getElementById('preview-frame-wrap');
      if (btn.dataset.viewport === 'desktop') {
        frame.classList.add('desktop');
        wrap.classList.add('preview-frame-wrap--desktop');
        wrap.classList.remove('preview-frame-wrap--mobile');
      } else {
        frame.classList.remove('desktop');
        wrap.classList.add('preview-frame-wrap--mobile');
        wrap.classList.remove('preview-frame-wrap--desktop');
      }
    });
  });

  // Back to dashboard
  document.querySelector('.js-back-dashboard')?.addEventListener('click', () => {
    if (State.dirty && !confirm('You have unsaved changes. Leave anyway?')) return;
    showScreen('dashboard-screen');
    loadDashboard();
  });

  // Back from template chooser
  document.querySelector('#template-screen .js-back')?.addEventListener('click', () => {
    showScreen('dashboard-screen');
  });

  // Save content
  document.getElementById('save-content-btn').addEventListener('click', saveContent);

  // Publish
  document.getElementById('publish-btn').addEventListener('click', publishSite);

  // Save domain
  document.getElementById('save-domain-btn').addEventListener('click', saveDomain);

  // Save app config
  document.getElementById('save-app-config-btn')?.addEventListener('click', saveAppConfig);
}

async function saveContent() {
  const siteId  = State.currentSite.id;
  const content = State.currentSite.content;

  // Always save locally first
  await SiteForgeDB.saveContent(siteId, content);
  setSaveStatus('Saved locally');

  if (!State.online) {
    await SiteForgeDB.addToSyncQueue({ type: 'update-content', siteId, content });
    setSaveStatus('Queued — will sync when online');
    return;
  }

  try {
    setSaveStatus('Saving…');
    await api('PUT', `/api/sites/${siteId}/content`, { content });
    State.dirty = false;
    setSaveStatus('Saved ' + new Date().toLocaleTimeString());
    showToast('Changes saved', 'success');
  } catch (err) {
    await SiteForgeDB.addToSyncQueue({ type: 'update-content', siteId, content });
    setSaveStatus('Queued — will retry');
    showToast('Saved offline. Will sync when online.', '');
  }
}

async function publishSite() {
  if (!State.online) return showToast('Cannot publish while offline', 'error');
  if (State.dirty) await saveContent();

  showLoading('Publishing…');
  try {
    await api('POST', `/api/sites/${State.currentSite.id}/publish`);
    State.currentSite.status = 'active';
    renderPublishPanel();
    hideLoading();
    showToast('Site published!', 'success');
  } catch (err) { hideLoading(); showToast(err.message, 'error'); }
}

async function saveDomain() {
  const domain = document.getElementById('custom-domain-input').value.trim();
  if (!domain || !State.online) return;
  try {
    await api('PATCH', `/api/sites/${State.currentSite.id}`, { customDomain: domain });
    showToast('Domain saved', 'success');
  } catch (err) { showToast(err.message, 'error'); }
}

async function saveAppConfig() {
  const cfg = {
    appName:      document.getElementById('app-name').value.trim(),
    primaryColor: document.getElementById('app-primary-color').value,
    splashColor:  document.getElementById('app-splash-color').value,
  };
  try {
    await api('PUT', `/api/sites/${State.currentSite.id}/app-config`, { appConfig: cfg });
    showToast('App config saved. Rebuild queued.', 'success');
  } catch (err) { showToast(err.message, 'error'); }
}

// ─── Sync queue ───────────────────────────────────────────────────────────────

async function processSyncQueue() {
  const items = await SiteForgeDB.getPendingSyncItems();
  for (const item of items) {
    try {
      if (item.type === 'update-content') {
        await api('PUT', `/api/sites/${item.siteId}/content`, { content: item.content });
        await SiteForgeDB.markSyncItemComplete(item.id);
      }
    } catch (err) {
      console.warn('[Sync] Failed:', err.message);
      await SiteForgeDB.markSyncItemFailed(item.id);
    }
  }
  if (items.length) setSaveStatus(`Synced ${items.length} item(s)`);
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function escHtml(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function debounce(fn, ms) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

// ─── Boot ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', init);
