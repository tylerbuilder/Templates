/**
 * SiteForge offline IndexedDB layer (idb-keyval-style but hand-rolled for full control).
 *
 * Fixes vs original:
 *  1. tx.complete is NOT a valid IDBTransaction property — all ops use explicit
 *     Promise wrappers around IDBRequest.onsuccess/onerror.
 *  2. getStorageInfo defined exactly ONCE (was defined twice with different fields).
 *  3. cleanupSyncQueue keeps the OLDEST items (FIFO) when cap is exceeded,
 *     not the newest — oldest = highest priority for processing.
 */

'use strict';

const DB_NAME    = 'siteforge-offline';
const DB_VERSION = 1;

const STORES = {
  sites:     { keyPath: 'id', indexes: [['userId', 'userId'], ['status', 'status'], ['updatedAt', 'updatedAt']] },
  content:   { keyPath: 'siteId', indexes: [['updatedAt', 'updatedAt']] },
  templates: { keyPath: 'id', indexes: [['category', 'category']] },
  syncQueue: { keyPath: 'id', autoIncrement: true, indexes: [['status', 'status'], ['createdAt', 'createdAt']] },
  media:     { keyPath: 'id', indexes: [['siteId', 'siteId']] },
  settings:  { keyPath: 'key' },
  sessions:  { keyPath: 'id' },
};

const MAX_STORED_SITES    = 10;
const MAX_SYNC_QUEUE_ITEMS = 100;

let _db = null;

// ─── Core open ───────────────────────────────────────────────────────────────

function openDB() {
  if (_db) return Promise.resolve(_db);

  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (event) => {
      const db = event.target.result;
      for (const [storeName, config] of Object.entries(STORES)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = config.autoIncrement
            ? db.createObjectStore(storeName, { keyPath: config.keyPath, autoIncrement: true })
            : db.createObjectStore(storeName, { keyPath: config.keyPath });

          for (const [indexName, keyPath] of (config.indexes || [])) {
            store.createIndex(indexName, keyPath, { unique: false });
          }
        }
      }
    };

    req.onsuccess = (e) => { _db = e.target.result; resolve(_db); };
    req.onerror   = (e) => reject(new Error(`IndexedDB open failed: ${e.target.error}`));
  });
}

// ─── Generic helpers ─────────────────────────────────────────────────────────

function idbRequest(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror   = (e) => reject(new Error(`IDB error: ${e.target.error}`));
  });
}

async function storeGet(storeName, key) {
  const db = await openDB();
  return idbRequest(db.transaction(storeName, 'readonly').objectStore(storeName).get(key));
}

async function storePut(storeName, value) {
  const db = await openDB();
  return idbRequest(db.transaction(storeName, 'readwrite').objectStore(storeName).put(value));
}

async function storeDelete(storeName, key) {
  const db = await openDB();
  return idbRequest(db.transaction(storeName, 'readwrite').objectStore(storeName).delete(key));
}

async function storeGetAll(storeName) {
  const db = await openDB();
  return idbRequest(db.transaction(storeName, 'readonly').objectStore(storeName).getAll());
}

async function storeGetAllByIndex(storeName, indexName, value) {
  const db = await openDB();
  const range = IDBKeyRange.only(value);
  return idbRequest(db.transaction(storeName, 'readonly').objectStore(storeName).index(indexName).getAll(range));
}

async function storeCount(storeName) {
  const db = await openDB();
  return idbRequest(db.transaction(storeName, 'readonly').objectStore(storeName).count());
}

// ─── Sites ───────────────────────────────────────────────────────────────────

async function saveSite(site) {
  const record = { ...site, savedLocally: true, lastAccessed: new Date().toISOString() };
  await storePut('sites', record);
  await cleanupOldSites();
  return record;
}

async function getSite(siteId) {
  const site = await storeGet('sites', siteId);
  if (site) await storePut('sites', { ...site, lastAccessed: new Date().toISOString() });
  return site;
}

async function getSitesByUser(userId) {
  return storeGetAllByIndex('sites', 'userId', userId);
}

async function deleteSiteLocally(siteId) {
  await storeDelete('sites', siteId);
  await storeDelete('content', siteId);
}

async function cleanupOldSites() {
  const all = await storeGetAll('sites');
  if (all.length <= MAX_STORED_SITES) return;

  // Sort newest first; delete the tail (oldest)
  const sorted = [...all].sort((a, b) =>
    new Date(b.lastAccessed || b.updatedAt || 0) - new Date(a.lastAccessed || a.updatedAt || 0)
  );

  const db = await openDB();
  for (const site of sorted.slice(MAX_STORED_SITES)) {
    const tx = db.transaction(['sites', 'content'], 'readwrite');
    tx.objectStore('sites').delete(site.id);
    tx.objectStore('content').delete(site.id);
    // Wait for both deletes in this transaction
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror    = (e) => reject(new Error(`Cleanup tx error: ${e.target.error}`));
    });
  }
}

// ─── Content ─────────────────────────────────────────────────────────────────

async function saveContent(siteId, content) {
  return storePut('content', { siteId, content, updatedAt: new Date().toISOString() });
}

async function getContent(siteId) {
  const record = await storeGet('content', siteId);
  return record?.content || null;
}

// ─── Templates ───────────────────────────────────────────────────────────────

async function saveTemplate(template) {
  return storePut('templates', { ...template, cachedAt: new Date().toISOString() });
}

async function getTemplate(templateId) {
  return storeGet('templates', templateId);
}

async function getTemplatesByCategory(category) {
  return storeGetAllByIndex('templates', 'category', category);
}

async function getAllTemplates() {
  return storeGetAll('templates');
}

// ─── Sync queue ───────────────────────────────────────────────────────────────

async function addToSyncQueue(operation) {
  const item = { ...operation, status: 'pending', createdAt: new Date().toISOString(), attempts: 0 };
  const id = await storePut('syncQueue', item);
  await cleanupSyncQueue();
  return id;
}

async function getPendingSyncItems() {
  return storeGetAllByIndex('syncQueue', 'status', 'pending');
}

async function markSyncItemComplete(id) {
  return storeDelete('syncQueue', id);
}

async function markSyncItemFailed(id) {
  const item = await storeGet('syncQueue', id);
  if (!item) return;
  return storePut('syncQueue', { ...item, status: 'failed', attempts: (item.attempts || 0) + 1 });
}

async function cleanupSyncQueue() {
  const all = await storeGetAll('syncQueue');
  if (all.length <= MAX_SYNC_QUEUE_ITEMS) return;

  // Sort OLDEST first (smallest createdAt) — FIFO: keep oldest, drop newest overflow
  const sorted = [...all].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const toDelete = sorted.slice(MAX_SYNC_QUEUE_ITEMS);

  const db = await openDB();
  for (const item of toDelete) {
    await idbRequest(db.transaction('syncQueue', 'readwrite').objectStore('syncQueue').delete(item.id));
  }
}

// ─── Settings ────────────────────────────────────────────────────────────────

async function saveSetting(key, value) {
  return storePut('settings', { key, value, updatedAt: new Date().toISOString() });
}

async function getSetting(key) {
  const record = await storeGet('settings', key);
  return record?.value ?? null;
}

async function clearAuthData() {
  await storeDelete('settings', 'authToken');
  await storeDelete('settings', 'userId');
  await storeDelete('sessions', 'current');
}

// ─── Storage info ─────────────────────────────────────────────────────────────
// SINGLE definition — was duplicated with different fields in original.

async function getStorageInfo() {
  const [siteCount, contentCount, templateCount, syncCount] = await Promise.all([
    storeCount('sites'),
    storeCount('content'),
    storeCount('templates'),
    storeCount('syncQueue'),
  ]);

  let quota = null;
  try {
    if (navigator.storage?.estimate) {
      const est = await navigator.storage.estimate();
      quota = { used: est.usage, total: est.quota, usedMB: (est.usage / 1024 / 1024).toFixed(1), totalMB: (est.quota / 1024 / 1024).toFixed(1) };
    }
  } catch (e) { /* not supported */ }

  return { siteCount, contentCount, templateCount, syncCount, quota };
}

// ─── Export ───────────────────────────────────────────────────────────────────

window.SiteForgeDB = {
  // Sites
  saveSite, getSite, getSitesByUser, deleteSiteLocally,
  // Content
  saveContent, getContent,
  // Templates
  saveTemplate, getTemplate, getTemplatesByCategory, getAllTemplates,
  // Sync queue
  addToSyncQueue, getPendingSyncItems, markSyncItemComplete, markSyncItemFailed,
  // Settings
  saveSetting, getSetting, clearAuthData,
  // Info
  getStorageInfo,
};
