#!/usr/bin/env bash
# =============================================================
# SiteForge — One-time bootstrap script
# Run once locally. After this, all deploys go through GitHub.
#
# What this does:
#   1. Creates Cloudflare D1, KV, R2, Queue
#   2. Patches wrangler.toml with real resource IDs
#   3. Creates the GitHub repo (siteforge-platform)
#   4. Pushes all code to it
#   5. Sets all CF credentials as GitHub repo secrets
#   6. Triggers the deploy-worker workflow
#
# Usage:
#   bash scripts/bootstrap.sh
# =============================================================
set -euo pipefail

# ── Load credentials ──────────────────────────────────────────
ENV_FILE="$(dirname "$0")/../.env.bootstrap"
if [ ! -f "$ENV_FILE" ]; then
  echo "ERROR: .env.bootstrap not found. Run scripts/write-env.sh first." >&2
  exit 1
fi
# shellcheck source=/dev/null
source "$ENV_FILE"

CF_TOKEN="${CF_API_TOKEN:?CF_API_TOKEN not set}"
CF_ACCOUNT="${CF_ACCOUNT_ID:?CF_ACCOUNT_ID not set}"
GH_TOKEN="${GITHUB_TOKEN:?GITHUB_TOKEN not set}"
GH_USER="${GITHUB_USER:-tylerbuilder}"
REPO_NAME="${REPO_NAME:-siteforge-platform}"
WORKER_NAME="${WORKER_NAME:-siteforge-api}"
PLATFORM_URL="${PLATFORM_URL:-https://siteforge.pages.dev}"

CF_API="https://api.cloudflare.com/client/v4"
GH_API="https://api.github.com"

WRANGLER="$(dirname "$0")/../worker-api/wrangler.toml"

log()  { echo "  ✓ $*"; }
warn() { echo "  ⚠ $*"; }
err()  { echo "  ✗ $*" >&2; }
step() { echo ""; echo "▶ $*"; }

cf() {
  curl -sf -X "${1}" "${CF_API}${2}" \
    -H "Authorization: Bearer ${CF_TOKEN}" \
    -H "Content-Type: application/json" \
    ${3:+--data "$3"}
}

gh_api() {
  curl -sf -X "${1}" "${GH_API}${2}" \
    -H "Authorization: Bearer ${GH_TOKEN}" \
    -H "Accept: application/vnd.github.v3+json" \
    -H "Content-Type: application/json" \
    ${3:+--data "$3"}
}

gh_secret() {
  # GitHub secret encryption requires libsodium; use gh CLI if available
  local repo="$1" name="$2" value="$3"
  if command -v gh &>/dev/null; then
    echo "$value" | gh secret set "$name" -R "${GH_USER}/${repo}" 2>/dev/null && return
  fi
  # Fallback: print for manual entry
  warn "Set GitHub secret manually: $name = [value hidden]"
  echo "  Repo: https://github.com/${GH_USER}/${repo}/settings/secrets/actions/new"
}

# ── 1. Cloudflare D1 database ─────────────────────────────────
step "Creating Cloudflare D1 database..."
D1_RESP=$(cf POST "/accounts/${CF_ACCOUNT}/d1/database" \
  '{"name":"siteforge-db"}' 2>/dev/null || echo '{}')
D1_ID=$(echo "$D1_RESP" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('result',{}).get('uuid',''))" 2>/dev/null || echo "")

if [ -z "$D1_ID" ]; then
  # May already exist — try to fetch existing
  D1_RESP=$(cf GET "/accounts/${CF_ACCOUNT}/d1/database?name=siteforge-db" 2>/dev/null || echo '{}')
  D1_ID=$(echo "$D1_RESP" | python3 -c "import sys,json;d=json.load(sys.stdin);items=d.get('result',[]); print(items[0]['uuid'] if items else '')" 2>/dev/null || echo "")
fi

if [ -z "$D1_ID" ]; then
  err "Could not create or find D1 database. Check your CF token permissions."
  exit 1
fi
log "D1 database ID: $D1_ID"

# ── 2. KV namespace ───────────────────────────────────────────
step "Creating KV namespace..."
KV_RESP=$(cf POST "/accounts/${CF_ACCOUNT}/storage/kv/namespaces" \
  '{"title":"siteforge-content-cache"}' 2>/dev/null || echo '{}')
KV_ID=$(echo "$KV_RESP" | python3 -c "import sys,json;print(json.load(sys.stdin).get('result',{}).get('id',''))" 2>/dev/null || echo "")

if [ -z "$KV_ID" ]; then
  KV_RESP=$(cf GET "/accounts/${CF_ACCOUNT}/storage/kv/namespaces?per_page=100" 2>/dev/null || echo '{}')
  KV_ID=$(echo "$KV_RESP" | python3 -c "
import sys, json
items = json.load(sys.stdin).get('result', [])
match = [i for i in items if i.get('title') == 'siteforge-content-cache']
print(match[0]['id'] if match else '')
" 2>/dev/null || echo "")
fi
[ -n "$KV_ID" ] && log "KV namespace ID: $KV_ID" || warn "KV namespace creation failed — set manually in wrangler.toml"

# ── 3. R2 bucket ──────────────────────────────────────────────
step "Creating R2 bucket..."
cf PUT "/accounts/${CF_ACCOUNT}/r2/buckets" \
  '{"name":"siteforge-assets"}' > /dev/null 2>&1 || true
log "R2 bucket: siteforge-assets (created or already exists)"

# ── 4. Queue ──────────────────────────────────────────────────
step "Creating Queue..."
cf POST "/accounts/${CF_ACCOUNT}/queues" \
  '{"queue_name":"siteforge-builds"}' > /dev/null 2>&1 || true
log "Queue: siteforge-builds (created or already exists)"

# ── 5. Patch wrangler.toml with real IDs ─────────────────────
step "Patching wrangler.toml..."
python3 - "$WRANGLER" "$D1_ID" "$KV_ID" "$CF_ACCOUNT" <<'PY'
import sys, re

path, d1_id, kv_id, account_id = sys.argv[1:]

with open(path) as f:
    content = f.read()

replacements = [
    (r'database_id\s*=\s*"[^"]*"',  f'database_id = "{d1_id}"'),
    (r'id\s*=\s*"your-kv-namespace-id-here"', f'id = "{kv_id}"'),
    (r'account_id\s*=\s*"[^"]*your[^"]*"', f'account_id = "{account_id}"'),
]

for pattern, replacement in replacements:
    content = re.sub(pattern, replacement, content)

with open(path, 'w') as f:
    f.write(content)

print("  wrangler.toml patched")
PY
log "wrangler.toml updated"

# ── 6. Generate secure secrets ────────────────────────────────
step "Generating platform secrets..."
ENCRYPTION_KEY=$(python3 -c "import secrets,base64;print(base64.b64encode(secrets.token_bytes(32)).decode())")
JWT_SECRET=$(python3 -c "import secrets;print(secrets.token_hex(32))")
CRON_SECRET=$(python3 -c "import secrets;print(secrets.token_hex(24))")
PLATFORM_API_KEY=$(python3 -c "import secrets;print(secrets.token_hex(24))")
GH_WEBHOOK_SECRET=$(python3 -c "import secrets;print(secrets.token_hex(24))")

# Save generated secrets to env file so they can be retrieved later
cat >> "$ENV_FILE" <<SECRETS

# Generated by bootstrap — $(date -u)
ENCRYPTION_KEY="$ENCRYPTION_KEY"
JWT_SECRET="$JWT_SECRET"
CRON_SECRET="$CRON_SECRET"
PLATFORM_API_KEY="$PLATFORM_API_KEY"
GH_WEBHOOK_SECRET="$GH_WEBHOOK_SECRET"
D1_DATABASE_ID="$D1_ID"
KV_NAMESPACE_ID="$KV_ID"
SECRETS
log "Secrets generated and appended to .env.bootstrap"

# ── 7. Create GitHub repo ─────────────────────────────────────
step "Creating GitHub repository..."
REPO_RESP=$(gh_api POST "/user/repos" \
  "{\"name\":\"${REPO_NAME}\",\"private\":true,\"description\":\"SiteForge — offline-first website builder for Zimbabwe\",\"auto_init\":false}" \
  2>/dev/null || echo '{}')
REPO_URL=$(echo "$REPO_RESP" | python3 -c "import sys,json;print(json.load(sys.stdin).get('clone_url',''))" 2>/dev/null || echo "")

if [ -z "$REPO_URL" ]; then
  # Already exists
  REPO_URL="https://github.com/${GH_USER}/${REPO_NAME}.git"
  warn "Repo may already exist — using: $REPO_URL"
else
  log "Repo created: $REPO_URL"
fi

# ── 8. Push code to GitHub ────────────────────────────────────
step "Pushing code to GitHub..."
REPO_ROOT="$(dirname "$0")/.."
cd "$REPO_ROOT"

# Add .env.bootstrap to .gitignore
grep -qF '.env.bootstrap' .gitignore 2>/dev/null || echo '.env.bootstrap' >> .gitignore

if [ ! -d ".git" ]; then
  git init -b main
  git add -A
  git commit -m "feat: initial SiteForge platform"
else
  git add -A
  git diff --cached --quiet || git commit -m "chore: update platform files"
fi

AUTH_URL=$(echo "$REPO_URL" | sed "s|https://|https://${GH_TOKEN}@|")
git remote remove origin 2>/dev/null || true
git remote add origin "$AUTH_URL"
git push -u origin main --force
log "Code pushed to ${REPO_URL}"

# ── 9. Set GitHub Secrets ─────────────────────────────────────
step "Setting GitHub repository secrets..."

declare -A SECRETS_MAP=(
  [CLOUDFLARE_API_TOKEN]="$CF_TOKEN"
  [CLOUDFLARE_ACCOUNT_ID]="$CF_ACCOUNT"
  [ENCRYPTION_KEY]="$ENCRYPTION_KEY"
  [JWT_SECRET]="$JWT_SECRET"
  [CRON_SECRET]="$CRON_SECRET"
  [PLATFORM_API_KEY]="$PLATFORM_API_KEY"
  [GITHUB_WEBHOOK_SECRET]="$GH_WEBHOOK_SECRET"
)

for SECRET_NAME in "${!SECRETS_MAP[@]}"; do
  gh_secret "$REPO_NAME" "$SECRET_NAME" "${SECRETS_MAP[$SECRET_NAME]}"
done

# Remaining secrets need to be set manually (need real values from third-party services)
echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │  Set these secrets manually in GitHub:              │"
echo "  │  https://github.com/${GH_USER}/${REPO_NAME}/settings/secrets │"
echo "  │                                                     │"
echo "  │  PAYNOW_INTEGRATION_ID       (from Paynow portal)  │"
echo "  │  PAYNOW_INTEGRATION_SECRET   (from Paynow portal)  │"
echo "  │  FCM_SERVER_KEY              (from Firebase)        │"
echo "  │  GITHUB_APP_ID               (GitHub App)          │"
echo "  │  GITHUB_APP_PRIVATE_KEY      (GitHub App PEM)      │"
echo "  │  GITHUB_APP_INSTALLATION_ID  (GitHub App)          │"
echo "  │  KEYSTORE_BASE64             (Android signing)      │"
echo "  │  KEYSTORE_PASSWORD           (Android signing)      │"
echo "  │  KEYSTORE_ALIAS              (Android signing)      │"
echo "  └─────────────────────────────────────────────────────┘"

# ── 10. Trigger first deploy ──────────────────────────────────
step "Triggering first deployment via GitHub Actions..."
DISPATCH_RESP=$(gh_api POST "/repos/${GH_USER}/${REPO_NAME}/actions/workflows/deploy-worker.yml/dispatches" \
  '{"ref":"main"}' 2>/dev/null || echo '{}')
log "Deploy workflow triggered — watch: https://github.com/${GH_USER}/${REPO_NAME}/actions"

# ── 11. Summary ───────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════"
echo "  SiteForge bootstrap complete"
echo ""
echo "  GitHub repo  : https://github.com/${GH_USER}/${REPO_NAME}"
echo "  Actions      : https://github.com/${GH_USER}/${REPO_NAME}/actions"
echo "  D1 database  : $D1_ID"
echo "  KV namespace : ${KV_ID:-<not created — set manually>}"
echo "  CRON_SECRET  : $CRON_SECRET   (save this for admin panel)"
echo ""
echo "  NEXT STEPS:"
echo "  1. Wait for the GitHub Action deploy to complete (~2 min)"
echo "  2. Run the DB migration:"
echo "     wrangler d1 execute siteforge-db --file=worker-api/schema.sql --remote"
echo "  3. Provision the Worker:"
echo "     curl -X POST https://api.siteforge.co.zw/api/admin/provision \\"
echo "       -H 'Authorization: Bearer $CRON_SECRET'"
echo "  4. Open admin panel: https://admin.siteforge.pages.dev"
echo "  5. Rotate your Cloudflare and GitHub tokens"
echo "════════════════════════════════════════════════════════"
