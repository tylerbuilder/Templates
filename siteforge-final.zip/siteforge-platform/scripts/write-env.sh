#!/usr/bin/env bash
# =============================================================
# Writes .env.bootstrap with your deployment credentials.
# This file is NEVER committed to git.
# Run: bash scripts/write-env.sh
# Then: bash scripts/bootstrap.sh
# =============================================================
set -euo pipefail

REPO_ROOT="$(dirname "$0")/.."
ENV_FILE="${REPO_ROOT}/.env.bootstrap"

cat > "$ENV_FILE" <<'EOF'
# SiteForge bootstrap credentials — DO NOT COMMIT
# Delete this file after bootstrap is complete and credentials are rotated.

CF_API_TOKEN="cfat_zFHe5h6BmTKiR0nCs0bkcBLp4AjqZRnQzkah0xb8b66fdbb8"
CF_ACCOUNT_ID="9b1eec3d41c2f33b9e4318d7938a5c24"
GITHUB_TOKEN="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"
GITHUB_USER="tylerbuilder"
REPO_NAME="siteforge-platform"
WORKER_NAME="siteforge-api"
PLATFORM_URL="https://siteforge.pages.dev"
GITHUB_ORG="tylerbuilder"
TEMPLATES_REPO="tylerbuilder/siteforge-templates"
CUSTOMER_APP_BUILDER_REPO="tylerbuilder/siteforge-customer-apps"
EOF

# Make sure .gitignore excludes it
GITIGNORE="${REPO_ROOT}/.gitignore"
grep -qF '.env.bootstrap' "$GITIGNORE" 2>/dev/null || echo '.env.bootstrap' >> "$GITIGNORE"
grep -qF '.env*' "$GITIGNORE" 2>/dev/null || echo '.env*' >> "$GITIGNORE"

chmod 600 "$ENV_FILE"
echo "✓ .env.bootstrap written (chmod 600, gitignored)"
echo "  Run next: bash scripts/bootstrap.sh"
