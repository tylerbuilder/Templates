/**
 * SiteForge — Scheduled jobs (Cloudflare Workers Cron Triggers).
 * Add to wrangler.toml:
 *
 *   [[triggers.crons]]
 *   crons = ["0 * * * *", "0 0 * * *"]
 *
 * The `scheduled` export handles both.
 */

export async function handleScheduled(event, env, ctx) {
  const cron = event.cron;
  console.log(`[Cron] Triggered: ${cron}`);

  const jobs = [];

  // Every hour — cleanup expired DB rows and rate limits
  if (isHourly(cron)) {
    jobs.push(runCleanup(env));
  }

  // Daily at midnight UTC — renewal checks
  if (isDaily(cron)) {
    jobs.push(queueExpiringRenewals(env));
    jobs.push(resetMonthlyCounters(env));
    jobs.push(pruneOldBuildLogs(env));
  }

  const results = await Promise.allSettled(jobs);
  for (const r of results) {
    if (r.status === 'rejected') console.error('[Cron] Job failed:', r.reason?.message);
  }
}

function isHourly(cron)  { return cron.includes('* * *') || cron === '0 * * * *'; }
function isDaily(cron)   { return cron === '0 0 * * *'  || cron === '0 1 * * *'; }

// ─── Jobs ─────────────────────────────────────────────────────────────────────

async function runCleanup(env) {
  const db = env.DB;

  // Rate limit rows older than 1 hour
  const rlResult = await db.prepare(
    `DELETE FROM rate_limits WHERE window_start < datetime('now', '-1 hour')`
  ).run();

  // Expired + revoked tokens older than 1 day
  const tokResult = await db.prepare(
    `DELETE FROM auth_tokens WHERE expires_at < datetime('now', '-1 day') OR revoked_at < datetime('now', '-1 day')`
  ).run();

  // Used / expired OTPs
  const otpResult = await db.prepare(
    `DELETE FROM otp_codes WHERE used_at IS NOT NULL OR expires_at < datetime('now')`
  ).run();

  console.log(`[Cron] Cleanup — rate_limits: ${rlResult.meta.changes}, tokens: ${tokResult.meta.changes}, otps: ${otpResult.meta.changes}`);
}

async function queueExpiringRenewals(env) {
  const db = env.DB;

  // Subscriptions expiring in the next 3 days that have a Paynow token (auto-renew)
  const expiring = await db.prepare(
    `SELECT id, user_id, plan_id FROM subscriptions
     WHERE status = 'active'
       AND paynow_token IS NOT NULL
       AND current_period_end <= datetime('now', '+3 days')
       AND current_period_end > datetime('now')`
  ).all();

  for (const sub of expiring.results) {
    await env.BUILD_QUEUE.send({ type: 'process-renewal', payload: { subscriptionId: sub.id } });
  }

  console.log(`[Cron] Renewals — queued ${expiring.results.length}`);
}

async function resetMonthlyCounters(env) {
  const db = env.DB;
  const now = new Date();

  // Only reset on the 1st of each month
  if (now.getUTCDate() !== 1) return;

  await db.prepare(`UPDATE sites SET app_rebuilds_this_month = 0`).run();
  console.log('[Cron] Monthly app rebuild counters reset');
}

async function pruneOldBuildLogs(env) {
  const db = env.DB;

  // Keep only last 90 days of build logs
  const result = await db.prepare(
    `DELETE FROM build_logs WHERE created_at < datetime('now', '-90 days')`
  ).run();

  console.log(`[Cron] Build logs pruned: ${result.meta.changes} rows`);
}
