#!/usr/bin/env bash
# ============================================================
# SiteForge — First-run provisioning script
# Run once after deploying the Worker to seed the DB and KV.
# Usage: CRON_SECRET=<secret> WORKER_URL=<url> bash scripts/provision.sh
# ============================================================
set -euo pipefail

WORKER_URL="${WORKER_URL:-https://api.siteforge.co.zw}"
CRON_SECRET="${CRON_SECRET:?CRON_SECRET is required}"

echo "═══════════════════════════════════════════"
echo "  SiteForge provisioning"
echo "  Worker: $WORKER_URL"
echo "═══════════════════════════════════════════"

# 1. Health check
echo ""
echo "▶ Checking Worker health..."
STATUS=$(curl -sf "$WORKER_URL/api/health" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['status'])" 2>/dev/null || echo "unreachable")
echo "  Status: $STATUS"

if [ "$STATUS" = "unreachable" ]; then
  echo "  ERROR: Worker not reachable. Deploy it first."
  exit 1
fi

# 2. Run admin provision (cleanup + DB checks)
echo ""
echo "▶ Running admin provision..."
RESULT=$(curl -sf -X POST "$WORKER_URL/api/admin/provision" \
  -H "Authorization: Bearer $CRON_SECRET" \
  -H "Content-Type: application/json" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['data']['message'])" 2>/dev/null || echo "failed")
echo "  Result: $RESULT"

# 3. Seed template catalog (generate templates into KV)
echo ""
echo "▶ Generating template catalog..."
PLATFORM_API_KEY="${PLATFORM_API_KEY:-}"
if [ -n "$PLATFORM_API_KEY" ]; then
  TEMPLATE_RESULT=$(curl -sf -X POST "$WORKER_URL/api/templates/factory/generate" \
    -H "X-Platform-Key: $PLATFORM_API_KEY" \
    -H "Content-Type: application/json" \
    -d '{"designSystems":["apple","bold-colorful","dark-premium"],"dryRun":false}' \
    | python3 -c "import sys,json;d=json.load(sys.stdin);print(f\"Generated: {d['data']['generated']}\")" 2>/dev/null || echo "skipped")
  echo "  $TEMPLATE_RESULT"
else
  echo "  Skipped (PLATFORM_API_KEY not set)"
fi

# 4. Admin status
echo ""
echo "▶ Admin status check..."
curl -sf "$WORKER_URL/api/admin/status" \
  -H "Authorization: Bearer $CRON_SECRET" \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)['data']
print(f'  Overall: {d[\"status\"]}')
for k,v in d['checks'].items():
    icon = '✓' if v in ('ok','configured') else '✗'
    print(f'  {icon} {k}: {v}')
" 2>/dev/null || echo "  Status check failed"

echo ""
echo "═══════════════════════════════════════════"
echo "  Provisioning complete"
echo "═══════════════════════════════════════════"
