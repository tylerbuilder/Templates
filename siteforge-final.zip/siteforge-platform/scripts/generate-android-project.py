#!/usr/bin/env python3
"""
SiteForge — Android project generator.
Reads app-config.json and site/ HTML files from the repo root,
then writes a self-contained Gradle Android project to ./android-app/.
"""

import json
import os
import sys
import shutil
import re
from pathlib import Path

ROOT        = Path(__file__).parent.parent
CONFIG_FILE = Path(os.environ.get('APP_CONFIG_FILE', 'app-config.json'))
OUT_DIR     = ROOT / 'android-app'


def load_config():
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f'[generator] app-config.json not found at {CONFIG_FILE}')
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f'[generator] Invalid app-config.json: {e}')
        sys.exit(1)


def slugify(text):
    text = re.sub(r'[^\w\s-]', '', text.lower())
    return re.sub(r'[\s-]+', '_', text).strip('_') or 'myapp'


def color_to_hex(color):
    """Ensure color is in #RRGGBB format."""
    c = color.strip()
    if c.startswith('#') and len(c) == 7:
        return c
    return '#0071e3'


def write(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')
    print(f'[generator] wrote {path.relative_to(ROOT)}')


def generate(cfg):
    app_name      = cfg.get('appName', 'My Business App')
    package_slug  = slugify(app_name)
    package_name  = f'co.zw.siteforge.customer.{package_slug}'
    primary_color = color_to_hex(cfg.get('primaryColor', '#0071e3'))
    splash_color  = color_to_hex(cfg.get('splashColor',  '#ffffff'))
    site_id       = cfg.get('siteId', 0)
    site_url      = cfg.get('siteUrl', '')
    enable_push   = str(cfg.get('enablePushNotifications', False)).lower()
    bottom_nav    = cfg.get('bottomNav', [
        {'label': 'Home',    'page': 'site/index.html',   'icon': 'home'},
        {'label': 'About',   'page': 'site/about.html',   'icon': 'info'},
        {'label': 'Contact', 'page': 'site/contact.html', 'icon': 'phone'},
    ])

    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)

    src_main = OUT_DIR / 'app/src/main'
    java_pkg  = src_main / f'java/{package_name.replace(".", "/")}'
    res       = src_main / 'res'

    # ── Copy site assets ────────────────────────────────────────────────────────
    site_src = ROOT / 'site'
    if site_src.exists():
        shutil.copytree(site_src, src_main / 'assets/site')
        print(f'[generator] copied {len(list(site_src.rglob("*")))} site assets')

    # ── settings.gradle ─────────────────────────────────────────────────────────
    write(OUT_DIR / 'settings.gradle', f'rootProject.name = "{app_name}"\ninclude(":app")\n')

    # ── build.gradle (project) ─────────────────────────────────────────────────
    write(OUT_DIR / 'build.gradle', """\
buildscript {
    repositories { google(); mavenCentral() }
    dependencies { classpath 'com.android.tools.build:gradle:8.2.2' }
}
allprojects { repositories { google(); mavenCentral() } }
task clean(type: Delete) { delete rootProject.buildDir }
""")

    # ── build.gradle (app) ─────────────────────────────────────────────────────
    write(OUT_DIR / 'app/build.gradle', f"""\
plugins {{
    id 'com.android.application'
}}

android {{
    namespace '{package_name}'
    compileSdk 34

    defaultConfig {{
        applicationId '{package_name}'
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
        resValue "string", "app_name", "{app_name}"
        resValue "string", "site_id",  "{site_id}"
        resValue "string", "site_url",  "{site_url}"
        resValue "bool",   "enable_push", "{enable_push}"
    }}

    buildTypes {{
        release {{
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }}
    }}

    compileOptions {{
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }}

    sourceSets {{
        main {{
            assets.srcDirs = ['src/main/assets']
        }}
    }}
}}

dependencies {{
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.webkit:webkit:1.9.0'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.core:core:1.12.0'
}}
""")

    # ── AndroidManifest.xml ────────────────────────────────────────────────────
    write(src_main / 'AndroidManifest.xml', f"""\
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:usesCleartextTraffic="false"
        android:theme="@style/Theme.SiteForge">

        <activity
            android:name=".SplashActivity"
            android:exported="true"
            android:theme="@style/Theme.Splash">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <activity
            android:name=".MainActivity"
            android:exported="false"
            android:windowSoftInputMode="adjustResize"/>

    </application>
</manifest>
""")

    # ── SplashActivity.java ────────────────────────────────────────────────────
    write(java_pkg / 'SplashActivity.java', f"""\
package {package_name};

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {{
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {{
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }}, 1500);
    }}
}}
""")

    # ── MainActivity.java ──────────────────────────────────────────────────────
    nav_items_java = '\n'.join([
        f'        navItems.add(new NavItem("{item["label"]}", "{item["page"]}", "{item["icon"]}"));'
        for item in bottom_nav
    ])

    write(java_pkg / 'MainActivity.java', f"""\
package {package_name};

import android.annotation.SuppressLint;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {{

    private WebView webView;
    private BottomNavigationView bottomNav;
    private LinearLayout offlineBanner;
    private String currentPage = "site/index.html";

    static class NavItem {{
        String label, page, icon;
        NavItem(String label, String page, String icon) {{
            this.label = label; this.page = page; this.icon = icon;
        }}
    }}

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView     = findViewById(R.id.webView);
        offlineBanner = findViewById(R.id.offlineBanner);

        setupWebView();
        setupBottomNav();

        if (savedInstanceState == null) {{
            loadPage(currentPage);
        }}
    }}

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {{
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {{
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {{
                String url = req.getUrl().toString();
                // Open external links in browser, not WebView
                if (!url.startsWith("file://") && !url.startsWith("about:")) {{
                    try {{
                        startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse(url)));
                    }} catch (Exception e) {{ }}
                    return true;
                }}
                return false;
            }}

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {{
                showOfflineBanner(true);
            }}

            @Override
            public void onPageFinished(WebView view, String url) {{
                boolean online = isOnline();
                showOfflineBanner(!online);
            }}
        }});

        webView.addJavascriptInterface(new SiteForgeJSBridge(this), "SiteForgeApp");
    }}

    private void setupBottomNav() {{
        List<NavItem> navItems = new ArrayList<>();
{nav_items_java}

        bottomNav = findViewById(R.id.bottomNav);
        bottomNav.getMenu().clear();

        for (int i = 0; i < Math.min(navItems.size(), 5); i++) {{
            NavItem item = navItems.get(i);
            bottomNav.getMenu().add(0, i, i, item.label);
        }}

        bottomNav.setOnItemSelectedListener(item -> {{
            if (item.getItemId() < navItems.size()) {{
                loadPage(navItems.get(item.getItemId()).page);
                return true;
            }}
            return false;
        }});
    }}

    private void loadPage(String page) {{
        currentPage = page;
        webView.loadUrl("file:///android_asset/" + page);
    }}

    private void showOfflineBanner(boolean show) {{
        offlineBanner.setVisibility(show ? View.VISIBLE : View.GONE);
    }}

    private boolean isOnline() {{
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }}

    @Override
    public void onBackPressed() {{
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }}

    @Override
    protected void onSaveInstanceState(Bundle outState) {{
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }}

    @Override
    protected void onRestoreInstanceState(Bundle savedState) {{
        super.onRestoreInstanceState(savedState);
        webView.restoreState(savedState);
    }}
}}
""")

    # ── SiteForgeJSBridge.java ─────────────────────────────────────────────────
    write(java_pkg / 'SiteForgeJSBridge.java', f"""\
package {package_name};

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class SiteForgeJSBridge {{
    private final Context context;

    SiteForgeJSBridge(Context context) {{ this.context = context; }}

    @JavascriptInterface
    public void openWhatsApp(String number, String message) {{
        try {{
            String url = "https://wa.me/" + number + "?text=" + Uri.encode(message);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            context.startActivity(intent);
        }} catch (Exception e) {{ showToast("WhatsApp not installed"); }}
    }}

    @JavascriptInterface
    public void openPhone(String number) {{
        try {{
            context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
        }} catch (Exception e) {{ showToast("Cannot open dialler"); }}
    }}

    @JavascriptInterface
    public void openEmail(String email) {{
        try {{
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email));
            context.startActivity(intent);
        }} catch (Exception e) {{ showToast("No email app found"); }}
    }}

    @JavascriptInterface
    public void showToast(String message) {{
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }}

    @JavascriptInterface
    public String getSiteId() {{ return context.getString(R.string.site_id); }}

    @JavascriptInterface
    public String getSiteUrl() {{ return context.getString(R.string.site_url); }}
}}
""")

    # ── Layouts ────────────────────────────────────────────────────────────────
    write(src_main / 'res/layout/activity_splash.xml', f"""\
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    android:background="{splash_color}">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/app_name"
        android:textSize="28sp"
        android:textStyle="bold"
        android:textColor="#1d1d1f"/>
</LinearLayout>
""")

    write(src_main / 'res/layout/activity_main.xml', """\
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">

    <LinearLayout
        android:id="@+id/offlineBanner"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="#ffd60a"
        android:padding="8dp"
        android:gravity="center"
        android:visibility="gone">
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Offline — viewing cached content"
            android:textSize="13sp"
            android:textColor="#333333"/>
    </LinearLayout>

    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"/>

    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id="@+id/bottomNav"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>
</LinearLayout>
""")

    # ── Colors & styles ────────────────────────────────────────────────────────
    write(res / 'values/colors.xml', f"""\
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">{primary_color}</color>
    <color name="splash_bg">{splash_color}</color>
    <color name="white">#FFFFFF</color>
    <color name="black">#FF000000</color>
</resources>
""")

    write(res / 'values/styles.xml', f"""\
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.SiteForge" parent="Theme.MaterialComponents.Light.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorPrimaryVariant">@color/primary</item>
        <item name="colorOnPrimary">@color/white</item>
        <item name="android:windowBackground">@color/white</item>
        <item name="android:navigationBarColor">@color/white</item>
    </style>
    <style name="Theme.Splash" parent="Theme.SiteForge">
        <item name="android:windowBackground">@color/splash_bg</item>
        <item name="android:windowFullscreen">true</item>
    </style>
</resources>
""")

    write(res / 'values/strings.xml', f"""\
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">{app_name}</string>
</resources>
""")

    # ── Placeholder launcher icons ─────────────────────────────────────────────
    for density in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
        mipmap = res / f'mipmap-{density}'
        mipmap.mkdir(parents=True, exist_ok=True)
        # Real icon would be generated from appIcon field in production
        (mipmap / 'ic_launcher.png').write_bytes(b'')
        (mipmap / 'ic_launcher_round.png').write_bytes(b'')

    # ── proguard-rules.pro ────────────────────────────────────────────────────
    write(OUT_DIR / 'app/proguard-rules.pro', """\
# SiteForge customer app proguard rules
-keep class **.SiteForgeJSBridge { @android.webkit.JavascriptInterface *; }
-keepattributes JavascriptInterface
""")

    print(f'\n[generator] Android project generated → {OUT_DIR}')
    print(f'[generator] Package: {package_name}')
    print(f'[generator] App name: {app_name}')


if __name__ == '__main__':
    cfg = load_config()
    generate(cfg)
