# SiteForge Platform

> Offline-first website and Android app builder for Zimbabwean businesses.

---

## Architecture overview

```
siteforge-platform/
├── worker-api/              Cloudflare Worker (D1 + KV + R2 + Queues)
│   ├── src/
│   │   ├── index.js         Router, auth middleware, queue consumer
│   │   ├── auth.js          OTP phone auth, JWT-less token system
│   │   ├── sites.js         Site CRUD
│   │   ├── templates.js     Template catalog
│   │   ├── deploy.js        Cloudflare Pages deployment
│   │   ├── paynow.js        EcoCash / Paynow payments
│   │   ├── oauth.js         Cloudflare OAuth (self-hosting)
│   │   ├── push.js          FCM push notifications
│   │   ├── github-build.js  Android APK build via GitHub Actions
│   │   ├── admin-setup.js   Provisioning + health check
│   │   └── template-factory/
│   │       ├── index.js         Orchestrator + GitHub push (batch tree API)
│   │       ├── industries.js    60+ industries catalog
│   │       ├── design-systems.js 8 visual styles
│   │       ├── content-schema.js Field definitions per industry
│   │       ├── page-assembler.js HTML page generator (all bugs fixed)
│   │       ├── style-generator.js CSS + JS generator
│   │       ├── routes.js        Factory HTTP handlers
│   │       └── github-token.js  GitHub App JWT (no circular deps)
│   ├── schema.sql           D1 table definitions + indexes
│   └── wrangler.toml        Bindings and cron config
│
├── editor-app/              Offline-first PWA editor (Cloudflare Pages)
│   ├── index.html
│   ├── sw.js                Service worker (cache-first shell, network-first API)
│   ├── manifest.json
│   └── assets/
│       ├── css/editor.css
│       └── js/
│           ├── offline-db.js  IndexedDB layer (all tx.complete bugs fixed)
│           └── app.js         Editor application
│
├── homepage/                Marketing site (Cloudflare Pages)
│   ├── index.html
│   └── assets/css/home.css
│
├── scripts/
│   ├── generate-android-project.py  Android project generator
│   ├── provision.sh                 First-run provisioning
│   └── cron.js                      Scheduled job handlers
│
└── .github/workflows/
    ├── deploy-worker.yml       Deploys Worker on push to main
    └── build-customer-app.yml  Builds customer APK on repository_dispatch
```

---

## Bugs fixed from original design

### page-assembler.js (5 bugs)
| # | Bug | Fix |
|---|-----|-----|
| 1 | `content` parameter accepted but never read — `{{placeholders}}` remained literal in all output HTML | `resolveContentValues()` extracts `.default` from schema descriptors and substitutes all tokens |
| 2 | CSS variables injected only into home page; all other pages had no design system applied | `buildCSSVariables()` + `buildHead()` shared helpers called in every page assembler |
| 3 | `assembleServicesPage`, `assembleGalleryPage`, `assembleProductsPage` all silently returned the contact page | Each is now a distinct, correct implementation |
| 4 | Secondary page navbars hardcoded Home/About/Contact regardless of `industry.pages` | `buildNav(industry, activePage)` reads `industry.pages` dynamically on every page |
| 5 | `images` parameter accepted but entirely unreachable | Flows through `resolveContentValues()` with fallback merge |

### deploy.js (2 bugs)
| # | Bug | Fix |
|---|-----|-----|
| 6 | EOCD entry count used `files.length` — undefined on an Object, so ZIP was always malformed | Fixed to `Object.entries(files).length` (captured at loop start) |
| 7 | `fetchTemplateFiles` had no implementation (returned empty) | Now tries KV cache → GitHub raw → fallback minimal template |

### index.js / router (2 bugs)
| # | Bug | Fix |
|---|-----|-----|
| 8 | `/api/templates/featured`, `/new`, `/trending` declared after `/:id` — permanently shadowed | Static routes declared before param route in ROUTES table |
| 9 | `handleQueueMessage` in `rate-limit.js` referenced `deploy`, `githubBuild`, `push`, `paynow` with no imports — ReferenceError on first job | Moved entirely into `index.js` where all imports exist |

### github-build.js (3 bugs)
| # | Bug | Fix |
|---|-----|-----|
| 10 | `getGitHubToken()` in factory was a stub always returning `null` | Replaced with real `getGitHubInstallationToken()` using RSA-SHA256 JWT |
| 11 | `pemToArrayBuffer` only stripped PKCS8 headers; RSA PRIVATE KEY format crashed `importKey` | Regex now strips any `-----BEGIN/END * KEY-----` variant |
| 12 | `handleBuildComplete` parsed body before verifying HMAC signature — signature check could not work | Raw body read first, HMAC verified, then JSON parsed |

### offline-db.js (3 bugs)
| # | Bug | Fix |
|---|-----|-----|
| 13 | `tx.complete` used as `await tx.complete` — not a valid IDBTransaction property (resolves immediately as `undefined`) | All transactions use explicit `Promise` wrappers on `onsuccess`/`onerror` / `tx.oncomplete` |
| 14 | `getStorageInfo` defined twice with different field sets | Single canonical definition with all 4 counts + quota |
| 15 | Sync queue overflow deleted oldest items (FIFO reversal) | Sorted oldest-first, slices newest overflow — keeps highest-priority pending items |

---

## Setup

### Prerequisites
- Cloudflare account with Workers, D1, KV, R2, Queues access
- GitHub App with `contents:write` permission
- Paynow merchant account
- FCM project (for push notifications)

### 1. Clone and configure

```bash
git clone https://github.com/siteforge-platform/siteforge-platform
cd siteforge-platform/worker-api
cp wrangler.toml.example wrangler.toml   # fill in your IDs
```

### 2. Set secrets

```bash
wrangler secret put ENCRYPTION_KEY       # base64(32 random bytes)
wrangler secret put JWT_SECRET
wrangler secret put GITHUB_APP_ID
wrangler secret put GITHUB_APP_PRIVATE_KEY
wrangler secret put GITHUB_APP_INSTALLATION_ID
wrangler secret put GITHUB_WEBHOOK_SECRET
wrangler secret put PAYNOW_INTEGRATION_ID
wrangler secret put PAYNOW_INTEGRATION_SECRET
wrangler secret put CLOUDFLARE_API_TOKEN
wrangler secret put CLOUDFLARE_ACCOUNT_ID
wrangler secret put CLOUDFLARE_OAUTH_CLIENT_ID
wrangler secret put CLOUDFLARE_OAUTH_CLIENT_SECRET
wrangler secret put FCM_SERVER_KEY
wrangler secret put CRON_SECRET
wrangler secret put PLATFORM_API_KEY
```

### 3. Create infrastructure

```bash
wrangler d1 create siteforge-db
wrangler kv:namespace create CONTENT_CACHE
wrangler r2 bucket create siteforge-assets
wrangler queues create siteforge-builds
# Update wrangler.toml with the IDs printed above
```

### 4. Deploy

```bash
wrangler deploy
wrangler d1 execute siteforge-db --file=schema.sql --remote
```

### 5. Provision

```bash
CRON_SECRET=<your-secret> WORKER_URL=https://api.siteforge.co.zw \
PLATFORM_API_KEY=<your-key> bash scripts/provision.sh
```

### 6. Deploy editor and homepage

Both are static sites deployable to Cloudflare Pages:

```bash
# In Cloudflare dashboard: create Pages projects for
# editor-app/ and homepage/ pointing to their directories.
```

---

## API reference

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/send-otp` | — | Send OTP to phone |
| POST | `/api/auth/verify-otp` | — | Verify OTP, get tokens |
| POST | `/api/auth/refresh` | — | Rotate tokens |
| GET | `/api/auth/me` | Bearer | Current user + sites |
| POST | `/api/sites` | Bearer | Create site |
| GET | `/api/sites` | Bearer | List sites |
| GET | `/api/sites/:id` | Bearer | Get site |
| PATCH | `/api/sites/:id` | Bearer | Update name/domain |
| DELETE | `/api/sites/:id` | Bearer | Soft delete |
| PUT | `/api/sites/:id/content` | Bearer | Update content |
| PUT | `/api/sites/:id/app-config` | Bearer | Update app config |
| POST | `/api/sites/:id/publish` | Bearer | Publish site |
| POST | `/api/sites/:id/rebuild` | Bearer | Re-deploy |
| GET | `/api/templates` | — | List templates |
| GET | `/api/templates/featured` | — | Featured templates |
| GET | `/api/templates/new` | — | Newest templates |
| GET | `/api/templates/trending` | — | Trending templates |
| GET | `/api/templates/:id` | — | Template detail |
| POST | `/api/paynow/initiate` | Bearer | Start payment |
| POST | `/api/paynow/callback` | — | Paynow webhook |
| GET | `/api/paynow/status/:ref` | Bearer | Payment status |
| GET | `/api/oauth/cloudflare` | Bearer | Start CF OAuth |
| GET | `/api/oauth/cloudflare/callback` | — | OAuth callback |
| POST | `/api/push/register` | — | Register FCM device |
| POST | `/api/push/send` | Bearer | Send push campaign |
| GET | `/api/push/campaigns` | Bearer | List campaigns |
| POST | `/api/builds/app` | Bearer | Trigger APK build |
| POST | `/api/builds/complete` | GitHub HMAC | Build callback |
| POST | `/api/admin/provision` | CRON_SECRET | Run cleanup |
| GET | `/api/admin/status` | CRON_SECRET | Health check |
| GET | `/api/health` | — | Worker health |

---

## Plans

| Plan | Price | Features |
|------|-------|----------|
| Free | $0 | 1 site, siteforge.pages.dev subdomain, all templates |
| Pro | $3/mo | Custom domain, no branding, analytics |
| Native App | $30/yr | Android APK, push notifications, 5 rebuilds/month |
| Push Small | $3/mo | 5 campaigns, 500 recipients |
| Push Medium | $6/mo | 15 campaigns, 2,000 recipients |
| Push Large | $12/mo | Unlimited campaigns, 10,000 recipients |
